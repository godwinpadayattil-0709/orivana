/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Source Code Pro', 'Courier New', 'monospace'],
        display: ['Source Code Pro', 'Courier New', 'monospace'],
        mono: ['Source Code Pro', 'Courier New', 'monospace'],
      },
      colors: {
        accent: {
          DEFAULT: 'var(--accent)',
          light: 'var(--accent-light)',
          dark: 'var(--accent-dark)',
        },
        emerald: {
          50: '#e6f8f8',
          100: '#c7f0f0',
          200: '#9ee5e5',
          300: '#7de0e0',
          400: '#58d0d0',
          500: '#3aaaa0',
          600: '#2e8895',
          700: '#236b75',
          800: '#1a5258',
          900: '#123a3e',
          950: '#0a2628',
        },
        teal: {
          50: '#e6f8f8',
          100: '#c7f0f0',
          200: '#9ee5e5',
          300: '#7de0e0',
          400: '#58d0d0',
          500: '#3aaaa0',
          600: '#2e8895',
          700: '#236b75',
          800: '#1a5258',
          900: '#123a3e',
          950: '#0a2628',
        },
      },
      borderRadius: {
        'none': '0',
        'sm': '0.125rem',
        DEFAULT: '0.125rem',
        'md': '0.125rem',
        'lg': '0.25rem',
        'xl': '0.375rem',
        '2xl': '0.5rem',
        '3xl': '0.75rem',
      },
      animation: {
        'fade-in': 'fadeIn 0.35s ease-out',
        'fade-in-up': 'fadeInUp 0.4s ease-out',
        'scale-in': 'scaleIn 0.3s ease-out',
        'shimmer': 'shimmer 2.5s ease-in-out infinite',
        'pulse-ring': 'pulseRing 2s ease-in-out infinite',
        'slide-up': 'slideUp 0.3s ease-out',
        'count-up': 'countUp 0.6s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        scaleIn: {
          '0%': { opacity: '0', transform: 'scale(0.96)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        shimmer: {
          '0%, 100%': { opacity: '0.3' },
          '50%': { opacity: '0.6' },
        },
        pulseRing: {
          '0%, 100%': { transform: 'scale(1)', opacity: '0.5' },
          '50%': { transform: 'scale(1.05)', opacity: '0.8' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(100%)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
};
