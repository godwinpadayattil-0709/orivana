# Orivana — Your Daily Health & Wellness Companion

A premium, WHOOP-inspired personal wellness app where users set daily health goals, quickly log sleep, water, exercise, and steps, see their progress visually with Apple Health-style concentric rings, track streaks, and receive AI-powered summaries and suggestions.

## Features

- **Authentication** — Sign up, log in, log out with Supabase Auth
- **Profile & Goals** — Set your name, age, weight, and daily targets for water, sleep, exercise, and steps
- **Daily Tracking** — Log sleep hours, water intake, exercise minutes, steps, and weight in under 30 seconds with live goal progress bars
- **Home Dashboard** — Apple Health-style multi-ring progress display showing all four metrics at once, plus individual metric cards, a streak counter, and a weekly bar chart
- **Progress Trends** — 7-day line charts for each metric with averages, consistency scores, and a weekly consistency hero stat
- **AI Insights** — Weekly summary and practical suggestions generated from your logged data (via OpenAI, with a fallback summary if no API key is set)
- **Responsive** — Mobile-first with bottom navigation; desktop sidebar on larger screens

## Technology Stack

- **Frontend:** React + TypeScript + Vite + Tailwind CSS
- **Icons:** Lucide React
- **Backend:** Supabase (PostgreSQL + Auth + Row Level Security)
- **AI:** OpenAI API (via Supabase Edge Function)
- **Charts:** Custom lightweight SVG charts

## Local Setup

```bash
npm install
npm run dev
```

## Environment Variables

The following are pre-configured in the project's `.env` file:

```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

For AI insights, an `OPENAI_API_KEY` secret can be added to the Supabase edge function. If not set, the app generates a fallback summary from the logged data.

## Database

The Supabase database has four tables:
- `profiles` — user personal info (name, age, weight)
- `goals` — daily wellness targets (water, sleep, exercise, steps)
- `daily_health_logs` — per-day habit entries with a unique constraint on (user_id, log_date)
- `ai_insights` — cached AI-generated summaries

All tables have Row Level Security enabled with owner-scoped policies — users can only access their own data.

## Development Commands

```bash
npm run dev      # Start dev server
npm run build    # Production build
npm run typecheck # TypeScript check
npm run lint     # ESLint
```
