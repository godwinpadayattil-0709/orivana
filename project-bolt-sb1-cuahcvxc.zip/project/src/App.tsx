import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import { ThemeProvider } from '@/lib/theme';
import { fetchGoals, fetchWellnessSettings } from '@/lib/api';
import { AuthScreen } from '@/components/screens/AuthScreen';
import { OnboardingScreen } from '@/components/screens/OnboardingScreen';
import { HomeScreen } from '@/components/screens/HomeScreen';
import { TrackScreen } from '@/components/screens/TrackScreen';
import { ProgressScreen } from '@/components/screens/ProgressScreen';
import { AIScreen } from '@/components/screens/AIScreen';
import { ProfileScreen } from '@/components/screens/ProfileScreen';
import { SettingsScreen } from '@/components/screens/SettingsScreen';
import { GratitudeScreen } from '@/components/screens/GratitudeScreen';
import { MeditationScreen } from '@/components/screens/MeditationScreen';
import { HabitsScreen } from '@/components/screens/HabitsScreen';
import { MedicalDocsScreen } from '@/components/screens/MedicalDocsScreen';
import { DietPlansScreen } from '@/components/screens/DietPlansScreen';
import { MobileBottomNav, DesktopSidebar, type TabId } from '@/components/navigation/Navigation';
import { Loader2 } from 'lucide-react';

function AppContent() {
  const { user, profile, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [needsOnboarding, setNeedsOnboarding] = useState(false);
  const [checkingOnboarding, setCheckingOnboarding] = useState(true);
  const [wellnessEnabled, setWellnessEnabled] = useState({ gratitude: false, meditation: false });

  useEffect(() => {
    if (!user) {
      setCheckingOnboarding(false);
      return;
    }
    let cancelled = false;
    async function check() {
      if (!user || cancelled) return;
      const [goals, settings] = await Promise.all([
        fetchGoals(user.id),
        fetchWellnessSettings(user.id),
      ]);
      if (cancelled) return;
      setNeedsOnboarding(!profile?.name || !goals);
      if (settings) {
        setWellnessEnabled({
          gratitude: settings.gratitude_enabled,
          meditation: settings.meditation_enabled,
        });
      }
      setCheckingOnboarding(false);
    }
    check();
    return () => { cancelled = true; };
  }, [user, profile]);

  // Refresh wellness settings when tab changes to/from settings
  useEffect(() => {
    if (!user || activeTab !== 'settings') return;
    let cancelled = false;
    async function refresh() {
      if (!user || cancelled) return;
      const settings = await fetchWellnessSettings(user.id);
      if (cancelled) return;
      if (settings) {
        setWellnessEnabled({
          gratitude: settings.gratitude_enabled,
          meditation: settings.meditation_enabled,
        });
      }
    }
    refresh();
    return () => { cancelled = true; };
  }, [user, activeTab]);

  if (loading || checkingOnboarding) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-app-primary">
        <Loader2 className="h-8 w-8 animate-spin text-accent" />
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  if (needsOnboarding) {
    return <OnboardingScreen />;
  }

  const isWellnessScreen = ['gratitude', 'meditation', 'habits', 'medical', 'diet', 'settings'].includes(activeTab);
  const paddingBottom = isWellnessScreen ? 'pb-44' : 'pb-28';

  return (
    <div className="min-h-screen bg-app-primary text-app-primary">
      <DesktopSidebar activeTab={activeTab} onTabChange={setActiveTab} wellnessEnabled={wellnessEnabled} />
      <MobileBottomNav activeTab={activeTab} onTabChange={setActiveTab} wellnessEnabled={wellnessEnabled} />

      <main className={`mx-auto max-w-2xl px-5 pt-8 md:ml-64 md:pb-8 md:pt-10 ${paddingBottom}`}>
        {activeTab === 'home' && <HomeScreen onNavigate={setActiveTab} />}
        {activeTab === 'track' && <TrackScreen />}
        {activeTab === 'progress' && <ProgressScreen />}
        {activeTab === 'ai' && <AIScreen />}
        {activeTab === 'profile' && <ProfileScreen />}
        {activeTab === 'settings' && <SettingsScreen />}
        {activeTab === 'gratitude' && wellnessEnabled.gratitude && <GratitudeScreen />}
        {activeTab === 'meditation' && wellnessEnabled.meditation && <MeditationScreen />}
        {activeTab === 'habits' && <HabitsScreen />}
        {activeTab === 'medical' && <MedicalDocsScreen />}
        {activeTab === 'diet' && <DietPlansScreen />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}
