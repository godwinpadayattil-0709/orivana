export interface ValidationResult {
  valid: boolean;
  error?: string;
}

export function validateSleep(value: number): ValidationResult {
  if (value < 0 || value > 24) return { valid: false, error: 'Sleep must be between 0 and 24 hours' };
  return { valid: true };
}

export function validateWater(value: number): ValidationResult {
  if (value < 0 || value > 20) return { valid: false, error: 'Water must be between 0 and 20 litres' };
  return { valid: true };
}

export function validateExercise(value: number): ValidationResult {
  if (value < 0 || value > 1440) return { valid: false, error: 'Exercise must be between 0 and 1440 minutes' };
  return { valid: true };
}

export function validateSteps(value: number): ValidationResult {
  if (value < 0 || value > 100000) return { valid: false, error: 'Steps must be between 0 and 100,000' };
  return { valid: true };
}

export function validateWeight(value: number): ValidationResult {
  if (value <= 0 || value > 500) return { valid: false, error: 'Weight must be a positive value' };
  return { valid: true };
}

export function validateAge(value: number): ValidationResult {
  if (value < 0 || value > 150) return { valid: false, error: 'Age must be between 0 and 150' };
  return { valid: true };
}

export function validateLogEntry(data: {
  sleep_hours: number;
  water_amount: number;
  exercise_minutes: number;
  steps: number;
  weight?: number | null;
}): ValidationResult {
  const checks = [
    validateSleep(data.sleep_hours),
    validateWater(data.water_amount),
    validateExercise(data.exercise_minutes),
    validateSteps(data.steps),
  ];
  if (data.weight !== null && data.weight !== undefined) {
    checks.push(validateWeight(data.weight));
  }
  const failed = checks.find((c) => !c.valid);
  return failed || { valid: true };
}
