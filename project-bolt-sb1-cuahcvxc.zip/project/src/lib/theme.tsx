import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { COLOR_THEMES, DEFAULT_THEME_ID, getThemeById, type ThemeColors } from '@/lib/theme-presets';

export type ThemeMode = 'dark' | 'light' | 'auto';

interface ThemeContextValue {
  theme: ThemeMode;
  resolvedTheme: 'dark' | 'light';
  setTheme: (mode: ThemeMode) => void;
  colorThemeId: string;
  setColorThemeId: (id: string) => void;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

function getSystemTheme(): 'dark' | 'light' {
  if (typeof window === 'undefined') return 'dark';
  const hour = new Date().getHours();
  return hour >= 7 && hour < 19 ? 'light' : 'dark';
}

function applyTheme(resolved: 'dark' | 'light') {
  const root = document.documentElement;
  if (resolved === 'light') {
    root.classList.remove('dark');
    root.classList.add('light');
  } else {
    root.classList.remove('light');
    root.classList.add('dark');
  }
}

function applyColorTheme(themeId: string, resolved: 'dark' | 'light') {
  const theme = getThemeById(themeId);
  if (!theme) return;
  const colors: ThemeColors = resolved === 'light' ? theme.light : theme.dark;
  const root = document.documentElement;
  (Object.keys(colors) as (keyof ThemeColors)[]).forEach((key) => {
    root.style.setProperty(key, colors[key]);
  });
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    if (typeof window === 'undefined') return 'dark';
    return (localStorage.getItem('orivana-theme') as ThemeMode) || 'dark';
  });

  const [colorThemeId, setColorThemeIdState] = useState<string>(() => {
    if (typeof window === 'undefined') return DEFAULT_THEME_ID;
    return localStorage.getItem('orivana-color-theme') || DEFAULT_THEME_ID;
  });

  const [resolvedTheme, setResolvedTheme] = useState<'dark' | 'light'>(() => {
    if (theme === 'auto') return getSystemTheme();
    return theme;
  });

  useEffect(() => {
    const resolved = theme === 'auto' ? getSystemTheme() : theme;
    setResolvedTheme(resolved);
    applyTheme(resolved);
    applyColorTheme(colorThemeId, resolved);
    localStorage.setItem('orivana-theme', theme);
  }, [theme, colorThemeId]);

  useEffect(() => {
    if (theme !== 'auto') return;
    const interval = setInterval(() => {
      const sys = getSystemTheme();
      setResolvedTheme((prev) => {
        if (prev !== sys) {
          applyTheme(sys);
          applyColorTheme(colorThemeId, sys);
          return sys;
        }
        return prev;
      });
    }, 60000);
    return () => clearInterval(interval);
  }, [theme, colorThemeId]);

  const setTheme = (mode: ThemeMode) => setThemeState(mode);

  const setColorThemeId = (id: string) => {
    setColorThemeIdState(id);
    localStorage.setItem('orivana-color-theme', id);
  };

  return (
    <ThemeContext.Provider value={{ theme, resolvedTheme, setTheme, colorThemeId, setColorThemeId }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}

export { COLOR_THEMES };
