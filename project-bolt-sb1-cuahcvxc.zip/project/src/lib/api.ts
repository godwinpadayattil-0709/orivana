import { supabase } from '@/lib/supabase';
import type {
  Goals, DailyHealthLog, Profile, AIInsight,
  GratitudeEntry, MeditationSession, WellnessSettings,
  Habit, MedicalDocument, DietPlan, MoodEntry,
} from '@/types';

// ============================================================
// Profile
// ============================================================

export async function fetchProfile(userId: string): Promise<Profile | null> {
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  return data as Profile | null;
}

export async function upsertProfile(
  userId: string,
  profile: { name?: string; age?: number; weight?: number; country?: string; country_source?: string; timezone?: string }
): Promise<Profile | null> {
  const { data } = await supabase
    .from('profiles')
    .upsert({ id: userId, ...profile, updated_at: new Date().toISOString() })
    .select()
    .single();
  return data as Profile | null;
}

// ============================================================
// Goals
// ============================================================

export async function fetchGoals(userId: string): Promise<Goals | null> {
  const { data } = await supabase
    .from('goals')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();
  return data as Goals | null;
}

export async function upsertGoals(
  userId: string,
  goals: { water_goal: number; sleep_goal: number; exercise_goal: number; steps_goal: number }
): Promise<Goals | null> {
  const existing = await fetchGoals(userId);
  if (existing) {
    const { data } = await supabase
      .from('goals')
      .update({ ...goals, updated_at: new Date().toISOString() })
      .eq('id', existing.id)
      .select()
      .single();
    return data as Goals | null;
  } else {
    const { data } = await supabase
      .from('goals')
      .insert({ user_id: userId, ...goals })
      .select()
      .single();
    return data as Goals | null;
  }
}

// ============================================================
// Daily Health Logs
// ============================================================

export async function fetchTodayLog(userId: string): Promise<DailyHealthLog | null> {
  const today = new Date().toISOString().split('T')[0];
  const { data } = await supabase
    .from('daily_health_logs')
    .select('*')
    .eq('user_id', userId)
    .eq('log_date', today)
    .maybeSingle();
  return data as DailyHealthLog | null;
}

export async function upsertDailyLog(
  userId: string,
  log: {
    sleep_hours: number;
    water_amount: number;
    exercise_minutes: number;
    steps: number;
    weight?: number | null;
  }
): Promise<DailyHealthLog | null> {
  const today = new Date().toISOString().split('T')[0];
  const { data: existing } = await supabase
    .from('daily_health_logs')
    .select('id')
    .eq('user_id', userId)
    .eq('log_date', today)
    .maybeSingle();

  if (existing) {
    const { data } = await supabase
      .from('daily_health_logs')
      .update({ ...log, updated_at: new Date().toISOString() })
      .eq('id', existing.id)
      .select()
      .single();
    return data as DailyHealthLog | null;
  } else {
    const { data } = await supabase
      .from('daily_health_logs')
      .insert({ user_id: userId, log_date: today, ...log })
      .select()
      .single();
    return data as DailyHealthLog | null;
  }
}

export async function fetchRecentLogs(
  userId: string,
  days: number = 7
): Promise<DailyHealthLog[]> {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days + 1);
  const startDateStr = startDate.toISOString().split('T')[0];

  const { data } = await supabase
    .from('daily_health_logs')
    .select('*')
    .eq('user_id', userId)
    .gte('log_date', startDateStr)
    .order('log_date', { ascending: true });
  return (data as DailyHealthLog[]) || [];
}

// ============================================================
// AI Insights
// ============================================================

export async function fetchLatestInsight(userId: string): Promise<AIInsight | null> {
  const { data } = await supabase
    .from('ai_insights')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();
  return data as AIInsight | null;
}

export async function saveInsight(
  userId: string,
  insight: {
    period_start: string;
    period_end: string;
    summary: string;
    suggestions: string;
  }
): Promise<void> {
  await supabase.from('ai_insights').insert({
    user_id: userId,
    insight_date: new Date().toISOString().split('T')[0],
    ...insight,
  });
}

// ============================================================
// Wellness Settings
// ============================================================

export async function fetchWellnessSettings(userId: string): Promise<WellnessSettings | null> {
  const { data } = await supabase
    .from('wellness_settings')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();
  return data as WellnessSettings | null;
}

export async function upsertWellnessSettings(
  userId: string,
  settings: Partial<WellnessSettings>
): Promise<WellnessSettings | null> {
  const { data } = await supabase
    .from('wellness_settings')
    .upsert({ user_id: userId, ...settings, updated_at: new Date().toISOString() })
    .select()
    .single();
  return data as WellnessSettings | null;
}

// ============================================================
// Gratitude Entries
// ============================================================

export async function fetchGratitudeEntry(
  userId: string,
  date: string
): Promise<GratitudeEntry | null> {
  const { data } = await supabase
    .from('gratitude_entries')
    .select('*')
    .eq('user_id', userId)
    .eq('entry_date', date)
    .maybeSingle();
  return data as GratitudeEntry | null;
}

export async function fetchGratitudeEntries(
  userId: string,
  limit: number = 30
): Promise<GratitudeEntry[]> {
  const { data } = await supabase
    .from('gratitude_entries')
    .select('*')
    .eq('user_id', userId)
    .order('entry_date', { ascending: false })
    .limit(limit);
  return (data as GratitudeEntry[]) || [];
}

export async function upsertGratitudeEntry(
  userId: string,
  entry: { entry_date: string; content: string; mood?: string | null; tags?: string[] }
): Promise<GratitudeEntry | null> {
  const { data } = await supabase
    .from('gratitude_entries')
    .upsert({ user_id: userId, ...entry, updated_at: new Date().toISOString() })
    .select()
    .single();
  return data as GratitudeEntry | null;
}

export async function deleteGratitudeEntry(entryId: string): Promise<void> {
  await supabase.from('gratitude_entries').delete().eq('id', entryId);
}

export async function deleteAllGratitudeEntries(userId: string): Promise<void> {
  await supabase.from('gratitude_entries').delete().eq('user_id', userId);
}

// ============================================================
// Meditation Sessions
// ============================================================

export async function fetchMeditationSessions(
  userId: string,
  limit: number = 30
): Promise<MeditationSession[]> {
  const { data } = await supabase
    .from('meditation_sessions')
    .select('*')
    .eq('user_id', userId)
    .order('started_at', { ascending: false })
    .limit(limit);
  return (data as MeditationSession[]) || [];
}

export async function saveMeditationSession(
  userId: string,
  session: {
    meditation_type: string;
    duration: number;
    completed: boolean;
    mood_before?: string | null;
    mood_after?: string | null;
    reflection?: string | null;
    started_at: string;
    completed_at?: string | null;
  }
): Promise<MeditationSession | null> {
  const { data } = await supabase
    .from('meditation_sessions')
    .insert({ user_id: userId, ...session })
    .select()
    .single();
  return data as MeditationSession | null;
}

// ============================================================
// Habits
// ============================================================

export async function fetchHabits(userId: string): Promise<Habit[]> {
  const { data } = await supabase
    .from('habits')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  return (data as Habit[]) || [];
}

export async function insertHabit(
  habit: { name: string; type: 'good' | 'bad'; category?: string; frequency?: string }
): Promise<Habit | null> {
  const { data } = await supabase
    .from('habits')
    .insert(habit)
    .select()
    .single();
  return data as Habit | null;
}

export async function updateHabit(
  habitId: string,
  updates: Partial<Habit>
): Promise<Habit | null> {
  const { data } = await supabase
    .from('habits')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', habitId)
    .select()
    .single();
  return data as Habit | null;
}

export async function deleteHabit(habitId: string): Promise<void> {
  await supabase.from('habits').delete().eq('id', habitId);
}

// ============================================================
// Medical Documents
// ============================================================

export async function fetchMedicalDocuments(userId: string): Promise<MedicalDocument[]> {
  const { data } = await supabase
    .from('medical_documents')
    .select('*')
    .eq('user_id', userId)
    .order('upload_date', { ascending: false });
  return (data as MedicalDocument[]) || [];
}

export async function insertMedicalDocument(
  doc: {
    filename: string;
    file_path: string;
    file_type?: string;
    file_size?: number;
  }
): Promise<MedicalDocument | null> {
  const { data } = await supabase
    .from('medical_documents')
    .insert(doc)
    .select()
    .single();
  return data as MedicalDocument | null;
}

export async function updateMedicalDocument(
  docId: string,
  updates: Partial<MedicalDocument>
): Promise<MedicalDocument | null> {
  const { data } = await supabase
    .from('medical_documents')
    .update(updates)
    .eq('id', docId)
    .select()
    .single();
  return data as MedicalDocument | null;
}

export async function deleteMedicalDocument(
  docId: string,
  filePath: string
): Promise<void> {
  await supabase.storage.from('medical-docs').remove([filePath]);
  await supabase.from('medical_documents').delete().eq('id', docId);
}

export async function uploadMedicalFile(
  userId: string,
  file: File
): Promise<{ path: string; error: string | null }> {
  const filePath = `${userId}/${Date.now()}-${file.name}`;
  const { error } = await supabase.storage
    .from('medical-docs')
    .upload(filePath, file);
  return { path: filePath, error: error?.message || null };
}

// ============================================================
// Mood Entries
// ============================================================

export async function fetchTodayMood(userId: string): Promise<MoodEntry | null> {
  const today = new Date().toISOString().split('T')[0];
  const { data } = await supabase
    .from('mood_entries')
    .select('*')
    .eq('user_id', userId)
    .eq('entry_date', today)
    .maybeSingle();
  return data as MoodEntry | null;
}

export async function upsertMoodEntry(
  userId: string,
  entry: { mood: string; mood_score: number; note?: string }
): Promise<MoodEntry | null> {
  const today = new Date().toISOString().split('T')[0];
  const { data: existing } = await supabase
    .from('mood_entries')
    .select('id')
    .eq('user_id', userId)
    .eq('entry_date', today)
    .maybeSingle();

  if (existing) {
    const { data } = await supabase
      .from('mood_entries')
      .update({ ...entry, updated_at: new Date().toISOString() })
      .eq('id', existing.id)
      .select()
      .single();
    return data as MoodEntry | null;
  } else {
    const { data } = await supabase
      .from('mood_entries')
      .insert({ user_id: userId, entry_date: today, ...entry })
      .select()
      .single();
    return data as MoodEntry | null;
  }
}

export async function fetchRecentMoods(userId: string, days: number = 7): Promise<MoodEntry[]> {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days + 1);
  const startDateStr = startDate.toISOString().split('T')[0];

  const { data } = await supabase
    .from('mood_entries')
    .select('*')
    .eq('user_id', userId)
    .gte('entry_date', startDateStr)
    .order('entry_date', { ascending: true });
  return (data as MoodEntry[]) || [];
}

// ============================================================
// Diet Plans
// ============================================================

export async function fetchDietPlans(userId: string): Promise<DietPlan[]> {
  const { data } = await supabase
    .from('diet_plans')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  return (data as DietPlan[]) || [];
}

export async function insertDietPlan(
  plan: {
    plan_name: string;
    conditions: string[];
    description?: string;
    daily_calories?: number;
    meals?: unknown;
    restrictions?: string[];
    notes?: string;
  }
): Promise<DietPlan | null> {
  const { data } = await supabase
    .from('diet_plans')
    .insert(plan)
    .select()
    .single();
  return data as DietPlan | null;
}

export async function deleteDietPlan(planId: string): Promise<void> {
  await supabase.from('diet_plans').delete().eq('id', planId);
}
