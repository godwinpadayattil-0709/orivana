import type { MeditationOption } from '@/types';

export const MEDITATION_SESSIONS: MeditationOption[] = [
  {
    id: 'quick-reset',
    title: 'Quick Reset',
    duration: 120,
    category: '2 Minutes',
    description: 'A brief pause to reset your mind during a busy day.',
    guide: [
      { time: 0, text: 'Find a comfortable position. Close your eyes or soften your gaze.' },
      { time: 15, text: 'Take a slow, deep breath in through your nose. Count to four.' },
      { time: 30, text: 'Hold for a moment at the top of your breath.' },
      { time: 40, text: 'Slowly exhale through your mouth. Let your shoulders drop.' },
      { time: 55, text: 'Notice any tension in your body. With each exhale, release it.' },
      { time: 75, text: 'Take two more breaths at your own pace. In... and out.' },
      { time: 95, text: 'Gently bring your awareness back. Open your eyes when ready.' },
      { time: 115, text: 'Take this calm with you into the rest of your day.' },
    ],
  },
  {
    id: 'calm',
    title: 'Calm',
    duration: 300,
    category: '5 Minutes',
    description: 'Settle your nervous system and find a sense of inner stillness.',
    guide: [
      { time: 0, text: 'Find a comfortable seated position. Rest your hands gently.' },
      { time: 10, text: 'Close your eyes. Take a slow breath in through your nose.' },
      { time: 25, text: 'Hold for a moment. Then slowly breathe out through your mouth.' },
      { time: 40, text: 'Let your shoulders relax. Let your jaw soften.' },
      { time: 60, text: 'Continue breathing slowly. In for four counts, out for six.' },
      { time: 90, text: 'If your mind wanders, gently bring it back to your breath.' },
      { time: 120, text: 'Notice the feeling of the air entering and leaving your body.' },
      { time: 160, text: 'Let go of any thoughts about the past or future.' },
      { time: 200, text: 'Rest in this stillness. There is nothing to do right now.' },
      { time: 240, text: 'Slowly begin to deepen your breath. Wiggle your fingers.' },
      { time: 275, text: 'Gently open your eyes. Carry this calm with you.' },
      { time: 295, text: 'You are calm. You are present.' },
    ],
  },
  {
    id: 'deep-relaxation',
    title: 'Deep Relaxation',
    duration: 600,
    category: '10 Minutes',
    description: 'A longer practice to deeply relax body and mind.',
    guide: [
      { time: 0, text: 'Find a comfortable position, either seated or lying down.' },
      { time: 15, text: 'Close your eyes. Take three slow, deep breaths.' },
      { time: 45, text: 'Begin to notice your body. Start from the top of your head.' },
      { time: 75, text: 'Relax your forehead. Let the muscles around your eyes soften.' },
      { time: 105, text: 'Release your jaw. Let your tongue rest gently.' },
      { time: 135, text: 'Soften your shoulders, letting them drop away from your ears.' },
      { time: 165, text: 'Relax your arms, your hands, your fingertips.' },
      { time: 195, text: 'Feel your chest rising and falling with each breath.' },
      { time: 225, text: 'Let your belly be soft. Relax your lower back.' },
      { time: 260, text: 'Release tension in your hips, your thighs, your knees.' },
      { time: 300, text: 'Relax your calves, your feet, all the way to your toes.' },
      { time: 340, text: 'Your whole body is relaxed. Rest here in stillness.' },
      { time: 400, text: 'If thoughts arise, let them pass like clouds in the sky.' },
      { time: 460, text: 'You are safe. You are at peace. There is nowhere to be but here.' },
      { time: 520, text: 'Slowly begin to bring awareness back to your breath.' },
      { time: 560, text: 'Gently wiggle your fingers and toes. Take a deeper breath.' },
      { time: 585, text: 'When you are ready, softly open your eyes.' },
      { time: 598, text: 'Welcome back. You are deeply relaxed and restored.' },
    ],
  },
  {
    id: 'focus',
    title: 'Focus',
    duration: 600,
    category: '10 Minutes',
    description: 'Sharpen your concentration and clear mental fog.',
    guide: [
      { time: 0, text: 'Sit upright with a straight spine. Plant your feet firmly.' },
      { time: 15, text: 'Close your eyes. Take three energizing breaths.' },
      { time: 45, text: 'Bring your attention to the sensation of breathing.' },
      { time: 75, text: 'Notice the cool air at the tip of your nose as you inhale.' },
      { time: 105, text: 'Notice the warm air as you exhale. Stay with this sensation.' },
      { time: 150, text: 'When your mind wanders, simply note it and return to the breath.' },
      { time: 200, text: 'Each time you return, you are strengthening your focus.' },
      { time: 260, text: 'Let the breath be your anchor. Everything else can wait.' },
      { time: 320, text: 'If you feel restless, take one deep breath and settle back.' },
      { time: 380, text: 'Your mind is becoming clearer, sharper, more present.' },
      { time: 440, text: 'Continue with steady, even breaths. In and out.' },
      { time: 500, text: 'Begin to widen your awareness. Notice sounds around you.' },
      { time: 540, text: 'Take a deep breath in, and as you exhale, open your eyes.' },
      { time: 570, text: 'You are focused, clear, and ready for what is ahead.' },
      { time: 598, text: 'Carry this clarity into your next task.' },
    ],
  },
  {
    id: 'morning-start',
    title: 'Morning Start',
    duration: 300,
    category: '5 Minutes',
    description: 'Begin your day with intention and presence.',
    guide: [
      { time: 0, text: 'Good morning. Sit up tall and take a deep breath in.' },
      { time: 15, text: 'Exhale slowly. Let go of any lingering sleepiness.' },
      { time: 35, text: 'Take three full breaths. Inhale energy, exhale tension.' },
      { time: 70, text: 'Set an intention for today. What would you like to feel?' },
      { time: 110, text: 'Hold that intention as you continue breathing gently.' },
      { time: 160, text: 'Picture yourself moving through your day with ease.' },
      { time: 210, text: 'You have everything you need for this day.' },
      { time: 260, text: 'Take one more deep breath. Inhale possibility.' },
      { time: 285, text: 'Exhale and gently open your eyes. The day is yours.' },
    ],
  },
  {
    id: 'evening-wind-down',
    title: 'Evening Wind Down',
    duration: 300,
    category: '5 Minutes',
    description: 'Release the day and prepare for restful sleep.',
    guide: [
      { time: 0, text: 'Find a comfortable position. Let yourself settle in.' },
      { time: 15, text: 'Close your eyes. Take a slow breath in, and a longer breath out.' },
      { time: 40, text: 'Begin to let go of the day. Whatever happened, it is done.' },
      { time: 75, text: 'Release any tasks left undone. They will be there tomorrow.' },
      { time: 110, text: 'Soften your forehead. Relax your eyes and jaw.' },
      { time: 145, text: 'Let your shoulders drop. Feel the support beneath you.' },
      { time: 180, text: 'With each exhale, let your body grow heavier and more still.' },
      { time: 220, text: 'There is nothing more to do today. Only rest.' },
      { time: 260, text: 'Breathe gently. In... and out... slower and slower.' },
      { time: 285, text: 'Let yourself drift. Tomorrow is a new beginning.' },
    ],
  },
];

export const GRATITUDE_PROMPTS: string[] = [
  "What are three things you're grateful for today?",
  "Who made your day better today, and how?",
  "What is one small thing that made you smile?",
  "What went well today?",
  "What is something you often take for granted?",
  "What is a challenge that helped you grow?",
  "What is something beautiful you noticed today?",
  "What is a skill or ability you're thankful to have?",
  "Who in your life are you most grateful for right now?",
  "What is something about your body you appreciate today?",
  "What is a moment today when you felt at peace?",
  "What is something you're looking forward to?",
  "What is a kindness someone showed you recently?",
  "What is something you accomplished today, however small?",
  "What is a part of your home or surroundings that brings you comfort?",
];

export function getDailyPrompt(): string {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000
  );
  return GRATITUDE_PROMPTS[dayOfYear % GRATITUDE_PROMPTS.length];
}

export function getPromptForDate(dateStr: string): string {
  const date = new Date(dateStr);
  const dayOfYear = Math.floor(
    (date.getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 86400000
  );
  return GRATITUDE_PROMPTS[dayOfYear % GRATITUDE_PROMPTS.length];
}
