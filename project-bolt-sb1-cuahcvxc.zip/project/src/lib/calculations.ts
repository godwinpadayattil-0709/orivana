import type { DailyHealthLog, Goals, MetricProgress, DailyProgress } from '@/types';

export function calcPercent(current: number, goal: number): number {
  if (goal <= 0) return 0;
  return Math.min(Math.round((current / goal) * 100), 100);
}

export function getDailyProgress(
  log: DailyHealthLog | null,
  goals: Goals | null
): DailyProgress {
  const sleep: MetricProgress = {
    current: log?.sleep_hours ?? 0,
    goal: goals?.sleep_goal ?? 8,
    percent: calcPercent(log?.sleep_hours ?? 0, goals?.sleep_goal ?? 8),
    unit: 'hrs',
    label: 'Sleep',
  };
  const water: MetricProgress = {
    current: log?.water_amount ?? 0,
    goal: goals?.water_goal ?? 2.5,
    percent: calcPercent(log?.water_amount ?? 0, goals?.water_goal ?? 2.5),
    unit: 'L',
    label: 'Water',
  };
  const exercise: MetricProgress = {
    current: log?.exercise_minutes ?? 0,
    goal: goals?.exercise_goal ?? 45,
    percent: calcPercent(log?.exercise_minutes ?? 0, goals?.exercise_goal ?? 45),
    unit: 'min',
    label: 'Exercise',
  };
  const steps: MetricProgress = {
    current: log?.steps ?? 0,
    goal: goals?.steps_goal ?? 8000,
    percent: calcPercent(log?.steps ?? 0, goals?.steps_goal ?? 8000),
    unit: 'steps',
    label: 'Steps',
  };

  const overall = Math.round(
    (sleep.percent + water.percent + exercise.percent + steps.percent) / 4
  );

  return { sleep, water, exercise, steps, overall };
}

export function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

export function getAverages(logs: DailyHealthLog[]) {
  if (logs.length === 0) {
    return { sleep: 0, water: 0, exercise: 0, steps: 0 };
  }
  const sum = logs.reduce(
    (acc, log) => ({
      sleep: acc.sleep + (log.sleep_hours ?? 0),
      water: acc.water + (log.water_amount ?? 0),
      exercise: acc.exercise + (log.exercise_minutes ?? 0),
      steps: acc.steps + (log.steps ?? 0),
    }),
    { sleep: 0, water: 0, exercise: 0, steps: 0 }
  );
  return {
    sleep: Math.round((sum.sleep / logs.length) * 10) / 10,
    water: Math.round((sum.water / logs.length) * 10) / 10,
    exercise: Math.round((sum.exercise / logs.length) * 10) / 10,
    steps: Math.round(sum.steps / logs.length),
  };
}

export function getConsistency(logs: DailyHealthLog[], goals: Goals | null): {
  sleep: number;
  water: number;
  exercise: number;
  steps: number;
} {
  if (logs.length === 0 || !goals) {
    return { sleep: 0, water: 0, exercise: 0, steps: 0 };
  }
  const countGoalMet = (key: keyof DailyHealthLog, goal: number) =>
    logs.filter((log) => (log[key] as number) >= goal).length;

  return {
    sleep: Math.round((countGoalMet('sleep_hours', goals.sleep_goal) / logs.length) * 100),
    water: Math.round((countGoalMet('water_amount', goals.water_goal) / logs.length) * 100),
    exercise: Math.round((countGoalMet('exercise_minutes', goals.exercise_goal) / logs.length) * 100),
    steps: Math.round((countGoalMet('steps', goals.steps_goal) / logs.length) * 100),
  };
}

export function getStreak(logs: DailyHealthLog[]): number {
  if (logs.length === 0) return 0;
  const sorted = [...logs].sort((a, b) => b.log_date.localeCompare(a.log_date));
  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  if (sorted[0].log_date !== today && sorted[0].log_date !== yesterday) return 0;

  let streak = 0;
  let expectedDate = new Date(sorted[0].log_date);

  for (const log of sorted) {
    const logDate = new Date(log.log_date);
    if (logDate.toISOString().split('T')[0] === expectedDate.toISOString().split('T')[0]) {
      streak++;
      expectedDate = new Date(expectedDate.getTime() - 86400000);
    } else {
      break;
    }
  }
  return streak;
}

export function getWeeklyCompletion(
  logs: DailyHealthLog[],
  goals: Goals | null
): number[] {
  const days: number[] = [];
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    const log = logs.find((l) => l.log_date === dateStr);
    if (!log || !goals) {
      days.push(0);
    } else {
      const p = getDailyProgress(log, goals);
      days.push(p.overall);
    }
  }
  return days;
}
