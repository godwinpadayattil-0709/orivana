import { useEffect, useState, useRef, useCallback } from 'react';
import { Play, Pause, Square, RotateCcw, Loader2, Check, Wind, Volume2, VolumeX, Music, Music2 } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { fetchMeditationSessions, saveMeditationSession } from '@/lib/api';
import { MEDITATION_SESSIONS } from '@/lib/meditation-data';
import type { MeditationSession, MeditationOption } from '@/types';

const MOODS = [
  { value: 'sad', emoji: '😞' },
  { value: 'neutral', emoji: '😐' },
  { value: 'good', emoji: '🙂' },
  { value: 'happy', emoji: '😊' },
  { value: 'joyful', emoji: '😄' },
];

export function MeditationScreen() {
  const { user } = useAuth();
  const [activeSession, setActiveSession] = useState<MeditationOption | null>(null);
  const [sessions, setSessions] = useState<MeditationSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const s = await fetchMeditationSessions(user.id, 10);
      if (cancelled) return;
      setSessions(s);
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  if (activeSession) {
    return (
      <MeditationTimer
        session={activeSession}
        onExit={() => setActiveSession(null)}
        onComplete={async (duration: number, moodBefore: string | null, moodAfter: string | null, reflection: string | null) => {
          if (!user) return;
          await saveMeditationSession(user.id, {
            meditation_type: activeSession.id,
            duration,
            completed: true,
            mood_before: moodBefore,
            mood_after: moodAfter,
            reflection,
            started_at: new Date(Date.now() - duration * 1000).toISOString(),
            completed_at: new Date().toISOString(),
          });
          const s = await fetchMeditationSessions(user.id, 10);
          setSessions(s);
          setActiveSession(null);
        }}
      />
    );
  }

  const totalMinutes = sessions.reduce((sum, s) => sum + Math.round(s.duration / 60), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-app-primary">Meditation</h1>
        <p className="mt-1 text-sm font-medium text-app-tertiary">Find a moment of stillness</p>
      </div>

      {/* Stats */}
      {sessions.length > 0 && !loading && (
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-2xl border border-app-subtle glass p-4">
            <p className="text-2xl font-extrabold text-app-primary">{sessions.length}</p>
            <p className="mt-0.5 text-xs font-semibold text-app-muted">Sessions Completed</p>
          </div>
          <div className="rounded-2xl border border-app-subtle glass p-4">
            <p className="text-2xl font-extrabold text-app-primary">{totalMinutes}</p>
            <p className="mt-0.5 text-xs font-semibold text-app-muted">Total Minutes</p>
          </div>
        </div>
      )}

      {/* Session list */}
      <div className="space-y-3">
        {MEDITATION_SESSIONS.map((session) => (
          <button
            key={session.id}
            onClick={() => setActiveSession(session)}
            className="group flex w-full items-center gap-4 rounded-2xl border border-app-subtle glass p-5 text-left transition-all hover:border-accent/20 hover:bg-app-card-hover"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-accent/10 transition-transform group-hover:scale-110">
              <Wind className="h-6 w-6 text-accent" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-app-primary">{session.title}</span>
                <span className="rounded-md bg-white/[0.05] px-2 py-0.5 text-[10px] font-semibold text-accent">{session.category}</span>
              </div>
              <p className="mt-0.5 truncate text-xs text-app-tertiary">{session.description}</p>
            </div>
            <Play className="h-5 w-5 shrink-0 text-app-muted transition-colors group-hover:text-accent" />
          </button>
        ))}
      </div>

      {loading && (
        <div className="flex justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-accent" />
        </div>
      )}
    </div>
  );
}

// ============================================================
// Ambient music generator — soft, soothing tones via Web Audio
// ============================================================
class AmbientMusic {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private oscillators: OscillatorNode[] = [];
  private lfos: OscillatorNode[] = [];
  private running = false;

  start() {
    if (this.running) return;
    try {
      this.ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0;
      this.masterGain.connect(this.ctx.destination);

      // Fade in gently
      this.masterGain.gain.linearRampToValueAtTime(0.08, this.ctx.currentTime + 3);

      // Soft pad — layered sine waves at calming frequencies
      const freqs = [110, 164.81, 220, 329.63];
      const gains = [0.35, 0.25, 0.2, 0.12];

      freqs.forEach((freq, i) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        gain.gain.value = gains[i];

        // Slow LFO for gentle volume swells
        const lfo = this.ctx!.createOscillator();
        const lfoGain = this.ctx!.createGain();
        lfo.frequency.value = 0.05 + i * 0.03;
        lfoGain.gain.value = gains[i] * 0.4;
        lfo.connect(lfoGain);
        lfoGain.connect(gain.gain);

        osc.connect(gain);
        gain.connect(this.masterGain!);
        osc.start();
        lfo.start();
        this.oscillators.push(osc);
        this.lfos.push(lfo);
      });

      this.running = true;
    } catch {
      // Audio not available
    }
  }

  stop() {
    if (!this.running || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const master = this.masterGain;
    master.gain.linearRampToValueAtTime(0, ctx.currentTime + 2);
    setTimeout(() => {
      this.oscillators.forEach((o) => { try { o.stop(); } catch { /* */ } });
      this.lfos.forEach((o) => { try { o.stop(); } catch { /* */ } });
      this.oscillators = [];
      this.lfos = [];
      try { ctx.close(); } catch { /* */ }
      this.ctx = null;
      this.masterGain = null;
      this.running = false;
    }, 2100);
  }

  pause() {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 1);
    }
  }

  resume() {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.linearRampToValueAtTime(0.08, this.ctx.currentTime + 2);
    }
  }

  duck() {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.linearRampToValueAtTime(0.025, this.ctx.currentTime + 0.4);
    }
  }

  unduck() {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.linearRampToValueAtTime(0.08, this.ctx.currentTime + 0.8);
    }
  }
}

// ============================================================
// Voice guidance — browser speech synthesis with soft voice
// ============================================================
function speak(text: string, music?: { duck: () => void; unduck: () => void } | null) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.rate = 0.75;
  utter.pitch = 0.9;
  utter.volume = 0.7;

  // Try to find a soft, natural-sounding voice
  const voices = window.speechSynthesis.getVoices();
  const preferred = voices.find(v =>
    /samantha|google.*(uk|us).*(female|samantha)|zira|aria|jenny|female/i.test(v.name)
  ) || voices.find(v => v.lang.startsWith('en'));
  if (preferred) utter.voice = preferred;

  // Duck music while speaking, restore after
  if (music) {
    utter.onstart = () => music.duck();
    utter.onend = () => music.unduck();
    utter.onerror = () => music.unduck();
  }

  window.speechSynthesis.speak(utter);
}

function stopSpeaking() {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

// ============================================================
// Meditation Timer
// ============================================================

interface TimerProps {
  session: MeditationOption;
  onExit: () => void;
  onComplete: (duration: number, moodBefore: string | null, moodAfter: string | null, reflection: string | null) => void;
}

function MeditationTimer({ session, onExit, onComplete }: TimerProps) {
  const [elapsed, setElapsed] = useState(0);
  const [isRunning, setIsRunning] = useState(true);
  const [phase, setPhase] = useState<'meditating' | 'complete'>('meditating');
  const [moodBefore, setMoodBefore] = useState<string | null>(null);
  const [moodAfter, setMoodAfter] = useState<string | null>(null);
  const [reflection, setReflection] = useState('');
  const [saving, setSaving] = useState(false);
  const [voiceOn, setVoiceOn] = useState(true);
  const [musicOn, setMusicOn] = useState(true);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const spokenRef = useRef<Set<number>>(new Set());
  const musicRef = useRef<AmbientMusic | null>(null);
  const voiceOnRef = useRef(voiceOn);
  const musicOnRef = useRef(musicOn);

  // Keep refs in sync so callbacks see latest values
  useEffect(() => { voiceOnRef.current = voiceOn; }, [voiceOn]);
  useEffect(() => { musicOnRef.current = musicOn; }, [musicOn]);

  // Preload voices (some browsers load asynchronously)
  useEffect(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
    }
  }, []);

  const startTimer = useCallback(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setElapsed((prev) => {
        if (prev >= session.duration) {
          if (intervalRef.current) clearInterval(intervalRef.current);
          setIsRunning(false);
          setPhase('complete');
          return session.duration;
        }
        return prev + 1;
      });
    }, 1000);
  }, [session.duration]);

  useEffect(() => {
    startTimer();
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [startTimer]);

  // Start ambient music on mount
  useEffect(() => {
    if (musicOnRef.current) {
      musicRef.current = new AmbientMusic();
      musicRef.current.start();
    }
    return () => {
      stopSpeaking();
      musicRef.current?.stop();
      musicRef.current = null;
    };
  }, []);

  // Speak guide text at the right time
  useEffect(() => {
    if (phase !== 'meditating') return;
    const currentGuide = session.guide.filter((g) => g.time <= elapsed).pop();
    if (currentGuide && !spokenRef.current.has(currentGuide.time)) {
      spokenRef.current.add(currentGuide.time);
      if (voiceOnRef.current) {
        speak(currentGuide.text, musicOnRef.current ? musicRef.current : null);
      }
    }
  }, [elapsed, session.guide, phase]);

  // Speak completion message
  useEffect(() => {
    if (phase === 'complete') {
      stopSpeaking();
      if (voiceOnRef.current) {
        speak('Meditation complete. Gently bring your awareness back.', null);
      }
      musicRef.current?.stop();
    }
  }, [phase]);

  function handlePauseResume() {
    if (isRunning) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setIsRunning(false);
      stopSpeaking();
      musicRef.current?.pause();
    } else {
      startTimer();
      setIsRunning(true);
      musicRef.current?.resume();
    }
  }

  function handleRestart() {
    setElapsed(0);
    setPhase('meditating');
    setIsRunning(true);
    spokenRef.current.clear();
    stopSpeaking();
    startTimer();
    musicRef.current?.resume();
  }

  function handleEnd() {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setIsRunning(false);
    setPhase('complete');
  }

  function handleToggleVoice() {
    setVoiceOn((prev) => {
      const next = !prev;
      if (!next) stopSpeaking();
      return next;
    });
  }

  function handleToggleMusic() {
    setMusicOn((prev) => {
      const next = !prev;
      if (next && !musicRef.current) {
        musicRef.current = new AmbientMusic();
        musicRef.current.start();
      } else if (next && musicRef.current) {
        musicRef.current.resume();
      } else if (!next && musicRef.current) {
        musicRef.current.pause();
      }
      return next;
    });
  }

  function handleSaveReflection() {
    setSaving(true);
    onComplete(elapsed, moodBefore, moodAfter, reflection.trim() || null);
  }

  const remaining = session.duration - elapsed;
  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;
  const progress = (elapsed / session.duration) * 100;

  // Current guide text
  const currentGuide = session.guide.filter((g) => g.time <= elapsed).pop();
  const nextGuide = session.guide.find((g) => g.time > elapsed);

  // ============================================================
  // Complete screen
  // ============================================================

  if (phase === 'complete') {
    return (
      <div className="space-y-6">
        <div className="flex flex-col items-center py-8 text-center">
          <div className="relative mb-6">
            <div className="absolute inset-0 rounded-full bg-accent/20 blur-2xl breathe-animation" />
            <div className="relative flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-accent to-accent-dark shadow-xl shadow-accent/25">
              <Check className="h-9 w-9 text-zinc-950" />
            </div>
          </div>
          <h2 className="text-xl font-extrabold text-app-primary">Meditation complete</h2>
          <p className="mt-1.5 text-sm text-app-tertiary">
            {Math.round(elapsed / 60)} minutes · {session.title}
          </p>
        </div>

        <div className="space-y-4 rounded-2xl border border-app-subtle glass p-6">
          <div>
            <p className="mb-3 text-xs font-semibold tracking-wide text-app-tertiary uppercase">How do you feel now?</p>
            <div className="flex justify-center gap-3">
              {MOODS.map((m) => (
                <button
                  key={m.value}
                  onClick={() => setMoodAfter(moodAfter === m.value ? null : m.value)}
                  className={`flex flex-col items-center gap-1 rounded-xl border px-3 py-2 transition-all ${
                    moodAfter === m.value ? 'border-accent/30 bg-accent/10' : 'border-app-subtle bg-app-card'
                  }`}
                >
                  <span className="text-2xl">{m.emoji}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="mb-2 text-xs font-semibold tracking-wide text-app-tertiary uppercase">Optional reflection</p>
            <p className="mb-2 text-xs text-app-muted">"What changed, even slightly?"</p>
            <textarea
              value={reflection}
              onChange={(e) => setReflection(e.target.value)}
              placeholder="Write your thoughts..."
              rows={3}
              className="w-full resize-none rounded-xl border border-app-subtle bg-app-card px-4 py-3 text-sm text-app-primary placeholder-app-muted outline-none focus:border-accent/40"
            />
          </div>

          <button
            onClick={handleSaveReflection}
            disabled={saving}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 transition-all hover:brightness-110 disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
            {saving ? 'Saving...' : 'Save Reflection'}
          </button>

          <button
            onClick={onExit}
            className="w-full text-center text-xs font-semibold text-app-muted transition-colors hover:text-app-secondary"
          >
            Skip and exit
          </button>
        </div>
      </div>
    );
  }

  // ============================================================
  // Active meditation screen
  // ============================================================

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-app-primary">{session.title}</h2>
          <p className="text-xs text-app-muted">{session.category}</p>
        </div>
        <button
          onClick={handleEnd}
          className="flex items-center gap-1.5 rounded-xl border border-app-subtle px-3 py-2 text-xs font-semibold text-app-secondary transition-all hover:border-red-500/20 hover:text-red-400"
        >
          <Square className="h-3 w-3" />
          End
        </button>
      </div>

      {/* Timer circle */}
      <div className="flex flex-col items-center py-4">
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-accent/10 blur-3xl breathe-animation" />
          <svg width="220" height="220" className="-rotate-90">
            <circle cx="110" cy="110" r="100" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6" />
            <circle
              cx="110" cy="110" r="100" fill="none"
              stroke="url(#med-grad)" strokeWidth="6" strokeLinecap="round"
              strokeDasharray={2 * Math.PI * 100}
              strokeDashoffset={2 * Math.PI * 100 - (progress / 100) * 2 * Math.PI * 100}
              style={{ transition: 'stroke-dashoffset 1s linear' }}
            />
            <defs>
              <linearGradient id="med-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="var(--accent-light)" />
                <stop offset="100%" stopColor="var(--accent-dark)" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-4xl font-extrabold tabular-nums text-app-primary">
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </span>
            <span className="mt-1 text-xs font-semibold text-app-muted">
              {isRunning ? 'Breathing...' : 'Paused'}
            </span>
          </div>
        </div>
      </div>

      {/* Guide text */}
      <div className="rounded-2xl border border-app-subtle glass-strong p-6 text-center">
        <p className="text-sm leading-relaxed text-app-primary animate-fade-in" key={currentGuide?.time}>
          {currentGuide?.text || 'Continue breathing gently...'}
        </p>
        {nextGuide && isRunning && (
          <p className="mt-3 text-xs text-app-muted">Next guidance in {nextGuide.time - elapsed}s</p>
        )}
      </div>

      {/* Audio toggle controls */}
      <div className="flex items-center justify-center gap-3">
        <button
          onClick={handleToggleVoice}
          className={`flex items-center gap-2 rounded-xl border px-4 py-2.5 text-xs font-semibold transition-all ${
            voiceOn
              ? 'border-accent/30 bg-accent/10 text-accent'
              : 'border-app-subtle bg-app-card text-app-muted hover:text-app-secondary'
          }`}
        >
          {voiceOn ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          Voice
        </button>
        <button
          onClick={handleToggleMusic}
          className={`flex items-center gap-2 rounded-xl border px-4 py-2.5 text-xs font-semibold transition-all ${
            musicOn
              ? 'border-accent/30 bg-accent/10 text-accent'
              : 'border-app-subtle bg-app-card text-app-muted hover:text-app-secondary'
          }`}
        >
          {musicOn ? <Music className="h-4 w-4" /> : <Music2 className="h-4 w-4" />}
          Ambient
        </button>
      </div>

      {/* Mood before (first 10 seconds) */}
      {elapsed < 10 && (
        <div className="animate-fade-in rounded-2xl border border-app-subtle glass p-4">
          <p className="mb-2 text-center text-xs font-semibold text-app-tertiary">How are you feeling before we begin?</p>
          <div className="flex justify-center gap-2">
            {MOODS.map((m) => (
              <button
                key={m.value}
                onClick={() => setMoodBefore(moodBefore === m.value ? null : m.value)}
                className={`rounded-xl border px-2.5 py-1.5 text-lg transition-all ${
                  moodBefore === m.value ? 'border-accent/30 bg-accent/10' : 'border-app-subtle bg-app-card'
                }`}
              >
                {m.emoji}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Controls */}
      <div className="flex items-center justify-center gap-3">
        <button
          onClick={handleRestart}
          className="flex h-12 w-12 items-center justify-center rounded-2xl border border-app-subtle bg-app-card text-app-secondary transition-all hover:border-app-hover active:scale-90"
        >
          <RotateCcw className="h-5 w-5" />
        </button>
        <button
          onClick={handlePauseResume}
          className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-accent to-accent-dark text-zinc-950 shadow-lg shadow-accent/25 transition-all hover:brightness-110 active:scale-95"
        >
          {isRunning ? <Pause className="h-7 w-7" /> : <Play className="h-7 w-7 ml-0.5" />}
        </button>
        <button
          onClick={handleEnd}
          className="flex h-12 w-12 items-center justify-center rounded-2xl border border-app-subtle bg-app-card text-app-secondary transition-all hover:border-red-500/20 hover:text-red-400 active:scale-90"
        >
          <Square className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}
