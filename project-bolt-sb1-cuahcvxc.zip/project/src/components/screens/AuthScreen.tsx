import { useState } from 'react';
import { Loader2, Mail, Lock, Eye, EyeOff, ArrowRight, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/lib/auth';

export function AuthScreen() {
  const { signIn, signUp, resetPassword } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [forgotMode, setForgotMode] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!email || !password) {
      setError('Please enter your email and password');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    setLoading(true);
    const { error } = mode === 'signup' ? await signUp(email, password) : await signIn(email, password);
    setLoading(false);
    if (error) {
      setError(error);
    }
  }

  async function handleResetPassword(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!email) {
      setError('Please enter your email address');
      return;
    }
    setLoading(true);
    const { error } = await resetPassword(email);
    setLoading(false);
    if (error) {
      setError(error);
    } else {
      setResetSent(true);
    }
  }

  function exitForgotMode() {
    setForgotMode(false);
    setResetSent(false);
    setError(null);
  }

  // ============================================================
  // Forgot password screen
  // ============================================================
  if (forgotMode) {
    return (
      <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-app-primary px-6">
        <div className="pointer-events-none absolute -left-32 -top-32 h-96 w-96 rounded-full bg-accent/10 blur-[120px]" />
        <div className="pointer-events-none absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-accent/[0.08] blur-[120px]" />

        <div className="relative w-full max-w-sm animate-fade-in-up">
          <div className="mb-10 flex flex-col items-center">
            <div className="relative mb-5">
              <div className="absolute inset-0 rounded-3xl bg-accent/20 blur-xl" />
              <div className="relative flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-accent to-accent-dark shadow-xl shadow-accent/25">
                <svg viewBox="0 0 24 24" className="h-8 w-8 text-zinc-950" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M3 12h4l3-9 4 18 3-9h4" />
                </svg>
              </div>
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-app-primary">Orivana</h1>
          </div>

          <div className="glass rounded-3xl border border-app-subtle p-7">
            {resetSent ? (
              <div className="flex flex-col items-center text-center">
                <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-accent/15">
                  <CheckCircle2 className="h-7 w-7 text-accent" />
                </div>
                <h2 className="mb-2 text-lg font-bold text-app-primary">Check your email</h2>
                <p className="mb-6 text-sm leading-relaxed text-app-tertiary">
                  We've sent a password reset link to <span className="font-semibold text-app-secondary">{email}</span>. Click the link in the email to set a new password.
                </p>
                <button
                  onClick={exitForgotMode}
                  className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-accent/20 transition-all hover:brightness-110"
                >
                  Back to Login
                </button>
              </div>
            ) : (
              <>
                <div className="mb-6">
                  <button
                    onClick={exitForgotMode}
                    className="mb-4 flex items-center gap-1.5 text-xs font-semibold text-app-muted transition-colors hover:text-app-secondary"
                  >
                    <ArrowLeft className="h-3.5 w-3.5" />
                    Back
                  </button>
                  <h2 className="text-lg font-bold text-app-primary">Reset Password</h2>
                  <p className="mt-1.5 text-sm text-app-tertiary">
                    Enter your email and we'll send you a link to reset your password.
                  </p>
                </div>

                <form onSubmit={handleResetPassword} className="space-y-4">
                  <div>
                    <label htmlFor="reset-email" className="mb-2 block text-xs font-semibold tracking-wide text-app-secondary uppercase">
                      Email
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-app-muted" />
                      <input
                        id="reset-email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@example.com"
                        className="w-full rounded-2xl border border-app-subtle bg-app-card py-3.5 pl-11 pr-4 text-sm text-app-primary placeholder-app-muted outline-none transition-all focus:border-accent/40 focus:bg-white/[0.05] focus:ring-2 focus:ring-accent/15"
                        autoComplete="email"
                        autoFocus
                      />
                    </div>
                  </div>

                  {error && (
                    <div className="animate-fade-in rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-400">
                      {error}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={loading}
                    className="group flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-accent/20 transition-all duration-300 hover:shadow-xl hover:shadow-accent/30 hover:brightness-110 disabled:opacity-50"
                  >
                    {loading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        Send Reset Link
                        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                      </>
                    )}
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ============================================================
  // Login / Signup screen
  // ============================================================
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-app-primary px-6">
      {/* Ambient gradient orbs */}
      <div className="pointer-events-none absolute -left-32 -top-32 h-96 w-96 rounded-full bg-accent/10 blur-[120px]" />
      <div className="pointer-events-none absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-accent/[0.08] blur-[120px]" />
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-64 w-64 -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-500/5 blur-[100px]" />

      <div className="relative w-full max-w-sm animate-fade-in-up">
        {/* Logo */}
        <div className="mb-10 flex flex-col items-center">
          <div className="relative mb-5">
            <div className="absolute inset-0 rounded-3xl bg-accent/20 blur-xl" />
            <div className="relative flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-accent to-accent-dark shadow-xl shadow-accent/25">
              <svg viewBox="0 0 24 24" className="h-8 w-8 text-zinc-950" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 12h4l3-9 4 18 3-9h4" />
              </svg>
            </div>
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight text-app-primary">Orivana</h1>
          <p className="mt-2 text-sm font-medium text-app-muted">
            Your Daily Health & Wellness Companion
          </p>
        </div>

        {/* Card */}
        <div className="glass rounded-3xl border border-app-subtle p-7">
          {/* Tab switcher */}
          <div className="mb-6 flex gap-1 rounded-2xl bg-app-card p-1">
            <button
              onClick={() => { setMode('signup'); setError(null); }}
              className={`flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all duration-300 ${
                mode === 'signup' ? 'bg-app-card-hover text-app-primary shadow-sm' : 'text-app-muted hover:text-app-secondary'
              }`}
            >
              Sign Up
            </button>
            <button
              onClick={() => { setMode('login'); setError(null); }}
              className={`flex-1 rounded-xl py-2.5 text-sm font-semibold transition-all duration-300 ${
                mode === 'login' ? 'bg-app-card-hover text-app-primary shadow-sm' : 'text-app-muted hover:text-app-secondary'
              }`}
            >
              Log In
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="mb-2 block text-xs font-semibold tracking-wide text-app-secondary uppercase">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-app-muted" />
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full rounded-2xl border border-app-subtle bg-app-card py-3.5 pl-11 pr-4 text-sm text-app-primary placeholder-app-muted outline-none transition-all focus:border-accent/40 focus:bg-white/[0.05] focus:ring-2 focus:ring-accent/15"
                  autoComplete="email"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="mb-2 block text-xs font-semibold tracking-wide text-app-secondary uppercase">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-app-muted" />
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min. 6 characters"
                  className="w-full rounded-2xl border border-app-subtle bg-app-card py-3.5 pl-11 pr-11 text-sm text-app-primary placeholder-app-muted outline-none transition-all focus:border-accent/40 focus:bg-white/[0.05] focus:ring-2 focus:ring-accent/15"
                  autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-app-muted transition-colors hover:text-app-secondary"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Forgot password link — only on login mode */}
            {mode === 'login' && (
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => { setForgotMode(true); setError(null); }}
                  className="text-xs font-semibold text-app-muted transition-colors hover:text-accent"
                >
                  Forgot password?
                </button>
              </div>
            )}

            {error && (
              <div className="animate-fade-in rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-400">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="group flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-accent/20 transition-all duration-300 hover:shadow-xl hover:shadow-accent/30 hover:brightness-110 disabled:opacity-50"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  {mode === 'signup' ? 'Create Account' : 'Log In'}
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </>
              )}
            </button>
          </form>
        </div>

        <p className="mt-6 text-center text-xs font-medium text-app-muted">
          Your wellness data is private and secure.
        </p>
      </div>
    </div>
  );
}
