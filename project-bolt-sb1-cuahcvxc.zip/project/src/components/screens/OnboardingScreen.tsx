import { useState } from 'react';
import { User, Target, Loader2, ChevronRight, Moon, Droplets, Dumbbell, Footprints, Heart, Globe, MapPin, Check } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { upsertProfile, upsertGoals, upsertWellnessSettings } from '@/lib/api';
import { validateAge, validateWeight } from '@/lib/validation';

const COUNTRIES = [
  'United States', 'United Kingdom', 'Canada', 'Australia', 'India', 'Germany',
  'France', 'Japan', 'Brazil', 'Mexico', 'Italy', 'Spain', 'Netherlands',
  'Sweden', 'Norway', 'Denmark', 'Singapore', 'United Arab Emirates',
  'South Africa', 'Nigeria', 'China', 'South Korea', 'New Zealand',
  'Ireland', 'Belgium', 'Switzerland', 'Austria', 'Portugal', 'Other',
];

export function OnboardingScreen() {
  const { user, refreshProfile } = useAuth();
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [weight, setWeight] = useState('');

  const [country, setCountry] = useState('');
  const [countrySource, setCountrySource] = useState<'geo' | 'manual' | null>(null);
  const [detecting, setDetecting] = useState(false);

  const [waterGoal, setWaterGoal] = useState('2.5');
  const [sleepGoal, setSleepGoal] = useState('8');
  const [exerciseGoal, setExerciseGoal] = useState('45');
  const [stepsGoal, setStepsGoal] = useState('8000');

  const [wellnessOptIn, setWellnessOptIn] = useState<'yes' | 'no' | null>(null);

  const TOTAL_STEPS = 4;

  async function detectLocation() {
    setDetecting(true);
    setError(null);
    try {
      if (!navigator.geolocation) {
        throw new Error('Geolocation not supported by your browser');
      }
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          timeout: 10000,
          enableHighAccuracy: false,
        });
      });

      const { latitude, longitude } = position.coords;
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`,
        { headers: { 'Accept-Language': 'en' } }
      );

      if (!response.ok) throw new Error('Could not determine your location');
      const data = await response.json();
      const detectedCountry = data?.address?.country || '';

      if (detectedCountry) {
        const matched = COUNTRIES.find(
          (c) => c.toLowerCase() === detectedCountry.toLowerCase()
        ) || (detectedCountry === 'Other' ? '' : detectedCountry);
        setCountry(matched || detectedCountry);
        setCountrySource('geo');
      } else {
        throw new Error('Could not determine your country from location');
      }
    } catch {
      setError('Could not auto-detect your location. Please select your country manually.');
    } finally {
      setDetecting(false);
    }
  }

  async function handleFinish() {
    if (!user) return;
    setError(null);

    const ageNum = parseInt(age) || 0;
    const weightNum = parseFloat(weight) || 0;

    if (step === 0) {
      if (!name.trim()) { setError('Please enter your name'); return; }
      const ageCheck = validateAge(ageNum);
      if (!ageCheck.valid) { setError(ageCheck.error!); return; }
      const weightCheck = validateWeight(weightNum);
      if (!weightCheck.valid) { setError(weightCheck.error!); return; }
    }

    if (step === 1) {
      if (!country.trim()) {
        setError('Please select your country');
        return;
      }
    }

    if (step === 2 && wellnessOptIn === null) {
      setError('Please choose whether to include wellness features');
      return;
    }

    setLoading(true);
    try {
      if (step === 0) {
        await upsertProfile(user.id, { name: name.trim(), age: ageNum, weight: weightNum });
        setStep(1);
        detectLocation();
      } else if (step === 1) {
        await upsertProfile(user.id, { country: country.trim(), country_source: countrySource || 'manual' });
        setStep(2);
      } else if (step === 2) {
        setStep(3);
      } else {
        await upsertProfile(user.id, {
          name: name.trim(), age: ageNum, weight: weightNum,
          country: country.trim(), country_source: countrySource || 'manual',
        });
        await upsertGoals(user.id, {
          water_goal: parseFloat(waterGoal) || 2.5,
          sleep_goal: parseFloat(sleepGoal) || 8,
          exercise_goal: parseFloat(exerciseGoal) || 45,
          steps_goal: parseInt(stepsGoal) || 8000,
        });
        if (wellnessOptIn === 'yes') {
          await upsertWellnessSettings(user.id, {
            gratitude_enabled: true,
            meditation_enabled: true,
          });
        }
        await refreshProfile();
      }
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  const goalFields = [
    { icon: Moon, label: 'Water goal', unit: 'litres/day', value: waterGoal, onChange: setWaterGoal, color: 'var(--accent-light)' },
    { icon: Droplets, label: 'Sleep goal', unit: 'hours/night', value: sleepGoal, onChange: setSleepGoal, color: 'var(--accent-dark)' },
    { icon: Dumbbell, label: 'Exercise goal', unit: 'minutes/day', value: exerciseGoal, onChange: setExerciseGoal, color: 'var(--accent)' },
    { icon: Footprints, label: 'Steps goal', unit: 'steps/day', value: stepsGoal, onChange: setStepsGoal, color: 'var(--accent)' },
  ];

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-app-primary px-6">
      <div className="pointer-events-none absolute -left-32 -top-32 h-96 w-96 rounded-full bg-accent/[0.08] blur-[120px]" />
      <div className="pointer-events-none absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-accent/[0.06] blur-[120px]" />

      <div className="relative w-full max-w-md animate-fade-in-up">
        {/* Logo */}
        <div className="mb-6 flex items-center gap-3">
          <div className="relative flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-accent to-accent-dark shadow-lg shadow-accent/20">
            <svg viewBox="0 0 24 24" className="h-6 w-6 text-zinc-950" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 12h4l3-9 4 18 3-9h4" />
            </svg>
          </div>
          <div>
            <h1 className="text-lg font-extrabold tracking-tight text-app-primary">Orivana</h1>
            <p className="text-xs font-medium text-app-muted">Let's set up your profile</p>
          </div>
        </div>

        {/* Progress indicator */}
        <div className="mb-6 flex gap-1.5">
          {Array.from({ length: TOTAL_STEPS }).map((_, i) => (
            <div key={i} className={`h-1 flex-1 rounded-full transition-all duration-500 ${step >= i ? 'bg-accent' : 'bg-app-card'}`} />
          ))}
        </div>

        <div className="glass rounded-3xl border border-app-subtle p-7">
          {step === 0 ? (
            <>
              <div className="mb-6 flex items-center gap-2.5">
                <User className="h-5 w-5 text-accent" />
                <h2 className="text-base font-bold text-app-primary">About You</h2>
              </div>
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="mb-2 block text-xs font-semibold tracking-wide text-app-tertiary uppercase">Name</label>
                  <input id="name" type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name"
                    className="w-full rounded-2xl border border-app-subtle bg-app-card px-4 py-3.5 text-sm text-app-primary placeholder-app-muted outline-none transition-all focus:border-accent/40 focus:ring-2 focus:ring-accent/15" />
                </div>
                <div>
                  <label htmlFor="age" className="mb-2 block text-xs font-semibold tracking-wide text-app-tertiary uppercase">Age</label>
                  <input id="age" type="number" value={age} onChange={(e) => setAge(e.target.value)} placeholder="e.g. 28"
                    className="w-full rounded-2xl border border-app-subtle bg-app-card px-4 py-3.5 text-sm text-app-primary placeholder-app-muted outline-none transition-all focus:border-accent/40 focus:ring-2 focus:ring-accent/15" />
                </div>
                <div>
                  <label htmlFor="weight" className="mb-2 block text-xs font-semibold tracking-wide text-app-tertiary uppercase">Weight (kg)</label>
                  <input id="weight" type="number" step="0.1" value={weight} onChange={(e) => setWeight(e.target.value)} placeholder="e.g. 70"
                    className="w-full rounded-2xl border border-app-subtle bg-app-card px-4 py-3.5 text-sm text-app-primary placeholder-app-muted outline-none transition-all focus:border-accent/40 focus:ring-2 focus:ring-accent/15" />
                </div>
              </div>
            </>
          ) : step === 1 ? (
            <>
              <div className="mb-6 flex items-center gap-2.5">
                <Globe className="h-5 w-5 text-accent" />
                <h2 className="text-base font-bold text-app-primary">Your Location</h2>
              </div>
              <p className="mb-5 text-sm leading-relaxed text-app-secondary">
                We use your country to personalize diet plans with local cuisine and food preferences.
              </p>

              {/* Auto-detect button */}
              <button
                onClick={detectLocation}
                disabled={detecting}
                className="mb-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-accent/20 bg-accent/[0.07] py-3.5 text-sm font-semibold text-accent transition-all hover:border-accent/30 hover:bg-accent/10 disabled:opacity-50"
              >
                {detecting ? (
                  <><Loader2 className="h-4 w-4 animate-spin" /> Detecting your location...</>
                ) : (
                  <><MapPin className="h-4 w-4" /> Auto-detect my location</>
                )}
              </button>

              {countrySource === 'geo' && country && (
                <div className="mb-4 flex items-center gap-2 rounded-xl border border-accent/20 bg-accent/10 px-3 py-2.5 animate-fade-in">
                  <Check className="h-4 w-4 text-accent" />
                  <span className="text-sm font-semibold text-accent">Detected: {country}</span>
                </div>
              )}

              <div className="relative mb-2">
                <div className="absolute top-1/2 left-0 h-px w-full -translate-y-1/2 bg-app-subtle" />
                <span className="relative block py-1 text-center text-xs font-semibold text-app-muted">
                  <span className="bg-app-secondary px-3">or select manually</span>
                </span>
              </div>

              <select
                value={country}
                onChange={(e) => { setCountry(e.target.value); setCountrySource('manual'); }}
                className="w-full rounded-2xl border border-app-subtle bg-app-card px-4 py-3.5 text-sm text-app-primary outline-none transition-all focus:border-accent/40 focus:ring-2 focus:ring-accent/15"
              >
                <option value="">Select your country</option>
                {COUNTRIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </>
          ) : step === 2 ? (
            <>
              <div className="mb-6 flex items-center gap-2.5">
                <Heart className="h-5 w-5 text-accent" />
                <h2 className="text-base font-bold text-app-primary">Wellness Features</h2>
              </div>
              <p className="mb-5 text-sm leading-relaxed text-app-secondary">
                Would you like to include Gratitude & Meditation in your daily routine?
              </p>
              <div className="space-y-3">
                <button
                  onClick={() => { setWellnessOptIn('yes'); setError(null); }}
                  className={`flex w-full items-start gap-3 rounded-2xl border p-4 text-left transition-all ${
                    wellnessOptIn === 'yes' ? 'border-accent/30 bg-accent/10' : 'border-app-subtle bg-app-card hover:border-app-hover'
                  }`}
                >
                  <div className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 mt-0.5 ${wellnessOptIn === 'yes' ? 'border-accent bg-accent' : 'border-app-muted'}`}>
                    {wellnessOptIn === 'yes' && <svg viewBox="0 0 24 24" className="h-3 w-3 text-zinc-950" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-app-primary">Yes, enable it</p>
                    <p className="mt-0.5 text-xs text-app-tertiary">Daily gratitude prompts, guided meditation, and a reflection dashboard.</p>
                  </div>
                </button>
                <button
                  onClick={() => { setWellnessOptIn('no'); setError(null); }}
                  className={`flex w-full items-start gap-3 rounded-2xl border p-4 text-left transition-all ${
                    wellnessOptIn === 'no' ? 'border-app-hover bg-app-card' : 'border-app-subtle bg-app-card hover:border-app-hover'
                  }`}
                >
                  <div className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 mt-0.5 ${wellnessOptIn === 'no' ? 'border-app-secondary bg-app-secondary' : 'border-app-muted'}`}>
                    {wellnessOptIn === 'no' && <svg viewBox="0 0 24 24" className="h-3 w-3 text-zinc-950" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-app-primary">Not now</p>
                    <p className="mt-0.5 text-xs text-app-tertiary">You can enable this later in Settings anytime.</p>
                  </div>
                </button>
              </div>
            </>
          ) : (
            <>
              <div className="mb-6 flex items-center gap-2.5">
                <Target className="h-5 w-5 text-accent" />
                <h2 className="text-base font-bold text-app-primary">Daily Goals</h2>
              </div>
              <div className="space-y-3">
                {goalFields.map((field) => {
                  const Icon = field.icon;
                  return (
                    <div key={field.label} className="flex items-center gap-3 rounded-2xl border border-app-subtle bg-app-card px-4 py-3.5 transition-all hover:border-app-hover">
                      <div className="flex h-9 w-9 items-center justify-center rounded-xl" style={{ backgroundColor: `color-mix(in srgb, ${field.color} 12%, transparent)` }}>
                        <Icon className="h-4 w-4" style={{ color: field.color }} />
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-semibold text-app-primary">{field.label}</div>
                        <div className="text-xs text-app-muted">{field.unit}</div>
                      </div>
                      <input
                        type="number" step="0.1" value={field.value}
                        onChange={(e) => field.onChange(e.target.value)}
                        className="w-20 rounded-xl border border-app-subtle bg-app-card px-3 py-2.5 text-right text-sm font-bold text-app-primary outline-none transition-all focus:border-accent/40"
                      />
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {error && (
            <div className="mt-4 animate-fade-in rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-400">
              {error}
            </div>
          )}

          <button
            onClick={handleFinish}
            disabled={loading || detecting}
            className="group mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-accent/20 transition-all duration-300 hover:shadow-xl hover:shadow-accent/30 hover:brightness-110 disabled:opacity-50"
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            {step === 0 ? 'Continue' : step === 1 ? 'Continue' : step === 2 ? 'Continue' : 'Start Tracking'}
            {step < 3 && !loading && !detecting && <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />}
          </button>
        </div>
      </div>
    </div>
  );
}
