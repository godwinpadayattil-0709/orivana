import { useEffect, useState } from 'react';
import { Loader2, Check, BookOpen, Calendar, Search, Trash2, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import {
  fetchGratitudeEntry, upsertGratitudeEntry,
  fetchGratitudeEntries, deleteGratitudeEntry,
} from '@/lib/api';
import { getDailyPrompt, getPromptForDate } from '@/lib/meditation-data';
import type { GratitudeEntry } from '@/types';
import type { TabId } from '@/components/navigation/Navigation';

interface GratitudeScreenProps {
  initialView?: 'journal' | 'history';
  onNavigate?: (tab: TabId) => void;
}

const MOODS = [
  { value: 'sad', label: 'Sad', emoji: '😞' },
  { value: 'neutral', label: 'OK', emoji: '😐' },
  { value: 'good', label: 'Good', emoji: '🙂' },
  { value: 'happy', label: 'Happy', emoji: '😊' },
  { value: 'joyful', label: 'Joyful', emoji: '😄' },
];

export function GratitudeScreen({ initialView = 'journal' }: GratitudeScreenProps) {
  const [view, setView] = useState<'journal' | 'history'>(initialView);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-app-primary">Gratitude</h1>
          <p className="mt-1 text-sm font-medium text-app-tertiary">A daily moment of reflection</p>
        </div>
        <div className="flex gap-1 rounded-xl bg-app-card p-1">
          <ViewTab icon={BookOpen} label="Journal" active={view === 'journal'} onClick={() => setView('journal')} />
          <ViewTab icon={Calendar} label="History" active={view === 'history'} onClick={() => setView('history')} />
        </div>
      </div>

      {view === 'journal' ? <JournalView /> : <HistoryView />}
    </div>
  );
}

function ViewTab({ icon: Icon, label, active, onClick }: { icon: typeof BookOpen; label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold transition-all ${
        active ? 'bg-white/10 text-accent' : 'text-app-muted hover:text-app-secondary'
      }`}
    >
      <Icon className="h-3.5 w-3.5" />
      {label}
    </button>
  );
}

// ============================================================
// Journal View
// ============================================================

function JournalView() {
  const { user } = useAuth();
  const [entry, setEntry] = useState('');
  const [mood, setMood] = useState<string | null>(null);
  const [tags, setTags] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [existingId, setExistingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const today = new Date().toISOString().split('T')[0];
  const prompt = getDailyPrompt();

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const existing = await fetchGratitudeEntry(user.id, today);
      if (cancelled) return;
      if (existing) {
        setEntry(existing.content);
        setMood(existing.mood);
        setTags(existing.tags.join(', '));
        setExistingId(existing.id);
      }
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user, today]);

  async function handleSave() {
    if (!user) return;
    if (!entry.trim()) {
      setError('Please write something before saving.');
      return;
    }
    setError(null);
    setSaving(true);
    const tagArray = tags.split(',').map((t) => t.trim()).filter(Boolean);
    await upsertGratitudeEntry(user.id, {
      entry_date: today,
      content: entry.trim(),
      mood,
      tags: tagArray,
    });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  if (loading) {
    return (
      <div className="flex h-48 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Prompt */}
      <div className="rounded-2xl border border-app-subtle glass-strong p-6">
        <p className="text-xs font-bold tracking-wider text-accent uppercase">Today's Prompt</p>
        <p className="mt-2 text-lg font-semibold leading-relaxed text-app-primary">{prompt}</p>
        <p className="mt-2 text-xs text-app-muted">
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
          {existingId && ' · Entry started'}
        </p>
      </div>

      {/* Text area */}
      <div className="rounded-2xl border border-app-subtle glass p-5">
        <textarea
          value={entry}
          onChange={(e) => setEntry(e.target.value)}
          placeholder="Write freely... there is no right or wrong answer."
          rows={6}
          className="w-full resize-none rounded-xl border border-app-subtle bg-app-card px-4 py-3 text-sm leading-relaxed text-app-primary placeholder-app-muted outline-none transition-all focus:border-accent/40"
        />

        {/* Mood */}
        <div className="mt-4">
          <p className="mb-2 text-xs font-semibold tracking-wide text-app-tertiary uppercase">Mood (optional)</p>
          <div className="flex gap-2">
            {MOODS.map((m) => (
              <button
                key={m.value}
                onClick={() => setMood(mood === m.value ? null : m.value)}
                className={`flex flex-col items-center gap-1 rounded-xl border px-3 py-2 transition-all ${
                  mood === m.value
                    ? 'border-accent/30 bg-accent/10'
                    : 'border-app-subtle bg-app-card hover:border-app-hover'
                }`}
              >
                <span className="text-xl">{m.emoji}</span>
                <span className={`text-[10px] font-semibold ${mood === m.value ? 'text-accent' : 'text-app-muted'}`}>{m.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Tags */}
        <div className="mt-4">
          <p className="mb-2 text-xs font-semibold tracking-wide text-app-tertiary uppercase">Tags (optional)</p>
          <input
            type="text"
            value={tags}
            onChange={(e) => setTags(e.target.value)}
            placeholder="e.g. family, work, nature (comma separated)"
            className="w-full rounded-xl border border-app-subtle bg-app-card px-4 py-2.5 text-sm text-app-primary placeholder-app-muted outline-none focus:border-accent/40"
          />
        </div>

        {error && (
          <div className="mt-3 animate-fade-in rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-2.5 text-sm font-medium text-red-400">
            {error}
          </div>
        )}

        <button
          onClick={handleSave}
          disabled={saving}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-accent/20 transition-all hover:shadow-xl hover:shadow-accent/30 hover:brightness-110 disabled:opacity-50"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : saved ? <><Check className="h-4 w-4" /> Gratitude recorded. Take a moment to appreciate it.</> : 'Save Entry'}
        </button>
      </div>
    </div>
  );
}

// ============================================================
// History View
// ============================================================

function HistoryView() {
  const { user } = useAuth();
  const [entries, setEntries] = useState<GratitudeEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEntry, setSelectedEntry] = useState<GratitudeEntry | null>(null);
  const [currentMonth, setCurrentMonth] = useState(new Date());

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const e = await fetchGratitudeEntries(user.id, 90);
      if (cancelled) return;
      setEntries(e);
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  const filtered = entries.filter((e) => {
    if (!searchQuery) return true;
    return e.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
  });

  const entryDates = new Set(entries.map((e) => e.entry_date));

  // Streak calc
  let currentStreak = 0;
  let longestStreak = 0;
  if (entries.length > 0) {
    const sortedDates = entries.map((e) => e.entry_date).sort();
    let tempStreak = 1;
    for (let i = 1; i < sortedDates.length; i++) {
      const prev = new Date(sortedDates[i - 1]);
      const curr = new Date(sortedDates[i]);
      const diff = (curr.getTime() - prev.getTime()) / 86400000;
      if (diff === 1) {
        tempStreak++;
      } else {
        longestStreak = Math.max(longestStreak, tempStreak);
        tempStreak = 1;
      }
    }
    longestStreak = Math.max(longestStreak, tempStreak);

    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const sorted = [...entries].sort((a, b) => b.entry_date.localeCompare(a.entry_date));
    if (sorted[0]?.entry_date === today || sorted[0]?.entry_date === yesterday) {
      let expected = new Date(sorted[0].entry_date);
      for (const e of sorted) {
        if (e.entry_date === expected.toISOString().split('T')[0]) {
          currentStreak++;
          expected = new Date(expected.getTime() - 86400000);
        } else break;
      }
    }
  }

  async function handleDelete(entryId: string) {
    if (!user) return;
    await deleteGratitudeEntry(entryId);
    setEntries((prev) => prev.filter((e) => e.id !== entryId));
    setSelectedEntry(null);
  }

  // Calendar
  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthName = currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  if (loading) {
    return (
      <div className="flex h-48 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    );
  }

  if (entries.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <BookOpen className="mb-4 h-10 w-10 text-app-muted" />
        <p className="text-sm font-bold text-app-primary">No entries yet</p>
        <p className="mt-1 text-xs text-app-tertiary">Your gratitude history will appear here.</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <StatCard label="Total Entries" value={entries.length} />
        <StatCard label="Current Streak" value={`${currentStreak}d`} />
        <StatCard label="Longest Streak" value={`${longestStreak}d`} />
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-app-muted" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search entries or tags..."
          className="w-full rounded-xl border border-app-subtle bg-app-card py-2.5 pl-11 pr-4 text-sm text-app-primary placeholder-app-muted outline-none focus:border-accent/40"
        />
      </div>

      {/* Calendar */}
      <div className="rounded-2xl border border-app-subtle glass p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-bold text-app-primary">{monthName}</h3>
          <div className="flex gap-1">
            <button
              onClick={() => setCurrentMonth(new Date(year, month - 1, 1))}
              className="rounded-lg p-1.5 text-app-muted transition-colors hover:bg-white/[0.05] hover:text-app-primary"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={() => setCurrentMonth(new Date(year, month + 1, 1))}
              className="rounded-lg p-1.5 text-app-muted transition-colors hover:bg-white/[0.05] hover:text-app-primary"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-1.5">
          {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
            <div key={i} className="text-center text-[10px] font-bold text-app-muted">{d}</div>
          ))}
          {Array.from({ length: firstDay }).map((_, i) => (
            <div key={`empty-${i}`} />
          ))}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const day = i + 1;
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const hasEntry = entryDates.has(dateStr);
            return (
              <div
                key={day}
                className={`flex h-8 items-center justify-center rounded-lg text-xs font-semibold ${
                  hasEntry
                    ? 'bg-accent/15 text-accent'
                    : 'text-app-muted'
                }`}
              >
                {day}
              </div>
            );
          })}
        </div>
      </div>

      {/* Entry list */}
      <div className="space-y-3">
        {filtered.map((entry) => {
          const moodInfo = MOODS.find((m) => m.value === entry.mood);
          return (
            <button
              key={entry.id}
              onClick={() => setSelectedEntry(entry)}
              className="block w-full rounded-2xl border border-app-subtle glass p-4 text-left transition-all hover:border-app-hover"
            >
              <div className="mb-1.5 flex items-center justify-between">
                <span className="text-xs font-bold text-accent">
                  {new Date(entry.entry_date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                </span>
                {moodInfo && <span className="text-lg">{moodInfo.emoji}</span>}
              </div>
              <p className="line-clamp-2 text-sm text-app-secondary">{entry.content}</p>
              {entry.tags.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {entry.tags.slice(0, 4).map((tag) => (
                    <span key={tag} className="rounded-md bg-white/[0.05] px-2 py-0.5 text-[10px] font-medium text-app-tertiary">
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Entry detail modal */}
      {selectedEntry && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 md:items-center md:p-6" onClick={() => setSelectedEntry(null)}>
          <div className="w-full max-w-md rounded-t-3xl border border-app-subtle glass-strong p-6 md:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="text-sm font-bold text-accent">
                  {new Date(selectedEntry.entry_date).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
                </p>
                {(() => { const m = MOODS.find((m) => m.value === selectedEntry.mood); return m ? <p className="text-xs text-app-muted">{m.emoji} {m.label}</p> : null; })()}
              </div>
              <button onClick={() => setSelectedEntry(null)} className="rounded-lg p-1.5 text-app-muted hover:bg-white/[0.05]">
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="mb-2 text-xs font-semibold text-app-tertiary uppercase">{getPromptForDate(selectedEntry.entry_date)}</p>
            <p className="text-sm leading-relaxed text-app-primary">{selectedEntry.content}</p>
            {selectedEntry.tags.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {selectedEntry.tags.map((tag) => (
                  <span key={tag} className="rounded-md bg-white/[0.05] px-2.5 py-1 text-xs font-medium text-app-tertiary">{tag}</span>
                ))}
              </div>
            )}
            <button
              onClick={() => handleDelete(selectedEntry.id)}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/20 py-2.5 text-sm font-semibold text-red-400 transition-all hover:bg-red-500/10"
            >
              <Trash2 className="h-4 w-4" />
              Delete Entry
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-2xl border border-app-subtle glass p-4 text-center">
      <p className="text-2xl font-extrabold text-app-primary">{value}</p>
      <p className="mt-0.5 text-[10px] font-semibold text-app-muted">{label}</p>
    </div>
  );
}
