import { useEffect, useState } from 'react';
import { Moon, Droplets, Dumbbell, Footprints, Scale, Check, Loader2, Minus, Plus } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { fetchTodayLog, upsertDailyLog, fetchGoals } from '@/lib/api';
import { validateLogEntry } from '@/lib/validation';
import { calcPercent } from '@/lib/calculations';
import type { Goals } from '@/types';

export function TrackScreen() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [goals, setGoals] = useState<Goals | null>(null);

  const [sleep, setSleep] = useState('0');
  const [water, setWater] = useState('0');
  const [exercise, setExercise] = useState('0');
  const [steps, setSteps] = useState('0');
  const [weight, setWeight] = useState('');

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const [log, g] = await Promise.all([
        fetchTodayLog(user.id),
        fetchGoals(user.id),
      ]);
      if (cancelled) return;
      setGoals(g);
      if (log) {
        setSleep(String(log.sleep_hours ?? 0));
        setWater(String(log.water_amount ?? 0));
        setExercise(String(log.exercise_minutes ?? 0));
        setSteps(String(log.steps ?? 0));
        setWeight(log.weight ? String(log.weight) : '');
      }
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  async function handleSave() {
    if (!user) return;
    setError(null);

    const data = {
      sleep_hours: parseFloat(sleep) || 0,
      water_amount: parseFloat(water) || 0,
      exercise_minutes: parseFloat(exercise) || 0,
      steps: parseInt(steps) || 0,
      weight: weight ? parseFloat(weight) : null,
    };

    const validation = validateLogEntry(data);
    if (!validation.valid) {
      setError(validation.error!);
      return;
    }

    setSaving(true);
    try {
      await upsertDailyLog(user.id, data);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch {
      setError('Failed to save. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-app-muted" />
      </div>
    );
  }

  const goalMap = goals
    ? { sleep: goals.sleep_goal, water: goals.water_goal, exercise: goals.exercise_goal, steps: goals.steps_goal }
    : { sleep: 8, water: 2.5, exercise: 45, steps: 8000 };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-app-primary">Track Today</h1>
        <p className="mt-1 text-sm font-medium text-app-muted">
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </p>
      </div>

      <TrackField
        icon={Moon}
        label="Sleep"
        unit="hours"
        value={sleep}
        onChange={setSleep}
        step={0.1}
        min={0}
        max={24}
        color="var(--accent-dark)"
        goal={goalMap.sleep}
        presets={[{ label: '6h', value: '6' }, { label: '7h', value: '7' }, { label: '8h', value: '8' }]}
      />

      <TrackField
        icon={Droplets}
        label="Water"
        unit="litres"
        value={water}
        onChange={setWater}
        step={0.1}
        min={0}
        max={20}
        color="var(--accent-light)"
        goal={goalMap.water}
        presets={[{ label: '1L', value: '1' }, { label: '2L', value: '2' }, { label: '2.5L', value: '2.5' }]}
      />

      <TrackField
        icon={Dumbbell}
        label="Exercise"
        unit="minutes"
        value={exercise}
        onChange={setExercise}
        step={5}
        min={0}
        max={1440}
        color="var(--accent)"
        goal={goalMap.exercise}
        presets={[{ label: '15m', value: '15' }, { label: '30m', value: '30' }, { label: '45m', value: '45' }]}
      />

      <TrackField
        icon={Footprints}
        label="Steps"
        unit="steps"
        value={steps}
        onChange={setSteps}
        step={100}
        min={0}
        max={100000}
        color="var(--accent)"
        goal={goalMap.steps}
        presets={[{ label: '5K', value: '5000' }, { label: '8K', value: '8000' }, { label: '10K', value: '10000' }]}
      />

      <TrackField
        icon={Scale}
        label="Weight"
        unit="kg (optional)"
        value={weight}
        onChange={setWeight}
        step={0.1}
        min={0}
        max={500}
        color="var(--accent-light)"
        placeholder="Enter weight"
      />

      {error && (
        <div className="animate-fade-in rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-400">
          {error}
        </div>
      )}

      <button
        onClick={handleSave}
        disabled={saving}
        className="group flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-accent/20 transition-all duration-300 hover:shadow-xl hover:shadow-accent/30 hover:brightness-110 disabled:opacity-50"
      >
        {saving ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : saved ? (
          <>
            <Check className="h-4 w-4" />
            Saved Successfully
          </>
        ) : (
          `Save Today's Data`
        )}
      </button>
    </div>
  );
}

interface TrackFieldProps {
  icon: typeof Moon;
  label: string;
  unit: string;
  value: string;
  onChange: (v: string) => void;
  step: number;
  min: number;
  max: number;
  color: string;
  goal?: number;
  presets?: { label: string; value: string }[];
  placeholder?: string;
}

function TrackField({ icon: Icon, label, unit, value, onChange, step, min, max, color, goal, presets, placeholder }: TrackFieldProps) {
  const numValue = parseFloat(value) || 0;

  function adjust(delta: number) {
    const newVal = Math.min(Math.max(numValue + delta, min), max);
    onChange(String(Math.round(newVal * 10) / 10));
  }

  const percent = goal ? calcPercent(numValue, goal) : 0;

  return (
    <div className="rounded-2xl border border-app-subtle glass p-5 transition-all hover:border-app-hover">
      <div className="mb-3 flex items-center gap-2.5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl" style={{ backgroundColor: `color-mix(in srgb, ${color} 12%, transparent)` }}>
          <Icon className="h-[18px] w-[18px]" style={{ color }} />
        </div>
        <span className="text-sm font-bold text-app-primary">{label}</span>
        <span className="ml-auto text-xs font-medium text-app-muted">{unit}</span>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={() => adjust(-step)}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-app-card text-app-secondary transition-all hover:bg-app-card-hover active:scale-90"
        >
          <Minus className="h-4 w-4" />
        </button>
        <input
          type="number"
          step={step}
          min={min}
          max={max}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder || '0'}
          className="w-full rounded-xl border border-app-subtle bg-app-card px-4 py-2.5 text-center text-lg font-extrabold text-app-primary placeholder-app-muted outline-none transition-all focus:border-accent/40 focus:ring-2 focus:ring-accent/10"
        />
        <button
          onClick={() => adjust(step)}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-app-card text-app-secondary transition-all hover:bg-app-card-hover active:scale-90"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>

      {/* Live goal progress */}
      {goal !== undefined && goal > 0 && (
        <div className="mt-3">
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-app-card">
            <div
              className="h-full rounded-full transition-all duration-500 ease-out"
              style={{
                width: `${Math.min(percent, 100)}%`,
                background: `linear-gradient(90deg, ${color}, color-mix(in srgb, ${color} 67%, transparent))`,
              }}
            />
          </div>
          <div className="mt-1.5 flex items-center justify-between">
            <span className="text-[11px] font-semibold text-app-muted">
              {percent}% of {goal} {unit}
            </span>
            {percent >= 100 && (
              <span className="text-[11px] font-bold" style={{ color }}>Goal reached!</span>
            )}
          </div>
        </div>
      )}

      {presets && (
        <div className="mt-3 flex gap-2">
          {presets.map((p) => (
            <button
              key={p.label}
              onClick={() => onChange(p.value)}
              className="flex-1 rounded-xl bg-app-card py-2 text-xs font-semibold text-app-muted transition-all hover:bg-app-card-hover hover:text-app-secondary"
            >
              {p.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
