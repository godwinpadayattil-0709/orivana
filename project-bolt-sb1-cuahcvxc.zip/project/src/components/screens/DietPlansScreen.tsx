import { useEffect, useState } from 'react';
import { Loader2, Sparkles, Trash2, Utensils, Plus, X, AlertCircle, FileText, Target, ChevronDown, ChevronUp, ShieldAlert, Download, Check } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { fetchDietPlans, insertDietPlan, deleteDietPlan, fetchProfile } from '@/lib/api';
import { fetchMedicalDocuments } from '@/lib/api';
import type { DietPlan, DietMeal, MedicalDocument, Profile } from '@/types';

type SourceTab = 'medical' | 'user-needs';

const GOAL_OPTIONS = [
  { id: 'weight-loss', label: 'Weight Loss', icon: '📉', description: 'Calorie-controlled plan for sustainable weight loss' },
  { id: 'weight-gain', label: 'Weight Gain', icon: '📈', description: 'Calorie-surplus plan for healthy weight gain' },
  { id: 'diabetes', label: 'Diabetes Management', icon: '🩺', description: 'Low-glycemic foods to manage blood sugar' },
  { id: 'high-blood-pressure', label: 'High Blood Pressure', icon: '❤️', description: 'DASH diet to help lower blood pressure' },
  { id: 'cholesterol', label: 'Cholesterol Management', icon: '🫀', description: 'Heart-healthy plan to lower LDL cholesterol' },
  { id: 'pcos', label: 'PCOS Management', icon: '🌸', description: 'Anti-inflammatory, low-glycemic plan for PCOS' },
  { id: 'thyroid', label: 'Thyroid Support', icon: '🦋', description: 'Nutrient-dense plan supporting thyroid health' },
  { id: 'general-wellness', label: 'General Wellness', icon: '🌿', description: 'Balanced, nutrient-rich plan for overall health' },
];

const COMMON_ALLERGIES = [
  'Peanuts', 'Tree nuts', 'Dairy', 'Eggs', 'Shellfish', 'Fish', 'Wheat', 'Soy', 'Sesame', 'Gluten',
];

export function DietPlansScreen() {
  const { user } = useAuth();
  const [plans, setPlans] = useState<DietPlan[]>([]);
  const [docs, setDocs] = useState<MedicalDocument[]>([]);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<DietPlan | null>(null);
  const [activeTab, setActiveTab] = useState<SourceTab>('medical');

  // User needs form state
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);
  const [allergies, setAllergies] = useState<string[]>([]);
  const [customAllergy, setCustomAllergy] = useState('');
  const [showAllergyInput, setShowAllergyInput] = useState(false);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const [p, d, prof] = await Promise.all([
        fetchDietPlans(user.id),
        fetchMedicalDocuments(user.id),
        fetchProfile(user.id),
      ]);
      if (cancelled) return;
      setPlans(p);
      setDocs(d.filter((doc) => doc.analysis_status === 'analyzed' && doc.ai_conditions.length > 0));
      setProfile(prof);
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  async function handleGenerateFromDocs() {
    if (!user || docs.length === 0) return;
    setError(null);
    setGenerating(true);
    try {
      const allConditions = [...new Set(docs.flatMap((d) => d.ai_conditions))];
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-diet-plan`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          mode: 'medical',
          userId: user.id,
          conditions: allConditions,
          country: profile?.country || '',
          documents: docs.map((d) => ({
            filename: d.filename,
            summary: d.ai_summary,
            conditions: d.ai_conditions,
          })),
        }),
      });

      if (!response.ok) throw new Error('Failed to generate diet plan');

      const result = await response.json();
      const plan = await insertDietPlan({
        plan_name: result.plan_name || `${allConditions[0]} Diet Plan`,
        conditions: allConditions,
        description: result.description,
        daily_calories: result.daily_calories,
        meals: result.meals || [],
        restrictions: result.restrictions || [],
        notes: result.notes,
      });

      if (plan) {
        setPlans((prev) => [plan, ...prev]);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate diet plan');
    } finally {
      setGenerating(false);
    }
  }

  async function handleGenerateFromNeeds() {
    if (!user || selectedGoals.length === 0) return;
    setError(null);
    setGenerating(true);
    try {
      const goalLabels = selectedGoals.map((g) => GOAL_OPTIONS.find((opt) => opt.id === g)?.label || g);
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-diet-plan`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          mode: 'user-needs',
          userId: user.id,
          goals: selectedGoals,
          allergies,
          country: profile?.country || '',
        }),
      });

      if (!response.ok) throw new Error('Failed to generate diet plan');

      const result = await response.json();
      const plan = await insertDietPlan({
        plan_name: result.plan_name || `${goalLabels.join(' + ')} Diet Plan`,
        conditions: result.conditions || goalLabels,
        description: result.description,
        daily_calories: result.daily_calories,
        meals: result.meals || [],
        restrictions: result.restrictions || [],
        notes: result.notes,
      });

      if (plan) {
        setPlans((prev) => [plan, ...prev]);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate diet plan');
    } finally {
      setGenerating(false);
    }
  }

  async function handleDelete(planId: string) {
    await deleteDietPlan(planId);
    setPlans((prev) => prev.filter((p) => p.id !== planId));
    setSelectedPlan(null);
  }

  function toggleAllergy(allergy: string) {
    setAllergies((prev) =>
      prev.includes(allergy) ? prev.filter((a) => a !== allergy) : [...prev, allergy]
    );
  }

  function addCustomAllergy() {
    const trimmed = customAllergy.trim();
    if (trimmed && !allergies.includes(trimmed)) {
      setAllergies((prev) => [...prev, trimmed]);
    }
    setCustomAllergy('');
    setShowAllergyInput(false);
  }

  function removeAllergy(allergy: string) {
    setAllergies((prev) => prev.filter((a) => a !== allergy));
  }

  function handleDownloadPlan(plan: DietPlan) {
    const meals = (Array.isArray(plan.meals) ? plan.meals : []) as DietMeal[];
    const mealsHtml = meals.map((m) => `
      <div class="meal">
        <div class="meal-header">
          <div>
            <div class="meal-name">${m.name}</div>
            <div class="meal-time">${m.time || ''}</div>
          </div>
          ${m.calories ? `<div class="meal-cal">${m.calories} cal</div>` : ''}
        </div>
        ${Array.isArray(m.items) && m.items.length > 0 ? `<ul class="meal-items">${m.items.map((i) => `<li>${i}</li>`).join('')}</ul>` : ''}
      </div>`).join('');

    const restrictionsHtml = plan.restrictions.length > 0
      ? `<div class="section"><h3>Restrictions</h3><div class="restrictions">${plan.restrictions.map((r) => `<span class="restriction">${r}</span>`).join('')}</div></div>`
      : '';

    const conditionsHtml = plan.conditions.length > 0
      ? `<div class="conditions">${plan.conditions.map((c) => `<span class="condition">${c}</span>`).join('')}</div>`
      : '';

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${plan.plan_name}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f9fafb; color: #18181b; padding: 24px; line-height: 1.6; }
  .container { max-width: 700px; margin: 0 auto; background: white; border-radius: 24px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
  .header { background: linear-gradient(135deg, #14b8a6, #0d9488); color: white; padding: 40px 32px; }
  .header h1 { font-size: 24px; font-weight: 800; margin-bottom: 8px; }
  .header .date { font-size: 13px; opacity: 0.8; }
  .conditions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 16px; }
  .condition { background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 8px; font-size: 12px; font-weight: 600; }
  .body { padding: 32px; }
  .description { font-size: 14px; color: #52525b; margin-bottom: 24px; line-height: 1.7; }
  .calories-box { background: #f0fdfa; border: 1px solid #99f6e4; border-radius: 16px; padding: 20px; text-align: center; margin-bottom: 28px; }
  .calories-box .num { font-size: 32px; font-weight: 800; color: #0d9488; }
  .calories-box .label { font-size: 12px; font-weight: 600; color: #0d9488; opacity: 0.7; }
  .section { margin-bottom: 24px; }
  .section h3 { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #71717a; margin-bottom: 12px; }
  .meal { border: 1px solid #e4e4e7; border-radius: 12px; padding: 16px; margin-bottom: 10px; }
  .meal-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; }
  .meal-name { font-size: 15px; font-weight: 700; color: #18181b; }
  .meal-time { font-size: 11px; color: #a1a1aa; }
  .meal-cal { font-size: 13px; font-weight: 700; color: #0d9488; white-space: nowrap; }
  .meal-items { list-style: none; padding: 0; }
  .meal-items li { font-size: 13px; color: #52525b; padding: 2px 0; padding-left: 16px; position: relative; }
  .meal-items li::before { content: '\u2022'; position: absolute; left: 0; color: #0d9488; }
  .restrictions { display: flex; flex-wrap: wrap; gap: 8px; }
  .restriction { background: #fef2f2; color: #dc2626; padding: 4px 12px; border-radius: 8px; font-size: 12px; font-weight: 600; }
  .notes { background: #f4f4f5; border-radius: 12px; padding: 16px; font-size: 13px; color: #52525b; line-height: 1.7; }
  .disclaimer { margin-top: 24px; padding: 16px; background: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; font-size: 12px; color: #92400e; }
  @media print { body { background: white; padding: 0; } .container { box-shadow: none; max-width: 100%; } }
</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${plan.plan_name}</h1>
      <div class="date">Generated on ${new Date(plan.created_at).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
      ${conditionsHtml}
    </div>
    <div class="body">
      ${plan.description ? `<p class="description">${plan.description}</p>` : ''}
      ${plan.daily_calories ? `<div class="calories-box"><div class="num">${plan.daily_calories}</div><div class="label">CALORIES PER DAY</div></div>` : ''}
      ${mealsHtml ? `<div class="section"><h3>Daily Meals</h3>${mealsHtml}</div>` : ''}
      ${restrictionsHtml}
      ${plan.notes ? `<div class="section"><h3>Notes</h3><div class="notes">${plan.notes}</div></div>` : ''}
      <div class="disclaimer">This diet plan is AI-generated and for informational purposes only. It is not medical advice. Consult your doctor or a registered dietitian before making dietary changes.</div>
    </div>
  </div>
</body>
</html>`;

    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${plan.plan_name.replace(/[^a-z0-9]/gi, '_')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-app-primary">Diet Plans</h1>
        <p className="mt-1 text-sm font-medium text-app-tertiary">AI nutrition plans tailored to your health</p>
      </div>

      {/* Disclaimer */}
      <div className="flex items-start gap-2.5 rounded-2xl border border-amber-500/15 bg-amber-500/[0.04] px-4 py-3">
        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
        <p className="text-xs leading-relaxed text-app-tertiary">
          Diet plans are AI-generated suggestions, not medical advice. Consult your doctor before making dietary changes.
        </p>
      </div>

      {/* Source tabs */}
      <div className="flex gap-2 rounded-2xl border border-app-subtle glass p-1.5">
        <button
          onClick={() => { setActiveTab('medical'); setError(null); }}
          className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-bold transition-all ${
            activeTab === 'medical' ? 'bg-accent/15 text-accent' : 'text-app-muted hover:text-app-secondary'
          }`}
        >
          <FileText className="h-4 w-4" />
          From Medical Docs
        </button>
        <button
          onClick={() => { setActiveTab('user-needs'); setError(null); }}
          className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-bold transition-all ${
            activeTab === 'user-needs' ? 'bg-accent/15 text-accent' : 'text-app-muted hover:text-app-secondary'
          }`}
        >
          <Target className="h-4 w-4" />
          Based on My Needs
        </button>
      </div>

      {/* Medical docs mode */}
      {activeTab === 'medical' && (
        <div className="rounded-2xl border border-app-subtle glass p-5">
          <div className="mb-3 flex items-center gap-2.5">
            <Sparkles className="h-5 w-5 text-accent" />
            <h2 className="text-sm font-bold text-app-primary">Generate from Medical Reports</h2>
          </div>

          {docs.length > 0 ? (
            <>
              <p className="mb-3 text-xs text-app-tertiary">
                Based on your analyzed medical documents, the following conditions will inform your diet plan:
              </p>
              <div className="mb-4 flex flex-wrap gap-2">
                {[...new Set(docs.flatMap((d) => d.ai_conditions))].map((cond) => (
                  <span key={cond} className="rounded-md bg-accent/10 px-2.5 py-1 text-xs font-semibold text-accent">
                    {cond}
                  </span>
                ))}
              </div>
              <button
                onClick={handleGenerateFromDocs}
                disabled={generating}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-accent/20 transition-all hover:brightness-110 disabled:opacity-50"
              >
                {generating ? <><Loader2 className="h-4 w-4 animate-spin" /> Generating your plan...</> : <><Plus className="h-4 w-4" /> Generate Diet Plan</>}
              </button>
            </>
          ) : (
            <div className="flex flex-col items-center py-4 text-center">
              <FileText className="mb-2 h-8 w-8 text-app-muted" />
              <p className="text-xs text-app-muted">
                Upload and analyze medical documents first. Once conditions like diabetes, high blood pressure, or others are detected, a personalized diet plan can be generated.
              </p>
            </div>
          )}
        </div>
      )}

      {/* User needs mode */}
      {activeTab === 'user-needs' && (
        <div className="space-y-4">
          {/* Goal selection */}
          <div className="rounded-2xl border border-app-subtle glass p-5">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Target className="h-5 w-5 text-accent" />
                <h2 className="text-sm font-bold text-app-primary">Choose Your Health Goals</h2>
              </div>
              {selectedGoals.length > 0 && (
                <span className="rounded-md bg-accent/10 px-2 py-0.5 text-[10px] font-bold text-accent">
                  {selectedGoals.length} selected
                </span>
              )}
            </div>
            <p className="mb-3 text-xs text-app-tertiary">
              Select one or more goals. The AI will create a combined plan that works for all of them.
            </p>
            <div className="grid grid-cols-2 gap-2.5">
              {GOAL_OPTIONS.map((goal) => {
                const isSelected = selectedGoals.includes(goal.id);
                return (
                  <button
                    key={goal.id}
                    onClick={() => setSelectedGoals((prev) =>
                      prev.includes(goal.id)
                        ? prev.filter((g) => g !== goal.id)
                        : [...prev, goal.id]
                    )}
                    className={`flex flex-col items-start gap-1 rounded-xl border p-3 text-left transition-all ${
                      isSelected
                        ? 'border-accent/40 bg-accent/10'
                        : 'border-app-subtle bg-app-card hover:border-app-hover'
                    }`}
                  >
                    <div className="flex w-full items-center justify-between">
                      <span className="text-lg">{goal.icon}</span>
                      {isSelected && <Check className="h-3.5 w-3.5 text-accent" />}
                    </div>
                    <span className={`text-xs font-bold ${isSelected ? 'text-accent' : 'text-app-primary'}`}>
                      {goal.label}
                    </span>
                    <span className="text-[10px] leading-tight text-app-muted">{goal.description}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Allergies section */}
          <div className="rounded-2xl border border-app-subtle glass p-5">
            <div className="mb-3 flex items-center gap-2.5">
              <ShieldAlert className="h-5 w-5 text-accent" />
              <h2 className="text-sm font-bold text-app-primary">Food Allergies (Optional)</h2>
            </div>
            <p className="mb-3 text-xs text-app-tertiary">
              Select any food allergies you have. The AI will strictly avoid these in your diet plan.
            </p>

            {/* Selected allergies */}
            {allergies.length > 0 && (
              <div className="mb-3 flex flex-wrap gap-2">
                {allergies.map((allergy) => (
                  <span
                    key={allergy}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-red-500/10 px-2.5 py-1 text-xs font-semibold text-red-400"
                  >
                    {allergy}
                    <button onClick={() => removeAllergy(allergy)} className="hover:text-red-300">
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}

            {/* Common allergy chips */}
            <div className="flex flex-wrap gap-2">
              {COMMON_ALLERGIES.map((allergy) => {
                const selected = allergies.includes(allergy);
                return (
                  <button
                    key={allergy}
                    onClick={() => toggleAllergy(allergy)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                      selected
                        ? 'bg-red-500/15 text-red-400 border border-red-500/20'
                        : 'bg-white/[0.04] text-app-tertiary border border-app-subtle hover:border-app-hover'
                    }`}
                  >
                    {allergy}
                  </button>
                );
              })}
            </div>

            {/* Custom allergy input */}
            <div className="mt-3">
              {showAllergyInput ? (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customAllergy}
                    onChange={(e) => setCustomAllergy(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && addCustomAllergy()}
                    placeholder="e.g., Corn, Yeast, Sulfites..."
                    className="flex-1 rounded-xl border border-app-subtle bg-app-card px-3 py-2 text-xs text-app-primary placeholder:text-app-muted focus:border-accent/40 focus:outline-none"
                    autoFocus
                  />
                  <button
                    onClick={addCustomAllergy}
                    className="rounded-xl bg-accent/15 px-3 py-2 text-xs font-bold text-accent transition-all hover:bg-accent/25"
                  >
                    Add
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowAllergyInput(true)}
                  className="flex items-center gap-1.5 text-xs font-semibold text-accent transition-all hover:text-accent-light"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Add custom allergy
                </button>
              )}
            </div>
          </div>

          {/* Generate button */}
          <button
            onClick={handleGenerateFromNeeds}
            disabled={generating || selectedGoals.length === 0}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-accent/20 transition-all hover:brightness-110 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {generating ? <><Loader2 className="h-4 w-4 animate-spin" /> Generating your plan...</> : <><Sparkles className="h-4 w-4" /> Generate Diet Plan</>}
          </button>

          {selectedGoals.length === 0 && (
            <p className="text-center text-xs text-app-muted">Select one or more health goals above to generate your plan</p>
          )}
        </div>
      )}

      {error && (
        <div className="animate-fade-in rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-400">
          {error}
        </div>
      )}

      {/* Existing plans */}
      {plans.length === 0 && !loading ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <Utensils className="mb-3 h-10 w-10 text-app-muted" />
          <p className="text-sm font-bold text-app-primary">No diet plans yet</p>
          <p className="mt-1 text-xs text-app-tertiary">Generate one using either method above.</p>
        </div>
      ) : (
        <div className="space-y-3">
          <h2 className="text-xs font-bold tracking-wide text-app-tertiary uppercase">Your Plans</h2>
          {plans.map((plan) => (
            <button
              key={plan.id}
              onClick={() => setSelectedPlan(plan)}
              className="block w-full rounded-2xl border border-app-subtle glass p-5 text-left transition-all hover:border-accent/20"
            >
              <div className="mb-2 flex items-center gap-2">
                <Utensils className="h-4 w-4 text-accent" />
                <h3 className="text-sm font-bold text-app-primary">{plan.plan_name}</h3>
              </div>
              {plan.description && (
                <p className="line-clamp-2 text-xs text-app-tertiary">{plan.description}</p>
              )}
              <div className="mt-3 flex flex-wrap gap-1.5">
                {plan.conditions.map((cond) => (
                  <span key={cond} className="rounded-md bg-white/[0.05] px-2 py-0.5 text-[10px] font-medium text-app-tertiary">
                    {cond}
                  </span>
                ))}
                {plan.daily_calories && (
                  <span className="rounded-md bg-accent/10 px-2 py-0.5 text-[10px] font-bold text-accent">
                    {plan.daily_calories} cal/day
                  </span>
                )}
                {plan.restrictions.some((r) => r.includes('allergy')) && (
                  <span className="rounded-md bg-red-500/10 px-2 py-0.5 text-[10px] font-bold text-red-400">
                    Allergy-adapted
                  </span>
                )}
              </div>
              <p className="mt-2 text-[10px] text-app-muted">
                Created {new Date(plan.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              </p>
            </button>
          ))}
        </div>
      )}

      {/* Plan detail modal */}
      {selectedPlan && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 md:items-center md:p-6" onClick={() => setSelectedPlan(null)}>
          <div className="max-h-[85vh] w-full max-w-md overflow-y-auto rounded-t-3xl border border-app-subtle glass-strong p-6 md:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-base font-bold text-app-primary">{selectedPlan.plan_name}</h3>
              <button onClick={() => setSelectedPlan(null)} className="rounded-lg p-1.5 text-app-muted hover:bg-white/[0.05]">
                <X className="h-4 w-4" />
              </button>
            </div>

            {selectedPlan.description && (
              <p className="mb-4 text-sm leading-relaxed text-app-secondary">{selectedPlan.description}</p>
            )}

            {selectedPlan.daily_calories && (
              <div className="mb-4 rounded-xl bg-accent/10 px-4 py-3 text-center">
                <p className="text-2xl font-extrabold text-accent">{selectedPlan.daily_calories}</p>
                <p className="text-xs font-semibold text-accent/70">calories per day</p>
              </div>
            )}

            {/* Allergy warning banner */}
            {selectedPlan.restrictions.some((r) => r.includes('allergy')) && (
              <div className="mb-4 flex items-start gap-2.5 rounded-xl border border-red-500/20 bg-red-500/[0.06] px-4 py-3">
                <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
                <div>
                  <p className="text-xs font-bold text-red-400">Allergy-Adapted Plan</p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-app-tertiary">
                    This plan was customized to avoid your food allergies. Always double-check ingredient labels.
                  </p>
                </div>
              </div>
            )}

            {/* Meals */}
            {Array.isArray(selectedPlan.meals) && selectedPlan.meals.length > 0 && (
              <div className="mb-4 space-y-3">
                <h4 className="text-xs font-bold tracking-wide text-app-tertiary uppercase">Daily Meals</h4>
                {(selectedPlan.meals as DietMeal[]).map((meal, i) => (
                  <div key={i} className="rounded-xl border border-app-subtle bg-app-card p-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-bold text-app-primary">{meal.name}</p>
                        <p className="text-[10px] text-app-muted">{meal.time}</p>
                      </div>
                      {meal.calories && (
                        <span className="text-xs font-bold text-accent">{meal.calories} cal</span>
                      )}
                    </div>
                    {Array.isArray(meal.items) && (
                      <ul className="mt-2 space-y-0.5">
                        {meal.items.map((item, j) => (
                          <li key={j} className="text-xs text-app-tertiary">• {item}</li>
                        ))}
                      </ul>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Restrictions */}
            {selectedPlan.restrictions.length > 0 && (
              <div className="mb-4">
                <h4 className="mb-2 text-xs font-bold tracking-wide text-app-tertiary uppercase">Restrictions</h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedPlan.restrictions.map((r) => (
                    <span key={r} className="rounded-md bg-red-500/10 px-2 py-0.5 text-[10px] font-semibold text-red-400">Avoid: {r}</span>
                  ))}
                </div>
              </div>
            )}

            {selectedPlan.notes && (
              <div className="mb-4 rounded-xl border border-app-subtle bg-app-card p-3">
                <h4 className="mb-1 text-xs font-bold tracking-wide text-app-tertiary uppercase">Notes</h4>
                <p className="text-xs leading-relaxed text-app-secondary">{selectedPlan.notes}</p>
              </div>
            )}

            <div className="flex gap-2.5">
              <button
                onClick={() => handleDownloadPlan(selectedPlan)}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-accent to-accent-dark py-2.5 text-sm font-bold text-zinc-950 transition-all hover:brightness-110"
              >
                <Download className="h-4 w-4" />
                Download
              </button>
              <button
                onClick={() => handleDelete(selectedPlan.id)}
                className="flex items-center justify-center gap-2 rounded-xl border border-red-500/20 px-4 py-2.5 text-sm font-semibold text-red-400 transition-all hover:bg-red-500/10"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
