import { useEffect, useState } from 'react';
import { Moon, Droplets, Dumbbell, Footprints, Loader2, TrendingUp } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { fetchRecentLogs, fetchGoals } from '@/lib/api';
import { getAverages, getConsistency } from '@/lib/calculations';
import type { DailyHealthLog, Goals } from '@/types';
import { MiniChart } from '@/components/ui/MiniChart';

export function ProgressScreen() {
  const { user } = useAuth();
  const [logs, setLogs] = useState<DailyHealthLog[]>([]);
  const [goals, setGoals] = useState<Goals | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const [l, g] = await Promise.all([
        fetchRecentLogs(user.id, 7),
        fetchGoals(user.id),
      ]);
      if (cancelled) return;
      setLogs(l);
      setGoals(g);
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-app-muted" />
      </div>
    );
  }

  const avgs = getAverages(logs);
  const consistency = getConsistency(logs, goals);

  const labels = logs.map((log) => {
    const d = new Date(log.log_date);
    return d.toLocaleDateString('en-US', { weekday: 'short' }).slice(0, 2);
  });

  const statCards = [
    {
      icon: Moon,
      label: 'Sleep',
      avg: `${avgs.sleep} hrs`,
      goal: goals ? `${goals.sleep_goal} hrs` : '—',
      consistency: consistency.sleep,
      color: 'var(--accent-dark)',
      data: logs.map((l) => l.sleep_hours ?? 0),
      goalLine: goals?.sleep_goal,
    },
    {
      icon: Droplets,
      label: 'Water',
      avg: `${avgs.water} L`,
      goal: goals ? `${goals.water_goal} L` : '—',
      consistency: consistency.water,
      color: 'var(--accent-light)',
      data: logs.map((l) => l.water_amount ?? 0),
      goalLine: goals?.water_goal,
    },
    {
      icon: Dumbbell,
      label: 'Exercise',
      avg: `${avgs.exercise} min`,
      goal: goals ? `${goals.exercise_goal} min` : '—',
      consistency: consistency.exercise,
      color: 'var(--accent)',
      data: logs.map((l) => l.exercise_minutes ?? 0),
      goalLine: goals?.exercise_goal,
    },
    {
      icon: Footprints,
      label: 'Steps',
      avg: avgs.steps.toLocaleString(),
      goal: goals ? goals.steps_goal.toLocaleString() : '—',
      consistency: consistency.steps,
      color: 'var(--accent)',
      data: logs.map((l) => l.steps ?? 0),
      goalLine: goals?.steps_goal,
    },
  ];

  if (logs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-3xl border border-app-subtle glass">
          <TrendingUp className="h-7 w-7 text-app-muted" />
        </div>
        <h2 className="text-lg font-bold text-app-primary">No data yet</h2>
        <p className="mt-1.5 text-sm text-app-muted">Start logging your daily habits to see trends here.</p>
      </div>
    );
  }

  const overallConsistency = Math.round(
    (consistency.sleep + consistency.water + consistency.exercise + consistency.steps) / 4
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-app-primary">Progress</h1>
        <p className="mt-1 text-sm font-medium text-app-muted">Last 7 days at a glance</p>
      </div>

      {/* Overall consistency hero */}
      <div className="relative overflow-hidden rounded-2xl border border-app-subtle glass-strong p-6">
        <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-accent/[0.08] blur-[60px]" />
        <div className="relative flex items-center justify-between">
          <div>
            <p className="text-xs font-bold tracking-wider text-app-muted uppercase">Weekly Consistency</p>
            <p className="mt-1 text-4xl font-extrabold tracking-tight text-app-primary">{overallConsistency}%</p>
            <p className="mt-1 text-sm text-app-muted">{logs.length} days logged this week</p>
          </div>
          <div className="flex h-20 w-20 items-center justify-center rounded-2xl border border-app-subtle bg-app-card">
            <TrendingUp className="h-8 w-8 text-accent" />
          </div>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="rounded-2xl border border-app-subtle glass p-4 transition-all hover:border-app-hover">
              <div className="mb-2.5 flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ backgroundColor: `color-mix(in srgb, ${stat.color} 12%, transparent)` }}>
                  <Icon className="h-3.5 w-3.5" style={{ color: stat.color }} />
                </div>
                <span className="text-xs font-semibold text-app-muted">{stat.label}</span>
              </div>
              <p className="text-lg font-extrabold tracking-tight text-app-primary">{stat.avg}</p>
              <p className="text-xs text-app-muted">Goal: {stat.goal}</p>
              <p className="mt-1.5 text-xs font-bold" style={{ color: stat.consistency >= 70 ? stat.color : 'var(--text-muted)' }}>
                {stat.consistency}% consistent
              </p>
            </div>
          );
        })}
      </div>

      {/* Trend charts */}
      <div className="space-y-4">
        {statCards.map((stat) => (
          <div key={stat.label} className="rounded-2xl border border-app-subtle glass p-5">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ backgroundColor: `color-mix(in srgb, ${stat.color} 12%, transparent)` }}>
                  <stat.icon className="h-3.5 w-3.5" style={{ color: stat.color }} />
                </div>
                <span className="text-sm font-bold text-app-primary">{stat.label}</span>
                <span className="text-xs font-medium text-app-muted">— 7 Day Trend</span>
              </div>
              <span className="text-xs font-bold" style={{ color: stat.color }}>
                Avg {stat.avg}
              </span>
            </div>
            <MiniChart
              data={stat.data}
              labels={labels}
              color={stat.color}
              goal={stat.goalLine}
              height={140}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
