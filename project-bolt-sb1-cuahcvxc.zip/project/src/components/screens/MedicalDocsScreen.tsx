import { useEffect, useState, useRef } from 'react';
import { Upload, FileText, Loader2, Trash2, Sparkles, FileImage, AlertCircle, Download, RotateCw } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import {
  fetchMedicalDocuments, insertMedicalDocument,
  updateMedicalDocument, deleteMedicalDocument, uploadMedicalFile,
} from '@/lib/api';
import { supabase } from '@/lib/supabase';
import type { MedicalDocument } from '@/types';

export function MedicalDocsScreen() {
  const { user } = useAuth();
  const [docs, setDocs] = useState<MedicalDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [analyzingId, setAnalyzingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const d = await fetchMedicalDocuments(user.id);
      if (cancelled) return;
      setDocs(d);
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  async function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    if (!user || !e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    setError(null);

    if (file.size > 10 * 1024 * 1024) {
      setError('File too large. Maximum size is 10MB.');
      return;
    }

    setUploading(true);
    try {
      const { path, error: uploadError } = await uploadMedicalFile(user.id, file);
      if (uploadError) throw new Error(uploadError);

      const doc = await insertMedicalDocument({
        filename: file.name,
        file_path: path,
        file_type: file.type,
        file_size: file.size,
      });

      if (doc) {
        setDocs((prev) => [doc, ...prev]);
        // Trigger AI analysis
        setAnalyzingId(doc.id);
        try {
          const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-medical-doc`;
          const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            },
            body: JSON.stringify({
              docId: doc.id,
              userId: user.id,
              filename: file.name,
              fileType: file.type,
              filePath: path,
            }),
          });

          if (response.ok) {
            const result = await response.json();
            const updated = await updateMedicalDocument(doc.id, {
              ai_analysis: result.analysis,
              ai_conditions: result.conditions || [],
              ai_summary: result.summary,
              analysis_status: 'analyzed',
            });
            if (updated) {
              setDocs((prev) => prev.map((d) => d.id === updated.id ? updated : d));
            }
          } else {
            const errResult = await response.json().catch(() => ({}));
            setError(errResult.error || 'AI analysis failed. You can retry from the document card.');
            await updateMedicalDocument(doc.id, { analysis_status: 'failed' });
          }
        } catch {
          setError('Could not connect to analysis service. You can retry from the document card.');
          await updateMedicalDocument(doc.id, { analysis_status: 'failed' });
        } finally {
          setAnalyzingId(null);
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed. Please try again.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  async function handleDelete(doc: MedicalDocument) {
    await deleteMedicalDocument(doc.id, doc.file_path);
    setDocs((prev) => prev.filter((d) => d.id !== doc.id));
  }

  async function handleDownload(doc: MedicalDocument) {
    const { data } = await supabase.storage
      .from('medical-docs')
      .createSignedUrl(doc.file_path, 3600);
    if (data?.signedUrl) {
      window.open(data.signedUrl, '_blank');
    }
  }

  async function handleRetryAnalysis(doc: MedicalDocument) {
    if (!user) return;
    setAnalyzingId(doc.id);
    setError(null);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-medical-doc`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          docId: doc.id,
          userId: user.id,
          filename: doc.filename,
          fileType: doc.file_type,
          filePath: doc.file_path,
        }),
      });

      if (response.ok) {
        const result = await response.json();
        const updated = await updateMedicalDocument(doc.id, {
          ai_analysis: result.analysis,
          ai_conditions: result.conditions || [],
          ai_summary: result.summary,
          analysis_status: 'analyzed',
        });
        if (updated) {
          setDocs((prev) => prev.map((d) => d.id === updated.id ? updated : d));
        }
      } else {
        const errResult = await response.json().catch(() => ({}));
        setError(errResult.error || 'Analysis failed. Please try again.');
        await updateMedicalDocument(doc.id, { analysis_status: 'failed' });
      }
    } catch {
      setError('Could not connect to analysis service. Please try again.');
      await updateMedicalDocument(doc.id, { analysis_status: 'failed' });
    } finally {
      setAnalyzingId(null);
    }
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-app-primary">Medical Documents</h1>
        <p className="mt-1 text-sm font-medium text-app-tertiary">Upload reports for AI health insights</p>
      </div>

      {/* Privacy notice */}
      <div className="flex items-start gap-2.5 rounded-2xl border border-amber-500/15 bg-amber-500/[0.04] px-4 py-3">
        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
        <p className="text-xs leading-relaxed text-app-tertiary">
          Your documents are stored privately and encrypted. Only you can access them. AI analysis is for informational purposes only and is not a medical diagnosis.
        </p>
      </div>

      {/* Upload button */}
      <button
        onClick={() => fileInputRef.current?.click()}
        disabled={uploading}
        className="flex w-full flex-col items-center gap-3 rounded-2xl border-2 border-dashed border-app-subtle glass p-8 text-center transition-all hover:border-accent/20 hover:bg-app-card-hover disabled:opacity-50"
      >
        {uploading ? (
          <Loader2 className="h-8 w-8 animate-spin text-accent" />
        ) : (
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-accent/10">
            <Upload className="h-6 w-6 text-accent" />
          </div>
        )}
        <div>
          <p className="text-sm font-bold text-app-primary">
            {uploading ? 'Uploading...' : 'Upload Medical Report'}
          </p>
          <p className="mt-0.5 text-xs text-app-muted">Lab reports, MRI scans, blood work, prescriptions — PDF or image, max 10MB</p>
        </div>
      </button>
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.jpg,.jpeg,.png,.webp"
        onChange={handleFileSelect}
        className="hidden"
      />

      {error && (
        <div className="animate-fade-in rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-400">
          {error}
        </div>
      )}

      {/* Documents list */}
      {docs.length === 0 && !loading ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <FileText className="mb-3 h-10 w-10 text-app-muted" />
          <p className="text-sm font-bold text-app-primary">No documents uploaded yet</p>
          <p className="mt-1 text-xs text-app-tertiary">Upload a lab report or scan to get AI health insights.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {docs.map((doc) => {
            const isImage = doc.file_type?.startsWith('image/');
            const isAnalyzing = analyzingId === doc.id;
            return (
              <div key={doc.id} className="rounded-2xl border border-app-subtle glass p-4 transition-all hover:border-app-hover">
                <div className="flex items-start gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/[0.04]">
                    {isImage ? <FileImage className="h-5 w-5 text-app-tertiary" /> : <FileText className="h-5 w-5 text-app-tertiary" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="truncate text-sm font-bold text-app-primary">{doc.filename}</p>
                    <p className="text-xs text-app-muted">
                      {new Date(doc.upload_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      {' · '}
                      {doc.file_size > 1024 * 1024
                        ? `${(doc.file_size / 1024 / 1024).toFixed(1)} MB`
                        : `${Math.round(doc.file_size / 1024)} KB`}
                    </p>

                    {/* Status badge */}
                    <div className="mt-2">
                      {isAnalyzing && (
                        <span className="inline-flex items-center gap-1.5 rounded-md bg-accent/10 px-2 py-0.5 text-[10px] font-bold text-accent">
                          <Loader2 className="h-3 w-3 animate-spin" />
                          AI analyzing...
                        </span>
                      )}
                      {!isAnalyzing && doc.analysis_status === 'analyzed' && (
                        <span className="inline-flex items-center gap-1.5 rounded-md bg-accent/10 px-2 py-0.5 text-[10px] font-bold text-accent">
                          <Sparkles className="h-3 w-3" />
                          Analyzed
                        </span>
                      )}
                      {!isAnalyzing && doc.analysis_status === 'pending' && (
                        <span className="inline-flex items-center gap-1.5 rounded-md bg-amber-500/10 px-2 py-0.5 text-[10px] font-bold text-amber-400">
                          Pending
                        </span>
                      )}
                      {!isAnalyzing && doc.analysis_status === 'failed' && (
                        <div className="flex items-center gap-2">
                          <span className="inline-flex items-center gap-1.5 rounded-md bg-red-500/10 px-2 py-0.5 text-[10px] font-bold text-red-400">
                            Analysis failed
                          </span>
                          <button
                            onClick={() => handleRetryAnalysis(doc)}
                            className="inline-flex items-center gap-1 rounded-md bg-accent/10 px-2 py-0.5 text-[10px] font-bold text-accent transition-all hover:bg-accent/20"
                          >
                            <RotateCw className="h-3 w-3" />
                            Retry
                          </button>
                        </div>
                      )}
                    </div>

                    {/* AI Analysis */}
                    {doc.analysis_status === 'analyzed' && doc.ai_summary && (
                      <div className="mt-3 rounded-xl border border-app-subtle bg-app-card p-3">
                        <p className="text-[10px] font-bold tracking-wide text-accent uppercase">AI Summary</p>
                        <p className="mt-1 text-xs leading-relaxed text-app-secondary">{doc.ai_summary}</p>

                        {doc.ai_conditions.length > 0 && (
                          <div className="mt-2.5">
                            <p className="text-[10px] font-bold tracking-wide text-app-muted uppercase">Detected Conditions</p>
                            <div className="mt-1 flex flex-wrap gap-1.5">
                              {doc.ai_conditions.map((cond) => (
                                <span key={cond} className="rounded-md bg-accent/10 px-2 py-0.5 text-[10px] font-semibold text-accent">
                                  {cond}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {doc.ai_analysis && (
                          <div className="mt-2.5">
                            <p className="text-[10px] font-bold tracking-wide text-app-muted uppercase">Detailed Analysis</p>
                            <p className="mt-1 text-xs leading-relaxed text-app-tertiary">{doc.ai_analysis}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <button
                      onClick={() => handleDownload(doc)}
                      className="rounded-lg p-2 text-app-muted transition-colors hover:bg-white/[0.05] hover:text-accent"
                    >
                      <Download className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(doc)}
                      className="rounded-lg p-2 text-app-muted transition-colors hover:bg-red-500/10 hover:text-red-400"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
