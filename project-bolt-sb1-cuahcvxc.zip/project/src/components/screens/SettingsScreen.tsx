import { useEffect, useState } from 'react';
import { Sun, Moon, Monitor, Heart, Bell, Trash2, Loader2, Check, Info, Palette } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useTheme, type ThemeMode } from '@/lib/theme';
import { COLOR_THEMES } from '@/lib/theme-presets';
import {
  fetchWellnessSettings, upsertWellnessSettings,
  deleteAllGratitudeEntries,
} from '@/lib/api';
import type { WellnessSettings } from '@/types';

export function SettingsScreen() {
  const { user } = useAuth();
  const { theme, setTheme, colorThemeId, setColorThemeId } = useTheme();
  const [settings, setSettings] = useState<WellnessSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [clearingJournal, setClearingJournal] = useState(false);
  const [journalCleared, setJournalCleared] = useState(false);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const s = await fetchWellnessSettings(user.id);
      if (cancelled) return;
      setSettings(s);
      if (s?.theme_preference && s.theme_preference !== theme) {
        setTheme(s.theme_preference as ThemeMode);
      }
      if (s?.color_theme && s.color_theme !== colorThemeId) {
        setColorThemeId(s.color_theme);
      }
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  async function updateSettings(updates: Partial<WellnessSettings>) {
    if (!user) return;
    setSaving(true);
    setSaveError(null);
    try {
      const updated = await upsertWellnessSettings(user.id, updates);
      if (updated) {
        setSettings(updated);
      } else {
        setSaveError('Could not save settings. Please try again.');
      }
    } catch {
      setSaveError('Could not save settings. Please try again.');
    }
    setSaving(false);
  }

  async function handleThemeChange(mode: ThemeMode) {
    setTheme(mode);
    if (user) await updateSettings({ theme_preference: mode });
  }

  async function handleColorThemeChange(themeId: string) {
    setColorThemeId(themeId);
    if (user) await updateSettings({ color_theme: themeId });
  }

  async function handleClearJournal() {
    if (!user) return;
    setClearingJournal(true);
    try {
      await deleteAllGratitudeEntries(user.id);
      setJournalCleared(true);
      setTimeout(() => setJournalCleared(false), 2500);
    } catch {
      setSaveError('Could not delete entries. Please try again.');
    }
    setClearingJournal(false);
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    );
  }

  const gratitudeEnabled = settings?.gratitude_enabled ?? false;
  const meditationEnabled = settings?.meditation_enabled ?? false;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-app-primary">Settings</h1>
        <p className="mt-1 text-sm font-medium text-app-tertiary">Customize your experience</p>
      </div>

      {/* Appearance — Mode */}
      <Section title="Display Mode" icon={Sun}>
        <div className="grid grid-cols-3 gap-2">
          <ThemeButton icon={Sun} label="Light" active={theme === 'light'} onClick={() => handleThemeChange('light')} />
          <ThemeButton icon={Moon} label="Dark" active={theme === 'dark'} onClick={() => handleThemeChange('dark')} />
          <ThemeButton icon={Monitor} label="Auto" active={theme === 'auto'} onClick={() => handleThemeChange('auto')} />
        </div>
        <p className="mt-3 text-xs text-app-muted">
          Auto mode switches between light and dark based on the time of day — light during daytime hours, dark in the evening.
        </p>
      </Section>

      {/* Appearance — Color Theme */}
      <Section title="Color Theme" icon={Palette}>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {COLOR_THEMES.map((ct) => (
            <ColorThemeCard
              key={ct.id}
              name={ct.name}
              description={ct.description}
              swatch={ct.swatch}
              active={colorThemeId === ct.id}
              onClick={() => handleColorThemeChange(ct.id)}
            />
          ))}
        </div>
        <p className="mt-3 text-xs text-app-muted">
          Pick a color palette that suits your style. Your choice is saved and applied across all your devices.
        </p>
      </Section>

      {/* Wellness Features */}
      <Section title="Wellness Features" icon={Heart}>
        <ToggleRow
          label="Gratitude Journaling"
          description="Daily gratitude prompts and journal history"
          enabled={gratitudeEnabled}
          onToggle={() => updateSettings({ gratitude_enabled: !gratitudeEnabled })}
        />
        <ToggleRow
          label="Meditation"
          description="Guided meditation sessions with timer"
          enabled={meditationEnabled}
          onToggle={() => updateSettings({ meditation_enabled: !meditationEnabled })}
        />
      </Section>

      {/* Reminders (only show if features enabled) */}
      {(gratitudeEnabled || meditationEnabled) && (
        <Section title="Reminders" icon={Bell}>
          {gratitudeEnabled && (
            <>
              <ToggleRow
                label="Gratitude Reminder"
                description="Get a gentle nudge to write your daily gratitude"
                enabled={settings?.gratitude_reminder_enabled ?? false}
                onToggle={() => updateSettings({ gratitude_reminder_enabled: !settings?.gratitude_reminder_enabled })}
              />
              {settings?.gratitude_reminder_enabled && (
                <TimeSelectRow
                  label="Gratitude Reminder Time"
                  value={settings?.gratitude_reminder_time || '09:00'}
                  onChange={(v) => updateSettings({ gratitude_reminder_time: v })}
                />
              )}
            </>
          )}
          {meditationEnabled && (
            <>
              <ToggleRow
                label="Meditation Reminder"
                description="A reminder to take a mindful pause"
                enabled={settings?.meditation_reminder_enabled ?? false}
                onToggle={() => updateSettings({ meditation_reminder_enabled: !settings?.meditation_reminder_enabled })}
              />
              {settings?.meditation_reminder_enabled && (
                <TimeSelectRow
                  label="Meditation Reminder Time"
                  value={settings?.meditation_reminder_time || '20:00'}
                  onChange={(v) => updateSettings({ meditation_reminder_time: v })}
                />
              )}
            </>
          )}
          <div className="mt-3 flex items-start gap-2.5 rounded-xl border border-app-subtle bg-app-card p-3">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-app-muted" />
            <p className="text-xs text-app-muted">
              Reminders are stored in your settings. Browser notifications are not enabled automatically — you control when and how to be reminded.
            </p>
          </div>
        </Section>
      )}

      {/* Privacy & Data */}
      {gratitudeEnabled && (
        <Section title="Privacy & Data" icon={Trash2}>
          <div className="rounded-xl border border-red-500/15 bg-red-500/[0.04] p-4">
            <p className="text-sm font-semibold text-app-primary">Delete All Journal Entries</p>
            <p className="mt-1 text-xs text-app-tertiary">
              This permanently deletes all your gratitude journal entries. This action cannot be undone.
            </p>
            <p className="mt-1.5 text-xs text-app-muted">
              Your data is stored in an encrypted Supabase database, protected by Row Level Security — only you can access your entries.
            </p>
            <button
              onClick={handleClearJournal}
              disabled={clearingJournal}
              className="mt-3 rounded-xl border border-red-500/20 px-4 py-2 text-xs font-bold text-red-400 transition-all hover:bg-red-500/10 disabled:opacity-50"
            >
              {clearingJournal ? 'Deleting...' : journalCleared ? 'Deleted' : 'Delete All Entries'}
              {journalCleared && <Check className="ml-1 inline h-3 w-3" />}
            </button>
          </div>
        </Section>
      )}

      {saveError && (
        <div className="animate-fade-in rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-400">
          {saveError}
        </div>
      )}

      {saving && (
        <div className="flex items-center gap-2 text-xs text-app-muted">
          <Loader2 className="h-3 w-3 animate-spin" />
          Saving...
        </div>
      )}
    </div>
  );
}

function Section({ title, icon: Icon, children }: { title: string; icon: typeof Sun; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-app-subtle glass p-5">
      <div className="mb-4 flex items-center gap-2.5">
        <Icon className="h-5 w-5 text-accent" />
        <h2 className="text-sm font-bold text-app-primary">{title}</h2>
      </div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function ThemeButton({ icon: Icon, label, active, onClick }: { icon: typeof Sun; label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-2 rounded-xl border py-4 transition-all ${
        active
          ? 'border-accent/30 bg-accent/10'
          : 'border-app-subtle bg-app-card hover:border-app-hover'
      }`}
    >
      <Icon className={`h-5 w-5 ${active ? 'text-accent' : 'text-app-muted'}`} />
      <span className={`text-xs font-semibold ${active ? 'text-accent' : 'text-app-secondary'}`}>{label}</span>
    </button>
  );
}

function ToggleRow({ label, description, enabled, onToggle }: { label: string; description: string; enabled: boolean; onToggle: () => void }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="flex-1">
        <p className="text-sm font-semibold text-app-primary">{label}</p>
        <p className="mt-0.5 text-xs text-app-tertiary">{description}</p>
      </div>
      <button
        onClick={onToggle}
        className={`relative h-7 w-12 shrink-0 rounded-full transition-all duration-300 ${
          enabled ? 'bg-accent' : 'bg-white/[0.08]'
        }`}
      >
        <div className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow-md transition-all duration-300 ${enabled ? 'left-6' : 'left-1'}`} />
      </button>
    </div>
  );
}

function TimeSelectRow({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <p className="text-sm font-semibold text-app-primary">{label}</p>
      <input
        type="time"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-xl border border-app-subtle bg-app-card px-3 py-2 text-sm text-app-primary outline-none focus:border-accent/40"
      />
    </div>
  );
}

function ColorThemeCard({ name, description, swatch, active, onClick }: {
  name: string;
  description: string;
  swatch: string[];
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`group relative overflow-hidden rounded-2xl border p-3 text-left transition-all duration-300 ${
        active
          ? 'border-accent/40 ring-2 ring-accent/20'
          : 'border-app-subtle hover:border-app-hover'
      }`}
    >
      {active && (
        <div className="absolute right-2 top-2 flex h-5 w-5 items-center justify-center rounded-full bg-accent">
          <Check className="h-3 w-3 text-zinc-950" />
        </div>
      )}
      <div className="mb-2.5 flex gap-1.5">
        {swatch.map((color, i) => (
          <div
            key={i}
            className="h-8 w-8 rounded-lg transition-transform duration-300 group-hover:scale-110"
            style={{ backgroundColor: color }}
          />
        ))}
      </div>
      <p className={`text-xs font-bold ${active ? 'text-accent' : 'text-app-primary'}`}>{name}</p>
      <p className="mt-0.5 text-[10px] leading-tight text-app-muted line-clamp-2">{description}</p>
    </button>
  );
}
