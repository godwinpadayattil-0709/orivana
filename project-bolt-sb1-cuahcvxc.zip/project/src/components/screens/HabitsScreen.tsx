import { useEffect, useState } from 'react';
import { Plus, Trash2, Loader2, ThumbsUp, AlertTriangle, Sparkles, X } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { fetchHabits, insertHabit, updateHabit, deleteHabit } from '@/lib/api';
import type { Habit, HabitType, Criticality } from '@/types';

const HABIT_CATEGORIES = ['Diet', 'Exercise', 'Sleep', 'Substance', 'Mental', 'Hydration', 'Screen Time', 'Social', 'Other'];

const CRITICALITY_STYLES: Record<Criticality, { label: string; color: string; bg: string }> = {
  low: { label: 'Low Impact', color: 'var(--accent)', bg: 'color-mix(in srgb, var(--accent) 10%, transparent)' },
  medium: { label: 'Medium Impact', color: '#fbbf24', bg: 'rgba(251, 191, 36, 0.1)' },
  high: { label: 'High Impact', color: '#f87171', bg: 'rgba(248, 113, 113, 0.1)' },
};

export function HabitsScreen() {
  const { user } = useAuth();
  const [habits, setHabits] = useState<Habit[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newHabitName, setNewHabitName] = useState('');
  const [newHabitType, setNewHabitType] = useState<HabitType>('good');
  const [newHabitCategory, setNewHabitCategory] = useState('Diet');
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const h = await fetchHabits(user.id);
      if (cancelled) return;
      setHabits(h);
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  async function handleAddHabit() {
    if (!user || !newHabitName.trim()) return;
    const habit = await insertHabit({
      name: newHabitName.trim(),
      type: newHabitType,
      category: newHabitCategory,
    });
    if (habit) {
      setHabits((prev) => [habit, ...prev]);
      // Generate AI assessment
      setAnalyzing(true);
      try {
        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-habit`;
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            habitName: habit.name,
            habitType: habit.type,
            category: habit.category,
            userAge: null,
          }),
        });
        if (response.ok) {
          const result = await response.json();
          if (result.criticality || result.assessment || result.recommendation) {
            const updated = await updateHabit(habit.id, {
              criticality: result.criticality as Criticality,
              ai_assessment: result.assessment,
              ai_recommendation: result.recommendation,
            });
            if (updated) {
              setHabits((prev) => prev.map((h) => h.id === updated.id ? updated : h));
            }
          }
        }
      } catch {
        // Non-critical — habit is saved without AI assessment
      } finally {
        setAnalyzing(false);
      }
    }
    setNewHabitName('');
    setShowAddModal(false);
  }

  const [deleteError, setDeleteError] = useState<string | null>(null);

  async function handleDelete(habitId: string) {
    setDeleteError(null);
    try {
      await deleteHabit(habitId);
      setHabits((prev) => prev.filter((h) => h.id !== habitId));
    } catch {
      setDeleteError('Could not delete habit. Please try again.');
    }
  }

  const goodHabits = habits.filter((h) => h.type === 'good' && h.active);
  const badHabits = habits.filter((h) => h.type === 'bad' && h.active);

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-app-primary">Habits</h1>
          <p className="mt-1 text-sm font-medium text-app-tertiary">Track and assess your daily habits</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-accent to-accent-dark text-zinc-950 shadow-lg shadow-accent/20 transition-all hover:brightness-110 active:scale-90"
        >
          <Plus className="h-5 w-5" />
        </button>
      </div>

      {/* AI banner */}
      <div className="flex items-start gap-2.5 rounded-2xl border border-accent/10 bg-accent/[0.04] px-4 py-3">
        <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
        <p className="text-xs leading-relaxed text-app-tertiary">
          Each habit is assessed by AI for its health impact — good habits show benefits to continue, bad habits show risks and how to stop.
        </p>
      </div>

      {/* Good habits */}
      <div>
        <div className="mb-3 flex items-center gap-2">
          <ThumbsUp className="h-4 w-4 text-accent" />
          <h2 className="text-sm font-bold text-app-primary">Good Habits</h2>
          <span className="text-xs text-app-muted">({goodHabits.length})</span>
        </div>
        <div className="space-y-3">
          {goodHabits.length === 0 && (
            <p className="rounded-xl border border-app-subtle glass p-4 text-center text-xs text-app-muted">
              No good habits added yet. Tap + to add one.
            </p>
          )}
          {goodHabits.map((habit) => (
            <HabitCard key={habit.id} habit={habit} onDelete={() => handleDelete(habit.id)} />
          ))}
        </div>
      </div>

      {/* Bad habits */}
      <div>
        <div className="mb-3 flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-amber-400" />
          <h2 className="text-sm font-bold text-app-primary">Habits to Improve</h2>
          <span className="text-xs text-app-muted">({badHabits.length})</span>
        </div>
        <div className="space-y-3">
          {badHabits.length === 0 && (
            <p className="rounded-xl border border-app-subtle glass p-4 text-center text-xs text-app-muted">
              No bad habits tracked. Great — or add one to get AI guidance on breaking it.
            </p>
          )}
          {badHabits.map((habit) => (
            <HabitCard key={habit.id} habit={habit} onDelete={() => handleDelete(habit.id)} />
          ))}
        </div>
      </div>

      {deleteError && (
        <div className="animate-fade-in rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-400">
          {deleteError}
        </div>
      )}

      {/* Add habit modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 md:items-center md:p-6" onClick={() => setShowAddModal(false)}>
          <div className="w-full max-w-md rounded-t-3xl border border-app-subtle glass-strong p-6 md:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-base font-bold text-app-primary">Add a Habit</h3>
              <button onClick={() => setShowAddModal(false)} className="rounded-lg p-1.5 text-app-muted hover:bg-white/[0.05]">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-xs font-semibold tracking-wide text-app-tertiary uppercase">Habit Name</label>
                <input
                  type="text"
                  value={newHabitName}
                  onChange={(e) => setNewHabitName(e.target.value)}
                  placeholder="e.g. Morning walk, Smoking, 8 glasses of water"
                  className="w-full rounded-xl border border-app-subtle bg-app-card px-4 py-3 text-sm text-app-primary placeholder-app-muted outline-none focus:border-accent/40"
                  onKeyDown={(e) => e.key === 'Enter' && handleAddHabit()}
                />
              </div>

              <div>
                <label className="mb-2 block text-xs font-semibold tracking-wide text-app-tertiary uppercase">Type</label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setNewHabitType('good')}
                    className={`flex-1 rounded-xl border py-2.5 text-sm font-semibold transition-all ${
                      newHabitType === 'good' ? 'border-accent/30 bg-accent/10 text-accent' : 'border-app-subtle bg-app-card text-app-muted'
                    }`}
                  >
                    <ThumbsUp className="mr-1.5 inline h-3.5 w-3.5" />
                    Good Habit
                  </button>
                  <button
                    onClick={() => setNewHabitType('bad')}
                    className={`flex-1 rounded-xl border py-2.5 text-sm font-semibold transition-all ${
                      newHabitType === 'bad' ? 'border-amber-500/30 bg-amber-500/10 text-amber-400' : 'border-app-subtle bg-app-card text-app-muted'
                    }`}
                  >
                    <AlertTriangle className="mr-1.5 inline h-3.5 w-3.5" />
                    To Improve
                  </button>
                </div>
              </div>

              <div>
                <label className="mb-2 block text-xs font-semibold tracking-wide text-app-tertiary uppercase">Category</label>
                <div className="flex flex-wrap gap-2">
                  {HABIT_CATEGORIES.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setNewHabitCategory(cat)}
                      className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition-all ${
                        newHabitCategory === cat ? 'border-accent/30 bg-accent/10 text-accent' : 'border-app-subtle bg-app-card text-app-muted'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleAddHabit}
                disabled={!newHabitName.trim() || analyzing}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 transition-all hover:brightness-110 disabled:opacity-50"
              >
                {analyzing ? <><Loader2 className="h-4 w-4 animate-spin" /> AI analyzing...</> : <><Plus className="h-4 w-4" /> Add Habit</>}
              </button>
            </div>
          </div>
        </div>
      )}

      {analyzing && (
        <div className="flex items-center justify-center gap-2 text-xs text-app-muted">
          <Loader2 className="h-3 w-3 animate-spin" />
          AI is assessing your habit...
        </div>
      )}
    </div>
  );
}

function HabitCard({ habit, onDelete }: { habit: Habit; onDelete: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const crit = habit.criticality ? CRITICALITY_STYLES[habit.criticality] : null;
  const isGood = habit.type === 'good';

  return (
    <div
      className="rounded-2xl border border-app-subtle glass p-4 transition-all hover:border-app-hover"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0" onClick={() => setExpanded(!expanded)}>
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-app-primary">{habit.name}</span>
            <span className="rounded-md bg-white/[0.05] px-2 py-0.5 text-[10px] font-medium text-app-muted">{habit.category}</span>
          </div>
          <div className="mt-2 flex items-center gap-2">
            {crit ? (
              <span className="rounded-md px-2 py-0.5 text-[10px] font-bold" style={{ color: crit.color, backgroundColor: crit.bg }}>
                {crit.label}
              </span>
            ) : (
              <span className="rounded-md bg-white/[0.04] px-2 py-0.5 text-[10px] font-semibold text-app-muted">
                Pending analysis
              </span>
            )}
            <span className={`text-[10px] font-semibold ${isGood ? 'text-accent' : 'text-amber-400'}`}>
              {isGood ? 'Keep going' : 'Consider stopping'}
            </span>
          </div>
        </div>
        <button
          onClick={onDelete}
          className="shrink-0 rounded-lg p-2 text-app-muted transition-colors hover:bg-red-500/10 hover:text-red-400"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      {expanded && (habit.ai_assessment || habit.ai_recommendation) && (
        <div className="mt-3 space-y-2 border-t border-app-subtle pt-3">
          {habit.ai_assessment && (
            <div>
              <p className="text-[10px] font-bold tracking-wide text-app-muted uppercase">AI Assessment</p>
              <p className="mt-1 text-xs leading-relaxed text-app-secondary">{habit.ai_assessment}</p>
            </div>
          )}
          {habit.ai_recommendation && (
            <div>
              <p className="text-[10px] font-bold tracking-wide text-app-muted uppercase">Recommendation</p>
              <p className="mt-1 text-xs leading-relaxed text-app-secondary">{habit.ai_recommendation}</p>
            </div>
          )}
        </div>
      )}

      {expanded && !habit.ai_assessment && !habit.ai_recommendation && (
        <p className="mt-3 border-t border-app-subtle pt-3 text-xs text-app-muted">
          AI assessment not available yet. Try deleting and re-adding this habit to trigger a new analysis.
        </p>
      )}
    </div>
  );
}
