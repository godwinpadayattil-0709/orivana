import { useEffect, useState } from 'react';
import { User, Target, Loader2, Check, Edit3 } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { upsertProfile, upsertGoals, fetchGoals } from '@/lib/api';
import { validateAge, validateWeight } from '@/lib/validation';
import type { Goals } from '@/types';

export function ProfileScreen() {
  const { user, profile, refreshProfile } = useAuth();
  const [goals, setGoals] = useState<Goals | null>(null);
  const [loading, setLoading] = useState(true);
  const [editingProfile, setEditingProfile] = useState(false);
  const [editingGoals, setEditingGoals] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [weight, setWeight] = useState('');
  const [country, setCountry] = useState('');
  const [timezone, setTimezone] = useState('');

  const [waterGoal, setWaterGoal] = useState('2.5');
  const [sleepGoal, setSleepGoal] = useState('8');
  const [exerciseGoal, setExerciseGoal] = useState('45');
  const [stepsGoal, setStepsGoal] = useState('8000');

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const g = await fetchGoals(user.id);
      if (cancelled) return;
      setGoals(g);
      if (g) {
        setWaterGoal(String(g.water_goal));
        setSleepGoal(String(g.sleep_goal));
        setExerciseGoal(String(g.exercise_goal));
        setStepsGoal(String(g.steps_goal));
      }
      if (profile) {
        setName(profile.name || '');
        setAge(profile.age ? String(profile.age) : '');
        setWeight(profile.weight ? String(profile.weight) : '');
        setCountry(profile.country || '');
        setTimezone(profile.timezone || '');
      }
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user, profile]);

  async function handleSaveProfile() {
    if (!user) return;
    setError(null);
    const ageNum = parseInt(age) || 0;
    const weightNum = parseFloat(weight) || 0;
    if (age) {
      const ac = validateAge(ageNum);
      if (!ac.valid) { setError(ac.error!); return; }
    }
    if (weight) {
      const wc = validateWeight(weightNum);
      if (!wc.valid) { setError(wc.error!); return; }
    }
    setSaving(true);
    try {
      await upsertProfile(user.id, {
        name: name.trim(),
        age: ageNum || undefined,
        weight: weightNum || undefined,
        country: country || undefined,
        timezone: timezone || undefined,
      });
      await refreshProfile();
      setEditingProfile(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch {
      setError('Failed to save profile');
    } finally {
      setSaving(false);
    }
  }

  async function handleSaveGoals() {
    if (!user) return;
    setError(null);
    setSaving(true);
    try {
      const g = await upsertGoals(user.id, {
        water_goal: parseFloat(waterGoal) || 2.5,
        sleep_goal: parseFloat(sleepGoal) || 8,
        exercise_goal: parseFloat(exerciseGoal) || 45,
        steps_goal: parseInt(stepsGoal) || 8000,
      });
      setGoals(g);
      setEditingGoals(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch {
      setError('Failed to save goals');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-app-muted" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-accent to-accent-dark shadow-lg shadow-accent/20">
          <span className="text-2xl font-extrabold text-zinc-950">
            {(profile?.name || user?.email || '?').charAt(0).toUpperCase()}
          </span>
        </div>
        <div>
          <h1 className="text-xl font-extrabold tracking-tight text-app-primary">{profile?.name || 'Profile'}</h1>
          <p className="text-sm text-app-muted">{user?.email}</p>
        </div>
      </div>

      {/* Toasts */}
      {error && (
        <div className="animate-fade-in rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm font-medium text-red-400">
          {error}
        </div>
      )}

      {saved && (
        <div className="animate-fade-in flex items-center gap-2 rounded-xl border border-accent/20 bg-accent/10 px-4 py-3 text-sm font-medium text-accent">
          <Check className="h-4 w-4" />
          Saved successfully
        </div>
      )}

      {/* Profile section */}
      <div className="rounded-2xl border border-app-subtle glass p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <User className="h-5 w-5 text-accent" />
            <h2 className="text-sm font-bold text-app-primary">Personal Info</h2>
          </div>
          {!editingProfile && (
            <button
              onClick={() => setEditingProfile(true)}
              className="flex items-center gap-1 text-xs font-semibold text-app-muted transition-colors hover:text-accent"
            >
              <Edit3 className="h-3 w-3" />
              Edit
            </button>
          )}
        </div>

        {editingProfile ? (
          <div className="space-y-3">
            <EditField label="Name" value={name} onChange={setName} />
            <EditField label="Age" type="number" value={age} onChange={setAge} />
            <EditField label="Weight (kg)" type="number" step="0.1" value={weight} onChange={setWeight} />
            <SelectField label="Country" value={country} onChange={setCountry} options={COUNTRIES} placeholder="Select your country" />
            <SelectField label="Timezone" value={timezone} onChange={setTimezone} options={TIMEZONES} placeholder="Select your timezone" />
            <div className="flex gap-2 pt-2">
              <button
                onClick={handleSaveProfile}
                disabled={saving}
                className="flex-1 rounded-xl bg-gradient-to-r from-accent to-accent-dark py-2.5 text-sm font-bold text-zinc-950 transition-all hover:brightness-110 disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save'}
              </button>
              <button
                onClick={() => { setEditingProfile(false); setError(null); }}
                className="rounded-xl bg-app-card px-5 py-2.5 text-sm font-semibold text-app-secondary transition-all hover:bg-app-card-hover"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <InfoRow label="Name" value={profile?.name || '—'} />
            <InfoRow label="Age" value={profile?.age ? `${profile.age}` : '—'} />
            <InfoRow label="Weight" value={profile?.weight ? `${profile.weight} kg` : '—'} />
            <InfoRow label="Country" value={profile?.country || '—'} />
            <InfoRow label="Timezone" value={profile?.timezone ? formatTimezone(profile.timezone) : '—'} />
          </div>
        )}
      </div>

      {/* Goals section */}
      <div className="rounded-2xl border border-app-subtle glass p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Target className="h-5 w-5 text-accent" />
            <h2 className="text-sm font-bold text-app-primary">Daily Goals</h2>
          </div>
          {!editingGoals && (
            <button
              onClick={() => setEditingGoals(true)}
              className="flex items-center gap-1 text-xs font-semibold text-app-muted transition-colors hover:text-accent"
            >
              <Edit3 className="h-3 w-3" />
              Edit
            </button>
          )}
        </div>

        {editingGoals ? (
          <div className="space-y-3">
            <GoalEditRow label="Water" unit="L" value={waterGoal} onChange={setWaterGoal} />
            <GoalEditRow label="Sleep" unit="hrs" value={sleepGoal} onChange={setSleepGoal} />
            <GoalEditRow label="Exercise" unit="min" value={exerciseGoal} onChange={setExerciseGoal} />
            <GoalEditRow label="Steps" unit="steps" value={stepsGoal} onChange={setStepsGoal} />
            <div className="flex gap-2 pt-2">
              <button
                onClick={handleSaveGoals}
                disabled={saving}
                className="flex-1 rounded-xl bg-gradient-to-r from-accent to-accent-dark py-2.5 text-sm font-bold text-zinc-950 transition-all hover:brightness-110 disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save Goals'}
              </button>
              <button
                onClick={() => { setEditingGoals(false); setError(null); }}
                className="rounded-xl bg-app-card px-5 py-2.5 text-sm font-semibold text-app-secondary transition-all hover:bg-app-card-hover"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <InfoRow label="Water goal" value={goals ? `${goals.water_goal} L` : '—'} />
            <InfoRow label="Sleep goal" value={goals ? `${goals.sleep_goal} hrs` : '—'} />
            <InfoRow label="Exercise goal" value={goals ? `${goals.exercise_goal} min` : '—'} />
            <InfoRow label="Steps goal" value={goals ? goals.steps_goal.toLocaleString() : '—'} />
          </div>
        )}
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm font-medium text-app-muted">{label}</span>
      <span className="text-sm font-bold text-app-primary">{value}</span>
    </div>
  );
}

function EditField({ label, type = 'text', step, value, onChange }: {
  label: string;
  type?: string;
  step?: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-semibold tracking-wide text-app-secondary uppercase">{label}</label>
      <input
        type={type}
        step={step}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-app-subtle bg-app-card px-4 py-2.5 text-sm text-app-primary outline-none transition-all focus:border-accent/40 focus:ring-2 focus:ring-accent/15"
      />
    </div>
  );
}

function SelectField({ label, value, onChange, options, placeholder }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder: string;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-semibold tracking-wide text-app-secondary uppercase">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-app-subtle bg-app-card px-4 py-2.5 text-sm text-app-primary outline-none transition-all focus:border-accent/40 focus:ring-2 focus:ring-accent/15"
      >
        <option value="">{placeholder}</option>
        {options.map((o) => (
          <option key={o} value={o}>{o}</option>
        ))}
      </select>
    </div>
  );
}

function formatTimezone(tz: string): string {
  try {
    const offset = new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: 'shortOffset' }).formatToParts(new Date()).find(p => p.type === 'timeZoneName')?.value || '';
    return `${tz} (${offset})`;
  } catch {
    return tz;
  }
}

const COUNTRIES = [
  'United States', 'United Kingdom', 'Canada', 'Australia', 'India', 'Germany',
  'France', 'Japan', 'Brazil', 'Mexico', 'Italy', 'Spain', 'Netherlands',
  'Sweden', 'Norway', 'Denmark', 'Singapore', 'United Arab Emirates',
  'South Africa', 'Nigeria', 'China', 'South Korea', 'New Zealand',
  'Ireland', 'Belgium', 'Switzerland', 'Austria', 'Portugal', 'Other',
];

const TIMEZONES = [
  'Pacific/Honolulu', 'America/Anchorage', 'America/Los_Angeles', 'America/Denver',
  'America/Chicago', 'America/New_York', 'America/Halifax', 'America/Sao_Paulo',
  'Atlantic/Azores', 'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'Europe/Madrid',
  'Europe/Rome', 'Europe/Amsterdam', 'Europe/Stockholm', 'Europe/Oslo', 'Europe/Copenhagen',
  'Europe/Zurich', 'Europe/Austria', 'Europe/Dublin', 'Europe/Lisbon', 'Europe/Belgrade',
  'Europe/Warsaw', 'Europe/Athens', 'Europe/Istanbul', 'Africa/Cairo', 'Africa/Lagos',
  'Africa/Johannesburg', 'Africa/Nairobi', 'Asia/Dubai', 'Asia/Tehran', 'Asia/Karachi',
  'Asia/Kolkata', 'Asia/Dhaka', 'Asia/Bangkok', 'Asia/Singapore', 'Asia/Hong_Kong',
  'Asia/Shanghai', 'Asia/Seoul', 'Asia/Tokyo', 'Australia/Sydney', 'Australia/Melbourne',
  'Pacific/Auckland',
];

function GoalEditRow({ label, unit, value, onChange }: {
  label: string;
  unit: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div>
        <span className="text-sm font-semibold text-app-secondary">{label}</span>
        <span className="ml-1 text-xs text-app-muted">({unit})</span>
      </div>
      <input
        type="number"
        step="0.1"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-24 rounded-xl border border-app-subtle bg-app-card px-3 py-2.5 text-right text-sm font-bold text-app-primary outline-none transition-all focus:border-accent/40"
      />
    </div>
  );
}
