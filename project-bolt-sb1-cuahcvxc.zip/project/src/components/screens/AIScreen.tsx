import { useEffect, useState } from 'react';
import { Sparkles, Loader2, RefreshCw, AlertCircle, Info } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { fetchRecentLogs, fetchGoals, fetchLatestInsight, saveInsight } from '@/lib/api';
import { getAverages, getConsistency } from '@/lib/calculations';
import type { DailyHealthLog, Goals, AIInsight } from '@/types';

export function AIScreen() {
  const { user } = useAuth();
  const [logs, setLogs] = useState<DailyHealthLog[]>([]);
  const [goals, setGoals] = useState<Goals | null>(null);
  const [existing, setExisting] = useState<AIInsight | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const [l, g, i] = await Promise.all([
        fetchRecentLogs(user.id, 7),
        fetchGoals(user.id),
        fetchLatestInsight(user.id),
      ]);
      if (cancelled) return;
      setLogs(l);
      setGoals(g);
      setExisting(i);
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  async function handleGenerate() {
    if (!user || logs.length === 0) return;
    setError(null);
    setGenerating(true);
    try {
      const avgs = getAverages(logs);
      const consistency = getConsistency(logs, goals);

      const payload = {
        goals: goals ? {
          water: goals.water_goal,
          sleep: goals.sleep_goal,
          exercise: goals.exercise_goal,
          steps: goals.steps_goal,
        } : null,
        averages: avgs,
        consistency,
        daysLogged: logs.length,
        logs: logs.map((l) => ({
          date: l.log_date,
          sleep: l.sleep_hours,
          water: l.water_amount,
          exercise: l.exercise_minutes,
          steps: l.steps,
        })),
      };

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-insight`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ userId: user.id, data: payload }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate insights. Please try again.');
      }

      const result = await response.json();
      if (result.error) throw new Error(result.error);

      await saveInsight(user.id, {
        period_start: logs[0]?.log_date || new Date().toISOString().split('T')[0],
        period_end: logs[logs.length - 1]?.log_date || new Date().toISOString().split('T')[0],
        summary: result.summary || '',
        suggestions: result.suggestions || '',
      });

      const latest = await fetchLatestInsight(user.id);
      setExisting(latest);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong');
    } finally {
      setGenerating(false);
    }
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-app-muted" />
      </div>
    );
  }

  const hasData = logs.length > 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-app-primary">AI Insights</h1>
        <p className="mt-1 text-sm font-medium text-app-muted">Personalized summary of your week</p>
      </div>

      {/* Disclaimer */}
      <div className="flex items-start gap-2.5 rounded-2xl border border-amber-500/15 bg-amber-500/[0.06] px-4 py-3">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
        <p className="text-xs font-medium leading-relaxed text-amber-400/80">
          AI insights are based on your logged wellness data and are not medical advice.
        </p>
      </div>

      {/* Empty state */}
      {!hasData && (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="relative mb-5">
            <div className="absolute inset-0 rounded-3xl bg-accent/10 blur-xl" />
            <div className="relative flex h-16 w-16 items-center justify-center rounded-3xl border border-app-subtle glass">
              <Sparkles className="h-7 w-7 text-app-muted" />
            </div>
          </div>
          <h2 className="text-lg font-bold text-app-primary">No data to analyze yet</h2>
          <p className="mt-1.5 text-sm text-app-muted">Log your habits for a few days, then come back for AI insights.</p>
        </div>
      )}

      {/* Existing insight */}
      {hasData && existing && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="relative overflow-hidden rounded-2xl border border-app-subtle glass-strong p-6">
            <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-accent/[0.08] blur-[60px]" />
            <div className="relative">
              <div className="mb-3 flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-accent/10">
                  <Sparkles className="h-4 w-4 text-accent" />
                </div>
                <h3 className="text-sm font-bold text-app-primary">Weekly Summary</h3>
              </div>
              <p className="text-sm leading-relaxed text-app-secondary">{existing.summary}</p>
            </div>
          </div>

          {existing.suggestions && (
            <div className="rounded-2xl border border-app-subtle glass p-6">
              <div className="mb-3 flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-cyan-500/10">
                  <svg viewBox="0 0 24 24" className="h-4 w-4 text-cyan-400" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
                  </svg>
                </div>
                <h3 className="text-sm font-bold text-app-primary">Suggestions</h3>
              </div>
              <p className="text-sm leading-relaxed text-app-secondary">{existing.suggestions}</p>
            </div>
          )}

          <p className="text-center text-xs font-medium text-app-muted">
            Generated {new Date(existing.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </p>
        </div>
      )}

      {/* No insight yet */}
      {hasData && !existing && !generating && (
        <div className="rounded-2xl border border-app-subtle glass p-8 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-accent/10">
            <Sparkles className="h-6 w-6 text-accent" />
          </div>
          <p className="text-sm font-semibold text-app-primary">No insights generated yet.</p>
          <p className="mt-1 text-xs text-app-muted">Click below to analyze your week.</p>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="animate-fade-in flex items-start gap-2.5 rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
          <p className="text-sm font-medium text-red-400">{error}</p>
        </div>
      )}

      {/* Generate button */}
      {hasData && (
        <button
          onClick={handleGenerate}
          disabled={generating}
          className="group flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-accent/20 transition-all duration-300 hover:shadow-xl hover:shadow-accent/30 hover:brightness-110 disabled:opacity-50"
        >
          {generating ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Analyzing your data...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4 transition-transform group-hover:rotate-180 duration-500" />
              {existing ? 'Regenerate Insights' : 'Generate AI Insights'}
            </>
          )}
        </button>
      )}
    </div>
  );
}
