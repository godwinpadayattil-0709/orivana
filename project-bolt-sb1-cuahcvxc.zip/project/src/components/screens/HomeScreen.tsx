import { useEffect, useState } from 'react';
import { Moon, Droplets, Dumbbell, Footprints, Loader2, Flame, ArrowRight, TrendingUp, BookOpen, Heart, Check } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { fetchGoals, fetchTodayLog, fetchRecentLogs, fetchWellnessSettings, fetchGratitudeEntry, fetchMeditationSessions, fetchTodayMood, upsertMoodEntry } from '@/lib/api';
import { getDailyProgress, getGreeting, getStreak, getWeeklyCompletion } from '@/lib/calculations';
import type { Goals, DailyHealthLog, WellnessSettings, MoodLevel } from '@/types';
import { MultiRing } from '@/components/ui/ProgressRing';
import { MetricCard } from '@/components/ui/MetricCard';
import { MoodCheckIn } from '@/components/ui/MoodCheckIn';
import type { TabId } from '@/components/navigation/Navigation';

interface HomeScreenProps {
  onNavigate: (tab: TabId) => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const { user, profile } = useAuth();
  const [goals, setGoals] = useState<Goals | null>(null);
  const [todayLog, setTodayLog] = useState<DailyHealthLog | null>(null);
  const [loading, setLoading] = useState(true);
  const [recentLogs, setRecentLogs] = useState<DailyHealthLog[]>([]);
  const [wellnessSettings, setWellnessSettings] = useState<WellnessSettings | null>(null);
  const [gratitudeDone, setGratitudeDone] = useState(false);
  const [meditationDone, setMeditationDone] = useState(false);
  const [wellnessStreak, setWellnessStreak] = useState(0);
  const [showMoodCheckIn, setShowMoodCheckIn] = useState(false);
  const [todayMood, setTodayMood] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    async function load() {
      if (!user || cancelled) return;
      const [g, t, r, ws, mood] = await Promise.all([
        fetchGoals(user.id),
        fetchTodayLog(user.id),
        fetchRecentLogs(user.id, 7),
        fetchWellnessSettings(user.id),
        fetchTodayMood(user.id),
      ]);
      if (cancelled) return;
      setGoals(g);
      setTodayLog(t);
      setRecentLogs(r);
      setWellnessSettings(ws);

      if (mood) {
        setTodayMood(mood.mood);
      } else {
        setShowMoodCheckIn(true);
      }

      if (ws?.gratitude_enabled || ws?.meditation_enabled) {
        const today = new Date().toISOString().split('T')[0];
        if (ws.gratitude_enabled) {
          const entry = await fetchGratitudeEntry(user.id, today);
          if (!cancelled) setGratitudeDone(!!entry);
        }
        if (ws.meditation_enabled) {
          const sessions = await fetchMeditationSessions(user.id, 30);
          if (!cancelled) {
            const todaySessions = sessions.filter((s) => s.started_at.startsWith(today));
            setMeditationDone(todaySessions.length > 0);
            // Calculate wellness streak (days with either gratitude or meditation)
            const activeDates = new Set<string>();
            const gratitudeEntries = await fetchGratitudeEntry(user.id, today);
            if (gratitudeEntries) activeDates.add(today);
            sessions.forEach((s) => {
              if (s.completed) activeDates.add(s.started_at.split('T')[0]);
            });
            let streak = 0;
            let expected = new Date();
            for (let i = 0; i < 30; i++) {
              const dateStr = expected.toISOString().split('T')[0];
              if (activeDates.has(dateStr)) {
                streak++;
                expected = new Date(expected.getTime() - 86400000);
              } else if (i === 0) {
                expected = new Date(expected.getTime() - 86400000);
              } else {
                break;
              }
            }
            setWellnessStreak(streak);
          }
        }
      }
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [user]);

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-accent" />
      </div>
    );
  }

  const progress = getDailyProgress(todayLog, goals);
  const greeting = getGreeting();
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
  const hasLogged = todayLog !== null;
  const daysTracked = recentLogs.length;
  const streak = getStreak(recentLogs);
  const weeklyData = getWeeklyCompletion(recentLogs, goals);
  const dayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const todayIdx = (new Date().getDay() + 6) % 7;

  const rings = [
    { percent: progress.exercise.percent, color: 'var(--accent-dark)', label: 'Exercise' },
    { percent: progress.steps.percent, color: 'var(--accent)', label: 'Steps' },
    { percent: progress.water.percent, color: 'var(--accent-light)', label: 'Water' },
    { percent: progress.sleep.percent, color: 'var(--accent-dark)', label: 'Sleep' },
  ];

  const metricColors = {
    sleep: 'var(--accent-dark)',
    water: 'var(--accent-light)',
    exercise: 'var(--accent-dark)',
    steps: 'var(--accent)',
  };

  async function handleMoodSubmit(mood: MoodLevel, score: number) {
    if (!user) return;
    try {
      await upsertMoodEntry(user.id, { mood, mood_score: score });
      setTodayMood(mood);
      setShowMoodCheckIn(false);
    } catch {
      // Keep modal open so user can retry
    }
  }

  return (
    <div className="space-y-6">
      {/* Mood check-in modal */}
      {showMoodCheckIn && !todayMood && (
        <MoodCheckIn
          userName={profile?.name || 'there'}
          isNewUser={profile ? profile.created_at.split('T')[0] === new Date().toISOString().split('T')[0] : false}
          onClose={() => setShowMoodCheckIn(false)}
          onSubmit={handleMoodSubmit}
        />
      )}

      {/* Header with greeting + streak */}
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-app-tertiary">{today}</p>
          <h1 className="mt-1 text-2xl font-extrabold tracking-tight text-app-primary">
            {greeting}, {profile?.name || 'there'}
          </h1>
        </div>
        {streak > 0 && (
          <div className="flex items-center gap-2 rounded-2xl border border-orange-500/20 bg-orange-500/10 px-3 py-2">
            <Flame className="h-5 w-5 text-orange-400" />
            <div>
              <span className="text-lg font-extrabold leading-none text-orange-400">{streak}</span>
              <span className="ml-1 text-xs font-medium text-orange-400/70">day streak</span>
            </div>
          </div>
        )}
      </div>

      {/* Multi-ring hero */}
      <div className="relative overflow-hidden rounded-3xl border border-app-subtle glass-strong p-8">
        <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-accent/[0.08] blur-[80px]" />
        <div className="relative flex flex-col items-center">
          <p className="mb-5 text-xs font-bold tracking-wider text-app-muted uppercase">Today's Progress</p>
          <div className="ring-pulse">
            <MultiRing rings={rings} size={240} strokeWidth={13} gap={5} />
          </div>

          {/* Legend */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-5 gap-y-2">
            {rings.map((ring) => (
              <div key={ring.label} className="flex items-center gap-1.5">
                <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: ring.color }} />
                <span className="text-xs font-medium text-app-secondary">{ring.label}</span>
              </div>
            ))}
          </div>

          <p className="mt-5 text-center text-sm text-app-tertiary">
            {progress.overall === 0
              ? 'Log your habits to see progress'
              : progress.overall === 100
              ? 'All goals met today. Outstanding work!'
              : `${progress.overall}% of your daily goals completed`}
          </p>
        </div>
      </div>

      {/* CTA if no data logged */}
      {!hasLogged && (
        <button
          onClick={() => onNavigate('track')}
          className="group flex w-full items-center justify-between rounded-2xl border border-accent/20 bg-accent/[0.07] p-5 text-left transition-all hover:border-accent/30 hover:bg-accent/10"
        >
          <div>
            <p className="text-sm font-bold text-app-primary">No data logged yet today</p>
            <p className="mt-0.5 text-xs text-app-tertiary">Tap to log your habits in under 30 seconds</p>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/15 transition-transform group-hover:scale-110">
            <ArrowRight className="h-5 w-5 text-accent" />
          </div>
        </button>
      )}

      {/* Metric cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <MetricCard
          icon={Moon}
          label="Sleep"
          current={progress.sleep.current}
          goal={progress.sleep.goal}
          percent={progress.sleep.percent}
          unit="hrs"
          color={metricColors.sleep}
          onClick={() => onNavigate('track')}
        />
        <MetricCard
          icon={Droplets}
          label="Water"
          current={progress.water.current}
          goal={progress.water.goal}
          percent={progress.water.percent}
          unit="L"
          color={metricColors.water}
          onClick={() => onNavigate('track')}
        />
        <MetricCard
          icon={Dumbbell}
          label="Exercise"
          current={progress.exercise.current}
          goal={progress.exercise.goal}
          percent={progress.exercise.percent}
          unit="min"
          color={metricColors.exercise}
          onClick={() => onNavigate('track')}
        />
        <MetricCard
          icon={Footprints}
          label="Steps"
          current={progress.steps.current}
          goal={progress.steps.goal}
          percent={progress.steps.percent}
          unit="steps"
          color={metricColors.steps}
          onClick={() => onNavigate('track')}
        />
      </div>

      {/* Weekly bar chart */}
      <div className="rounded-2xl border border-app-subtle glass p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-accent" />
            <h3 className="text-sm font-bold text-app-primary">This Week</h3>
          </div>
          <button
            onClick={() => onNavigate('progress')}
            className="text-xs font-semibold text-app-tertiary transition-colors hover:text-accent"
          >
            View Trends →
          </button>
        </div>

        <div className="flex items-end justify-between gap-2" style={{ height: 120 }}>
          {weeklyData.map((val, i) => {
            const isToday = i === todayIdx;
            const height = Math.max(val, 3);
            return (
              <div key={i} className="flex flex-1 flex-col items-center gap-2">
                <div className="flex w-full flex-1 items-end justify-center">
                  <div
                    className="w-full max-w-[28px] rounded-t-md transition-all duration-700 ease-out"
                    style={{
                      height: `${height}%`,
                      background: isToday
                        ? 'linear-gradient(180deg, var(--accent-light), var(--accent-dark))'
                        : val > 0
                        ? 'linear-gradient(180deg, rgba(255,255,255,0.12), rgba(255,255,255,0.06))'
                        : 'rgba(255,255,255,0.03)',
                      boxShadow: isToday ? '0 0 12px var(--shadow-teal-strong)' : 'none',
                    }}
                  />
                </div>
                <span className={`text-[10px] font-semibold ${isToday ? 'text-accent' : 'text-app-muted'}`}>
                  {dayLabels[(todayIdx - 6 + i + 7) % 7]}
                </span>
              </div>
            );
          })}
        </div>

        <div className="mt-4 flex items-center justify-between border-t border-app-subtle pt-4">
          <div>
            <p className="text-xs font-medium text-app-muted">Days tracked</p>
            <p className="text-lg font-extrabold text-app-primary">{daysTracked} / 7</p>
          </div>
          <div className="text-right">
            <p className="text-xs font-medium text-app-muted">Avg completion</p>
            <p className="text-lg font-extrabold text-app-primary">
              {weeklyData.length > 0
                ? Math.round(weeklyData.reduce((a, b) => a + b, 0) / weeklyData.length)
                : 0}%
            </p>
          </div>
        </div>
      </div>

      {/* Today's Reflection — only show if wellness features are enabled */}
      {(wellnessSettings?.gratitude_enabled || wellnessSettings?.meditation_enabled) && (
        <div className="rounded-2xl border border-app-subtle glass-strong p-5">
          <div className="mb-4 flex items-center gap-2">
            <Heart className="h-4 w-4 text-accent" />
            <h3 className="text-sm font-bold text-app-primary">Today's Reflection</h3>
          </div>

          <div className="space-y-3">
            {wellnessSettings?.gratitude_enabled && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className={`flex h-7 w-7 items-center justify-center rounded-lg ${gratitudeDone ? 'bg-accent/15 text-accent' : 'bg-white/[0.04] text-app-muted'}`}>
                    {gratitudeDone ? <Check className="h-4 w-4" /> : <BookOpen className="h-4 w-4" />}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-app-primary">Gratitude</p>
                    <p className="text-xs text-app-tertiary">{gratitudeDone ? 'Completed today' : 'Not completed yet'}</p>
                  </div>
                </div>
                {!gratitudeDone && (
                  <button onClick={() => onNavigate('gratitude')} className="rounded-lg bg-accent/10 px-3 py-1.5 text-xs font-semibold text-accent transition-all hover:bg-accent/20">
                    Write
                  </button>
                )}
              </div>
            )}

            {wellnessSettings?.meditation_enabled && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className={`flex h-7 w-7 items-center justify-center rounded-lg ${meditationDone ? 'bg-accent/15 text-accent' : 'bg-white/[0.04] text-app-muted'}`}>
                    {meditationDone ? <Check className="h-4 w-4" /> : <Heart className="h-4 w-4" />}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-app-primary">Meditation</p>
                    <p className="text-xs text-app-tertiary">{meditationDone ? 'Session completed' : 'Not completed yet'}</p>
                  </div>
                </div>
                {!meditationDone && (
                  <button onClick={() => onNavigate('meditation')} className="rounded-lg bg-accent/10 px-3 py-1.5 text-xs font-semibold text-accent transition-all hover:bg-accent/20">
                    Meditate
                  </button>
                )}
              </div>
            )}

            {wellnessStreak > 0 && (
              <div className="flex items-center gap-2 border-t border-app-subtle pt-3">
                <Flame className="h-4 w-4 text-orange-400" />
                <span className="text-xs font-semibold text-orange-400">{wellnessStreak} day wellness streak</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
