interface MiniChartProps {
  data: number[];
  labels: string[];
  color: string;
  goal?: number;
  unit?: string;
  height?: number;
}

export function MiniChart({
  data,
  labels,
  color,
  goal,
  height = 120,
}: MiniChartProps) {
  const width = 320;
  const padding = { top: 14, right: 12, bottom: 26, left: 12 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;

  const allValues = goal ? [...data, goal] : data;
  const maxVal = Math.max(...allValues, 1);
  const minVal = 0;

  const points = data.map((value, i) => {
    const x = padding.left + (i / Math.max(data.length - 1, 1)) * chartWidth;
    const y = padding.top + chartHeight - ((value - minVal) / (maxVal - minVal)) * chartHeight;
    return { x, y, value };
  });

  const linePath = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`)
    .join(' ');

  const areaPath = `${linePath} L ${points[points.length - 1]?.x ?? 0} ${padding.top + chartHeight} L ${points[0]?.x ?? 0} ${padding.top + chartHeight} Z`;
  const gradId = 'chart-grad';

  const goalY = goal
    ? padding.top + chartHeight - ((goal - minVal) / (maxVal - minVal)) * chartHeight
    : null;

  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="xMidYMid meet">
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>

      {goalY !== null && (
        <>
          <line
            x1={padding.left}
            y1={goalY}
            x2={width - padding.right}
            y2={goalY}
            stroke="var(--border-hover)"
            strokeWidth="1"
            strokeDasharray="4 4"
          />
          <text x={width - padding.right} y={goalY - 4} textAnchor="end" className="text-[8px] font-semibold" style={{ fill: 'var(--text-muted)' }}>
            goal
          </text>
        </>
      )}

      {data.length > 1 && (
        <path d={areaPath} fill={`url(#${gradId})`} />
      )}

      {data.length > 1 && (
        <path
          d={linePath}
          fill="none"
          stroke={color}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{ filter: `drop-shadow(0 0 6px color-mix(in srgb, ${color} 25%, transparent))` }}
        />
      )}

      {points.map((p, i) => (
        <g key={i}>
          <circle cx={p.x} cy={p.y} r="3.5" fill="var(--bg-primary)" stroke={color} strokeWidth="2" />
          <text x={p.x} y={height - 8} textAnchor="middle" className="text-[9px] font-semibold" style={{ fill: 'var(--text-muted)' }}>
            {labels[i]}
          </text>
        </g>
      ))}
    </svg>
  );
}
