import { useState } from 'react';
import { X, Loader2, Check } from 'lucide-react';
import type { MoodLevel } from '@/types';

interface MoodCheckInProps {
  userName: string;
  isNewUser: boolean;
  onClose: () => void;
  onSubmit: (mood: MoodLevel, score: number) => Promise<void>;
}

const MOODS: { level: MoodLevel; score: number; label: string; emoji: string; color: string }[] = [
  { level: 'great', score: 5, label: 'Great', emoji: '😄', color: 'var(--accent-light)' },
  { level: 'good', score: 4, label: 'Good', emoji: '🙂', color: 'var(--accent)' },
  { level: 'okay', score: 3, label: 'Okay', emoji: '😐', color: 'var(--accent)' },
  { level: 'low', score: 2, label: 'Low', emoji: '😕', color: 'var(--accent-dark)' },
  { level: 'rough', score: 1, label: 'Rough', emoji: '😣', color: 'var(--accent-dark)' },
];

export function MoodCheckIn({ userName, isNewUser, onClose, onSubmit }: MoodCheckInProps) {
  const [selected, setSelected] = useState<MoodLevel | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const hour = new Date().getHours();
  const timeGreeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  async function handleSubmit() {
    if (!selected) return;
    const mood = MOODS.find((m) => m.level === selected)!;
    setSubmitting(true);
    await onSubmit(mood.level, mood.score);
    setSubmitting(false);
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/60 md:items-center md:p-6" onClick={onClose}>
      <div
        className="w-full max-w-md animate-fade-in-up rounded-t-3xl border border-app-subtle glass-strong p-7 md:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-6 flex items-start justify-between">
          <div>
            <h2 className="text-xl font-extrabold tracking-tight text-app-primary">
              {isNewUser ? `${timeGreeting}, ${userName}!` : `Welcome back, ${userName}!`}
            </h2>
            <p className="mt-1 text-sm font-medium text-app-secondary">
              {isNewUser ? `How are you feeling today?` : `${timeGreeting} — how are you feeling today?`}
            </p>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-app-muted transition-colors hover:bg-app-card hover:text-app-secondary">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Mood selector */}
        <div className="mb-6 grid grid-cols-5 gap-2">
          {MOODS.map((mood) => {
            const isSelected = selected === mood.level;
            return (
              <button
                key={mood.level}
                onClick={() => setSelected(mood.level)}
                className={`flex flex-col items-center gap-2 rounded-2xl border py-4 transition-all duration-300 ${
                  isSelected
                    ? 'border-accent/40 bg-accent/10 scale-105'
                    : 'border-app-subtle bg-app-card hover:border-app-hover hover:scale-[1.02]'
                }`}
              >
                <span className="text-3xl transition-transform duration-300" style={{ filter: isSelected ? 'none' : 'grayscale(0.3)' }}>
                  {mood.emoji}
                </span>
                <span
                  className="text-xs font-bold transition-colors"
                  style={{ color: isSelected ? mood.color : 'var(--text-muted)' }}
                >
                  {mood.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Mood meter bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs font-semibold text-app-muted">
            <span>Not great</span>
            <span>Amazing</span>
          </div>
          <div className="relative mt-2 h-2 overflow-hidden rounded-full bg-app-card">
            {selected && (
              <div
                className="absolute left-0 top-0 h-full rounded-full transition-all duration-500 ease-out"
                style={{
                  width: `${(MOODS.find((m) => m.level === selected)!.score / 5) * 100}%`,
                  background: 'linear-gradient(90deg, var(--accent-dark), var(--accent-light))',
                }}
              />
            )}
          </div>
        </div>

        <button
          onClick={handleSubmit}
          disabled={!selected || submitting}
          className="group flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent-dark py-3.5 text-sm font-bold text-zinc-950 shadow-lg shadow-accent/20 transition-all hover:brightness-110 disabled:opacity-40 disabled:shadow-none"
        >
          {submitting ? (
            <><Loader2 className="h-4 w-4 animate-spin" /> Saving...</>
          ) : (
            <><Check className="h-4 w-4" /> Check In</>
          )}
        </button>
      </div>
    </div>
  );
}
