interface RingData {
  percent: number;
  color: string;
  label: string;
}

interface MultiRingProps {
  rings: RingData[];
  size?: number;
  strokeWidth?: number;
  gap?: number;
}

export function MultiRing({
  rings,
  size = 240,
  strokeWidth = 14,
  gap = 6,
}: MultiRingProps) {
  const center = size / 2;
  const totalRings = rings.length;
  const innerRadius = center - strokeWidth - (totalRings - 1) * (strokeWidth + gap);

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        {rings.map((ring, i) => {
          const radius = innerRadius + i * (strokeWidth + gap);
          const circumference = 2 * Math.PI * radius;
          const clamped = Math.min(Math.max(ring.percent, 0), 100);
          const offset = circumference - (clamped / 100) * circumference;
          const gradientId = `ring-grad-${i}`;

          return (
            <g key={i}>
              <defs>
                <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor={ring.color} stopOpacity="1" />
                  <stop offset="100%" stopColor={ring.color} stopOpacity="0.6" />
                </linearGradient>
              </defs>
              {/* Track */}
              <circle
                cx={center}
                cy={center}
                r={radius}
                fill="none"
                stroke={ring.color}
                strokeOpacity="0.12"
                strokeWidth={strokeWidth}
              />
              {/* Progress */}
              <circle
                cx={center}
                cy={center}
                r={radius}
                fill="none"
                stroke={`url(#${gradientId})`}
                strokeWidth={strokeWidth}
                strokeDasharray={circumference}
                strokeDashoffset={offset}
                strokeLinecap="round"
                style={{ transition: 'stroke-dashoffset 1s cubic-bezier(0.4, 0, 0.2, 1)' }}
              />
            </g>
          );
        })}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-4xl font-extrabold tracking-tight text-app-primary tabular-nums">
          {Math.round(rings.reduce((sum, r) => sum + r.percent, 0) / rings.length)}%
        </span>
        <span className="mt-1 text-xs font-semibold tracking-wide text-app-muted uppercase">Overall</span>
      </div>
    </div>
  );
}

interface ProgressRingProps {
  percent: number;
  size?: number;
  strokeWidth?: number;
  label?: string;
  sublabel?: string;
  color?: string;
}

export function ProgressRing({
  percent,
  size = 200,
  strokeWidth = 12,
  label,
  sublabel,
  color = 'var(--accent)',
}: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clampedPercent = Math.min(Math.max(percent, 0), 100);
  const offset = circumference - (clampedPercent / 100) * circumference;
  const gradientId = 'progress-ring-grad';

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={color} stopOpacity="1" />
            <stop offset="100%" stopColor={color} stopOpacity="0.5" />
          </linearGradient>
        </defs>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeOpacity="0.12"
          strokeWidth={strokeWidth}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={`url(#${gradientId})`}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 1s cubic-bezier(0.4, 0, 0.2, 1)' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-4xl font-extrabold tracking-tight text-app-primary tabular-nums">{clampedPercent}%</span>
        {label && <span className="mt-1 text-sm font-semibold text-app-secondary">{label}</span>}
        {sublabel && <span className="text-xs text-app-muted">{sublabel}</span>}
      </div>
    </div>
  );
}
