import type { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  icon: LucideIcon;
  label: string;
  current: number;
  goal: number;
  percent: number;
  unit: string;
  color: string;
  onClick?: () => void;
}

export function MetricCard({
  icon: Icon,
  label,
  current,
  goal,
  percent,
  unit,
  color,
  onClick,
}: MetricCardProps) {
  const displayCurrent = current >= 1000 ? current.toLocaleString() : current.toFixed(current < 10 ? 1 : 0);
  const displayGoal = goal >= 1000 ? goal.toLocaleString() : goal;
  const isComplete = percent >= 100;

  return (
    <button
      onClick={onClick}
      className="group relative overflow-hidden rounded-2xl border border-app-subtle glass p-5 text-left transition-all duration-300 hover:border-app-hover hover:bg-app-card-hover active:scale-[0.97]"
    >
      {/* Glow effect on hover */}
      <div
        className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full opacity-0 blur-2xl transition-opacity duration-300 group-hover:opacity-30"
        style={{ backgroundColor: color }}
      />

      <div className="mb-3 flex items-center gap-2.5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl" style={{ backgroundColor: `color-mix(in srgb, ${color} 12%, transparent)` }}>
          <Icon className="h-[18px] w-[18px]" style={{ color }} />
        </div>
        <span className="text-sm font-semibold text-app-secondary">{label}</span>
        {isComplete && (
          <span className="ml-auto flex h-5 w-5 items-center justify-center rounded-full" style={{ backgroundColor: `color-mix(in srgb, ${color} 15%, transparent)` }}>
            <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          </span>
        )}
      </div>

      <div className="mb-3 flex items-baseline gap-1.5">
        <span className="text-2xl font-extrabold tracking-tight text-app-primary tabular-nums">{displayCurrent}</span>
        <span className="text-sm font-medium text-app-muted">/ {displayGoal} {unit}</span>
      </div>

      <div className="h-2 w-full overflow-hidden rounded-full bg-app-card">
        <div
          className="h-full rounded-full transition-all duration-1000 ease-out"
          style={{
            width: `${Math.min(percent, 100)}%`,
            background: `linear-gradient(90deg, ${color}, color-mix(in srgb, ${color} 67%, transparent))`,
          }}
        />
      </div>
      <div className="mt-2 flex items-center justify-between">
        <span className="text-xs font-semibold text-app-muted">{percent}% complete</span>
        {isComplete && (
          <span className="text-xs font-bold" style={{ color }}>Goal met</span>
        )}
      </div>
    </button>
  );
}
