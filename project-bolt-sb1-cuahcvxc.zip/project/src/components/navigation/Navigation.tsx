import { Home, Plus, TrendingUp, Sparkles, User, Settings, Heart, Utensils, FileText, BookOpen, LogOut } from 'lucide-react';
import { useAuth } from '@/lib/auth';

export type TabId =
  | 'home' | 'track' | 'progress' | 'ai' | 'profile'
  | 'settings' | 'gratitude' | 'meditation' | 'habits' | 'medical' | 'diet';

interface NavigationProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
  wellnessEnabled: { gratitude: boolean; meditation: boolean };
}

const primaryTabs: { id: TabId; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'track', label: 'Track', icon: Plus },
  { id: 'progress', label: 'Progress', icon: TrendingUp },
  { id: 'ai', label: 'AI', icon: Sparkles },
  { id: 'profile', label: 'Profile', icon: User },
];

function getWellnessTabs(gratitude: boolean, meditation: boolean) {
  const tabs: { id: TabId; label: string; icon: typeof Home }[] = [];
  if (gratitude) tabs.push({ id: 'gratitude', label: 'Gratitude', icon: BookOpen });
  if (meditation) tabs.push({ id: 'meditation', label: 'Meditate', icon: Heart });
  tabs.push({ id: 'habits', label: 'Habits', icon: Sparkles });
  tabs.push({ id: 'medical', label: 'Documents', icon: FileText });
  tabs.push({ id: 'diet', label: 'Diet Plans', icon: Utensils });
  tabs.push({ id: 'settings', label: 'Settings', icon: Settings });
  return tabs;
}

export function MobileBottomNav({ activeTab, onTabChange, wellnessEnabled }: NavigationProps) {
  const wellnessTabs = getWellnessTabs(wellnessEnabled.gratitude, wellnessEnabled.meditation);
  const showActiveInPrimary = primaryTabs.some((t) => t.id === activeTab);

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-app-subtle glass-strong pb-[env(safe-area-inset-bottom)] md:hidden">
      <div className="flex items-center justify-around px-2 pt-2">
        {primaryTabs.map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="group relative flex flex-1 flex-col items-center gap-1 py-2 transition-all"
            >
              {active && <div className="absolute -top-px h-0.5 w-8 rounded-full bg-accent" />}
              <div className={`flex h-7 w-7 items-center justify-center rounded-lg transition-all duration-300 ${active ? 'bg-accent/15 text-accent' : 'text-app-muted group-hover:text-app-secondary'}`}>
                <Icon className={`h-[18px] w-[18px] transition-transform duration-300 ${active ? 'scale-110' : ''}`} />
              </div>
              <span className={`text-[10px] font-semibold transition-colors duration-300 ${active ? 'text-accent' : 'text-app-muted'}`}>{tab.label}</span>
            </button>
          );
        })}

        {/* More button */}
        <button
          onClick={() => onTabChange('habits')}
          className="group relative flex flex-1 flex-col items-center gap-1 py-2 transition-all"
        >
          {!showActiveInPrimary && <div className="absolute -top-px h-0.5 w-8 rounded-full bg-accent" />}
          <div className={`flex h-7 w-7 items-center justify-center rounded-lg transition-all ${!showActiveInPrimary ? 'bg-accent/15 text-accent' : 'text-app-muted group-hover:text-app-secondary'}`}>
            <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="currentColor"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>
          </div>
          <span className={`text-[10px] font-semibold ${!showActiveInPrimary ? 'text-accent' : 'text-app-muted'}`}>More</span>
        </button>
      </div>

      {/* Expanded wellness tabs — show when a wellness tab is active */}
      {!showActiveInPrimary && (
        <div className="flex items-center gap-1 overflow-x-auto border-t border-app-subtle px-2 py-2">
          {wellnessTabs.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                  active ? 'bg-accent/15 text-accent' : 'text-app-muted'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>
      )}
    </nav>
  );
}

export function DesktopSidebar({ activeTab, onTabChange, wellnessEnabled }: NavigationProps) {
  const wellnessTabs = getWellnessTabs(wellnessEnabled.gratitude, wellnessEnabled.meditation);
  const { signOut } = useAuth();

  return (
    <aside className="fixed left-0 top-0 hidden h-screen w-64 flex-col border-r border-app-subtle bg-app-primary/80 p-5 md:flex">
      <div className="mb-8 flex items-center gap-3">
        <div className="relative flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-accent to-accent-dark shadow-lg shadow-accent/20">
          <svg viewBox="0 0 24 24" className="h-6 w-6 text-zinc-950" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 12h4l3-9 4 18 3-9h4" />
          </svg>
        </div>
        <div>
          <span className="text-base font-extrabold tracking-tight text-app-primary">Orivana</span>
          <span className="block text-[10px] font-medium tracking-wide text-app-muted">YOUR DAILY HEALTH &amp; WELLNESS COMPANION</span>
        </div>
      </div>

      <nav className="flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto pr-1" style={{ scrollbarWidth: 'thin' }}>
        <SidebarLabel>Core</SidebarLabel>
        {primaryTabs.map((tab) => (
          <SidebarItem key={tab.id} tab={tab} activeTab={activeTab} onTabChange={onTabChange} />
        ))}

        <SidebarLabel>Wellness</SidebarLabel>
        {wellnessTabs.map((tab) => (
          <SidebarItem key={tab.id} tab={tab} activeTab={activeTab} onTabChange={onTabChange} />
        ))}
      </nav>

      <div className="mt-auto shrink-0 space-y-3">
        <button
          onClick={signOut}
          className="flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold text-app-tertiary transition-all duration-300 hover:border-red-500/20 hover:bg-red-500/[0.06] hover:text-red-400"
        >
          <LogOut className="h-5 w-5" />
          Log Out
        </button>

        <div className="rounded-2xl border border-app-subtle glass p-4">
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-accent shadow-accent/50 shadow-sm" />
          <span className="text-xs font-medium text-app-secondary">All systems synced</span>
        </div>
        <p className="mt-1.5 text-[11px] leading-relaxed text-app-muted">Your data is private and encrypted end-to-end.</p>
        </div>
      </div>
    </aside>
  );
}

function SidebarLabel({ children }: { children: React.ReactNode }) {
  return <p className="px-4 pt-4 pb-1 text-[10px] font-bold tracking-wider text-app-muted uppercase">{children}</p>;
}

function SidebarItem({ tab, activeTab, onTabChange }: { tab: { id: TabId; label: string; icon: typeof Home }; activeTab: TabId; onTabChange: (id: TabId) => void }) {
  const Icon = tab.icon;
  const active = activeTab === tab.id;
  return (
    <button
      onClick={() => onTabChange(tab.id)}
      className={`group relative flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all duration-300 ${
        active ? 'bg-accent/10 text-accent' : 'text-app-tertiary hover:bg-app-card hover:text-app-secondary'
      }`}
    >
      {active && <div className="absolute left-0 h-5 w-1 rounded-r-full bg-accent" />}
      <Icon className={`h-5 w-5 transition-transform duration-300 ${active ? 'scale-110' : 'group-hover:scale-105'}`} />
      {tab.label}
    </button>
  );
}
