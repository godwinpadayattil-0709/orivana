export interface Profile {
  id: string;
  name: string | null;
  age: number | null;
  weight: number | null;
  country: string | null;
  country_source: string | null;
  timezone: string | null;
  created_at: string;
  updated_at: string;
}

export type MoodLevel = 'great' | 'good' | 'okay' | 'low' | 'rough';

export interface MoodEntry {
  id: string;
  user_id: string;
  entry_date: string;
  mood: MoodLevel;
  mood_score: number;
  note: string | null;
  created_at: string;
  updated_at: string;
}

export interface Goals {
  id: string;
  user_id: string;
  water_goal: number;
  sleep_goal: number;
  exercise_goal: number;
  steps_goal: number;
  created_at: string;
  updated_at: string;
}

export interface DailyHealthLog {
  id: string;
  user_id: string;
  log_date: string;
  sleep_hours: number;
  water_amount: number;
  exercise_minutes: number;
  steps: number;
  weight: number | null;
  created_at: string;
  updated_at: string;
}

export interface AIInsight {
  id: string;
  user_id: string;
  insight_date: string;
  period_start: string;
  period_end: string;
  summary: string;
  suggestions: string;
  created_at: string;
}

export interface MetricProgress {
  current: number;
  goal: number;
  percent: number;
  unit: string;
  label: string;
}

export interface DailyProgress {
  sleep: MetricProgress;
  water: MetricProgress;
  exercise: MetricProgress;
  steps: MetricProgress;
  overall: number;
}

// ============================================================
// Wellness Features
// ============================================================

export interface GratitudeEntry {
  id: string;
  user_id: string;
  entry_date: string;
  content: string;
  mood: string | null;
  tags: string[];
  created_at: string;
  updated_at: string;
}

export interface MeditationSession {
  id: string;
  user_id: string;
  meditation_type: string;
  duration: number;
  completed: boolean;
  mood_before: string | null;
  mood_after: string | null;
  reflection: string | null;
  started_at: string;
  completed_at: string | null;
}

export interface WellnessSettings {
  user_id: string;
  gratitude_enabled: boolean;
  meditation_enabled: boolean;
  gratitude_reminder_enabled: boolean;
  gratitude_reminder_time: string;
  meditation_reminder_enabled: boolean;
  meditation_reminder_time: string;
  theme_preference: string;
  color_theme: string;
  created_at: string;
  updated_at: string;
}

export type HabitType = 'good' | 'bad';
export type Criticality = 'low' | 'medium' | 'high';

export interface Habit {
  id: string;
  user_id: string;
  name: string;
  type: HabitType;
  category: string;
  frequency: string;
  ai_assessment: string | null;
  ai_recommendation: string | null;
  criticality: Criticality | null;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export type AnalysisStatus = 'pending' | 'analyzed' | 'failed';

export interface MedicalDocument {
  id: string;
  user_id: string;
  filename: string;
  file_path: string;
  file_type: string | null;
  file_size: number;
  upload_date: string;
  ai_analysis: string | null;
  ai_conditions: string[];
  ai_summary: string | null;
  analysis_status: AnalysisStatus;
  created_at: string;
}

export interface DietMeal {
  name: string;
  time: string;
  items: string[];
  calories: number;
}

export interface DietPlan {
  id: string;
  user_id: string;
  plan_name: string;
  conditions: string[];
  description: string | null;
  daily_calories: number | null;
  meals: DietMeal[];
  restrictions: string[];
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface MeditationOption {
  id: string;
  title: string;
  duration: number;
  category: string;
  description: string;
  guide: { time: number; text: string }[];
}
