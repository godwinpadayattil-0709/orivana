# Orivana MVP Explainer Video Script
**Target length: 4 minutes 45 seconds**
**Voice: calm, warm, confident pace (~130 words per minute)**

---

## SEGMENT 1 — Intro & Login (0:00 – 0:35)

**[Screen: App loading → Auth screen, Sign Up tab]**

> Welcome to Orivana — your daily health and wellness companion.
>
> Getting started is simple. Create an account with your email and password, or switch to Log In if you already have one.

**[Screen: Switch to Log In tab → show Forgot Password link]**

> Forgot your password? No problem. Just tap "Forgot password," enter your email, and we'll send you a secure link to reset it.

**[Action: Demo forgot password flow — enter email → "Check your email" confirmation]**

> Check your inbox, click the link, set a new password, and you're back in.

---

## SEGMENT 2 — Onboarding (0:35 – 0:55)

**[Screen: Onboarding — name, age, country, health goals]**

> Once you're in, we'll ask a few quick questions to personalize your experience — your name, age, country, and what you'd like to focus on. This only takes a minute.

---

## SEGMENT 3 — Home (0:55 – 1:20)

**[Screen: Home screen — greeting, daily summary cards, quick actions]**

> This is your Home screen — the hub of your wellness journey. You'll see a personalized greeting, a snapshot of your day, and quick access to everything you need. Your daily mood check-in is right here, along with shortcuts to track your health, view progress, and more.

---

## SEGMENT 4 — Track (1:20 – 1:50)

**[Screen: Track screen — metrics like weight, steps, water, sleep]**

> The Track screen is where you log your daily health metrics — weight, steps, water intake, sleep, and more. Just tap any metric, enter your value, and Orivana keeps a running history so you can spot trends over time. Everything is saved automatically and privately to your account.

---

## SEGMENT 5 — Progress (1:50 – 2:15)

**[Screen: Progress screen — charts, trends, streaks]**

> The Progress screen turns your data into insights. You'll see visual charts showing how your metrics change week over week, your current streaks, and a clear picture of where you're improving and where you might want to focus more attention.

---

## SEGMENT 6 — AI Insights (2:15 – 2:40)

**[Screen: AI screen — AI-generated insights and recommendations]**

> Orivana's AI analyzes your patterns and generates personalized insights — things like "Your sleep improves on days you drink more water" or suggestions to adjust your routine. It's like having a wellness coach that learns from your data.

---

## SEGMENT 7 — Gratitude (2:40 – 3:00)

**[Screen: Gratitude screen — gratitude journal entries]**

> A gratitude practice can transform your mental well-being. Here you can jot down what you're grateful for each day. Your entries are saved privately, and you can look back anytime to reflect on the positive moments in your life.

---

## SEGMENT 8 — Meditate (3:00 – 3:25)

**[Screen: Meditation screen — session options, timer running, ambient music toggle, voice guidance]**

> Take a moment to breathe. The Meditate screen offers guided sessions with calming ambient music and a gentle voice to guide you. The background music automatically softens when the voice speaks, so the guidance is always clear. Choose a session, close your eyes, and relax.

---

## SEGMENT 9 — Habits (3:25 – 3:45)

**[Screen: Habits screen — habit list, streaks, check-offs]**

> Build healthy habits that stick. Add habits you want to track — like drinking water, walking, or reading — and check them off each day. Orivana tracks your streaks and uses AI to analyze your consistency, helping you understand what's working and where you can improve.

---

## SEGMENT 10 — Medical Documents (3:45 – 4:05)

**[Screen: Medical Docs screen — upload, AI analysis results]**

> Upload your medical reports and Orivana's AI will analyze them — extracting conditions, summaries, and key findings. Your documents are stored securely and privately, and the detected conditions can be used to generate personalized diet plans.

---

## SEGMENT 11 — Diet Plans (4:05 – 4:30)

**[Screen: Diet Plans screen — goal selection (multi-goal), allergies, generated plan]**

> The Diet Plans screen creates AI-powered nutrition plans tailored to your needs. You can select multiple health goals at once — for example, managing diabetes AND losing weight — and Orivana will create a single combined plan that works for both. Add any food allergies, and the AI will strictly avoid them in every meal. You can also generate plans directly from your uploaded medical reports.

---

## SEGMENT 12 — Profile (4:30 – 4:40)

**[Screen: Profile screen — user info, health details]**

> Your Profile shows your personal details and health information at a glance. You can update your information anytime, and it feeds into your personalized recommendations.

---

## SEGMENT 13 — Settings & Logout (4:40 – 4:50)

**[Screen: Settings screen — theme options, preferences → scroll to Logout button]**

> In Settings, you can customize your experience — change the color theme, adjust preferences, and manage your account. When you're done, simply tap Log Out to securely sign out.

---

## CLOSING (4:50 – 4:55)

**[Screen: Fade to Orivana logo on dark background]**

> Orivana — your health, your journey, every day.

---

## Production Notes

- **Total estimated runtime:** ~4 min 55 sec
- **Pace:** ~130 words/minute — calm and unhurried
- **Music:** Soft ambient instrumental under the voice, ducked during narration
- **Transitions:** Simple fade or slide between screens
- **Screen recording:** Record each screen in sequence, then overlay the narration
- **Text-to-speech options:** ElevenLabs, Google Cloud TTS, or record your own voice
- **Format:** 1920x1080 (or 1080x1920 for vertical/mobile demo)
