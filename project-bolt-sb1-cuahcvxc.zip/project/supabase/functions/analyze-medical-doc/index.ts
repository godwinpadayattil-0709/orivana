import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const openaiKey = Deno.env.get("OPENAI_API_KEY");
const supabase = createClient(supabaseUrl, supabaseServiceKey);

function toBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const chunks: string[] = [];
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    chunks.push(String.fromCharCode(...bytes.subarray(i, Math.min(i + chunkSize, bytes.length))));
  }
  return btoa(chunks.join(''));
}

function responseError(status: number, message: string): Response {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  let docId: string | null = null;

  try {
    const { docId: requestDocId, filename, fileType, filePath } = await req.json();
    docId = requestDocId;

    const { data: fileData, error: downloadError } = await supabase.storage
      .from('medical-docs')
      .download(filePath);

    if (downloadError || !fileData) {
      if (docId) await supabase.from('medical_documents').update({ analysis_status: 'failed' }).eq('id', docId);
      return responseError(500, 'The document could not be retrieved from private storage.');
    }

    const arrayBuffer = await fileData.arrayBuffer();
    const sizeMB = arrayBuffer.byteLength / (1024 * 1024);
    if (sizeMB > 20) {
      const message = `This file is ${sizeMB.toFixed(1)} MB. AI analysis supports files up to 20 MB.`;
      if (docId) await supabase.from('medical_documents').update({ analysis_status: 'failed', ai_analysis: message }).eq('id', docId);
      return responseError(413, message);
    }

    if (!openaiKey) {
      const message = 'AI analysis is temporarily unavailable. The document was stored securely.';
      if (docId) await supabase.from('medical_documents').update({ analysis_status: 'failed', ai_analysis: message }).eq('id', docId);
      return responseError(503, message);
    }

    const base64Data = toBase64(arrayBuffer);
    const isImage = fileType?.startsWith('image/');
    const mediaType = fileType || (filename?.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'application/octet-stream');
    const dataUrl = `data:${mediaType};base64,${base64Data}`;
    const prompt = `Analyze this medical document (${filename}). Extract key findings, diagnosed conditions, and useful health insights. Return only valid JSON with this exact shape: {"summary":"2-3 sentence summary","conditions":["condition names"],"analysis":"detailed insights and recommendations"}. Always state that this is informational only and not medical advice.`;

    const content = isImage
      ? [
          { type: 'input_text', text: prompt },
          { type: 'input_image', image_url: dataUrl },
        ]
      : [
          { type: 'input_text', text: prompt },
          { type: 'input_file', filename, file_data: dataUrl },
        ];

    const openaiResponse = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        input: [{ role: 'user', content }],
        max_output_tokens: 2000,
      }),
    });

    if (!openaiResponse.ok) {
      const errorBody = await openaiResponse.json().catch(() => ({}));
      const apiMessage = errorBody?.error?.message || '';
      const message = openaiResponse.status === 429
        ? 'AI analysis is temporarily unavailable because the AI service has reached its usage limit. Your document is stored securely. Please try again later.'
        : `AI analysis could not be completed (${openaiResponse.status}). Your document is stored securely. Please try again later.`;
      console.error('OpenAI analysis error', openaiResponse.status, apiMessage);
      if (docId) await supabase.from('medical_documents').update({ analysis_status: 'failed', ai_analysis: message }).eq('id', docId);
      return responseError(openaiResponse.status === 429 ? 429 : 502, message);
    }

    const result = await openaiResponse.json();
    const contentText = result.output_text || result.output?.flatMap((item: { content?: { text?: string }[] }) => item.content || []).map((part: { text?: string }) => part.text || '').join('') || '';
    const cleanContent = contentText.replace(/^```json?\n?/, '').replace(/\n?```$/, '').trim();
    let parsed: { summary?: string; conditions?: unknown; analysis?: string };

    try {
      parsed = JSON.parse(cleanContent);
    } catch {
      parsed = { summary: cleanContent.slice(0, 240), conditions: [], analysis: cleanContent };
    }

    const summary = parsed.summary || 'The document was analyzed successfully.';
    const conditions = Array.isArray(parsed.conditions) ? parsed.conditions.filter((condition): condition is string => typeof condition === 'string') : [];
    const analysis = parsed.analysis || cleanContent;

    await supabase.from('medical_documents').update({
      ai_analysis: analysis,
      ai_conditions: conditions,
      ai_summary: summary,
      analysis_status: 'analyzed',
    }).eq('id', docId);

    return new Response(JSON.stringify({ analysis, conditions, summary }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    const message = 'The document was stored securely, but analysis could not be completed. Please try again later.';
    if (docId) {
      await supabase.from('medical_documents').update({ analysis_status: 'failed', ai_analysis: message }).eq('id', docId).catch(() => {});
    }
    console.error('Medical document analysis error', err);
    return responseError(500, message);
  }
});
