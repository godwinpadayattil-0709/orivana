const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface InsightPayload {
  goals: { water: number; sleep: number; exercise: number; steps: number } | null;
  averages: { sleep: number; water: number; exercise: number; steps: number };
  consistency: { sleep: number; water: number; exercise: number; steps: number };
  daysLogged: number;
  logs: { date: string; sleep: number; water: number; exercise: number; steps: number }[];
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { data }: { userId: string; data: InsightPayload } = await req.json();

    if (!data || !data.logs || data.logs.length === 0) {
      return new Response(
        JSON.stringify({ error: "No health data available to analyze" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("OPENAI_API_KEY");
    if (!apiKey) {
      // Fallback: generate a simple data-based summary without OpenAI
      return generateFallbackSummary(data, corsHeaders);
    }

    const prompt = buildPrompt(data);

    const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content:
              "You are a wellness assistant. Analyze the user's logged health data and provide observations and practical suggestions. Do NOT provide medical advice, diagnoses, or medication recommendations. Base your response ONLY on the provided data. Be encouraging but honest. Keep the summary to 2-3 sentences and suggestions to 1-2 practical tips.",
          },
          { role: "user", content: prompt },
        ],
        temperature: 0.7,
        max_tokens: 400,
      }),
    });

    if (!openaiResponse.ok) {
      return generateFallbackSummary(data, corsHeaders);
    }

    const openaiResult = await openaiResponse.json();
    const content = openaiResult.choices?.[0]?.message?.content || "";

    const parsed = parseAIResponse(content);

    return new Response(
      JSON.stringify({ summary: parsed.summary, suggestions: parsed.suggestions }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch {
    return new Response(
      JSON.stringify({ error: "Failed to generate insights" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function buildPrompt(data: InsightPayload): string {
  const g = data.goals;
  const a = data.averages;
  const c = data.consistency;

  return `Here is the user's wellness data for the last ${data.daysLogged} days:

GOALS:
- Water: ${g?.water ?? 2.5} L/day
- Sleep: ${g?.sleep ?? 8} hrs/night
- Exercise: ${g?.exercise ?? 45} min/day
- Steps: ${g?.steps ?? 8000} steps/day

7-DAY AVERAGES:
- Sleep: ${a.sleep} hrs
- Water: ${a.water} L
- Exercise: ${a.exercise} min
- Steps: ${a.steps.toLocaleString()}

CONSISTENCY (days goal was met):
- Sleep: ${c.sleep}%
- Water: ${c.water}%
- Exercise: ${c.exercise}%
- Steps: ${c.steps}%

DAILY LOGS:
${data.logs.map((l) => `${l.date}: sleep ${l.sleep}h, water ${l.water}L, exercise ${l.exercise}min, steps ${l.steps}`).join('\n')}

Please provide:
1. A brief summary (2-3 sentences) of their week
2. One or two practical suggestions based on the data

Format your response as:
SUMMARY: [your summary here]
SUGGESTIONS: [your suggestions here]`;
}

function parseAIResponse(content: string): { summary: string; suggestions: string } {
  const summaryMatch = content.match(/SUMMARY:\s*(.*?)(?:\n\s*SUGGESTIONS:|$)/is);
  const suggestionsMatch = content.match(/SUGGESTIONS:\s*(.*?)$/is);

  return {
    summary: summaryMatch?.[1]?.trim() || content,
    suggestions: suggestionsMatch?.[1]?.trim() || '',
  };
}

function generateFallbackSummary(data: InsightPayload, corsHeaders: Record<string, string>): Response {
  const a = data.averages;
  const c = data.consistency;
  const g = data.goals;

  const parts: string[] = [];
  parts.push(`Over the last ${data.daysLogged} days, you averaged ${a.sleep} hours of sleep, ${a.water}L of water, ${a.exercise} minutes of exercise, and ${a.steps.toLocaleString()} steps.`);

  if (g) {
    if (a.sleep < g.sleep) {
      parts.push(`Your sleep averaged below your ${g.sleep}-hour target.`);
    } else {
      parts.push(`Your sleep is meeting your ${g.sleep}-hour goal — great work.`);
    }
    if (c.exercise >= 70) {
      parts.push(`You've been consistent with exercise, hitting your goal ${c.exercise}% of days.`);
    } else if (c.exercise < 40) {
      parts.push(`Exercise has been less frequent this week — you met your goal ${c.exercise}% of days.`);
    }
  }

  const suggestions: string[] = [];
  if (g && a.sleep < g.sleep) {
    suggestions.push(`Try maintaining a consistent bedtime to close the gap on your sleep goal.`);
  }
  if (c.water < 50) {
    suggestions.push(`Consider keeping a water bottle nearby to stay on track with hydration.`);
  }
  if (c.exercise < 50) {
    suggestions.push(`Even short 15-minute sessions can help build momentum toward your exercise goal.`);
  }
  if (suggestions.length === 0) {
    suggestions.push(`Keep up the great work and maintain your current routine.`);
  }

  return new Response(
    JSON.stringify({
      summary: parts.join(' '),
      suggestions: suggestions.join(' '),
    }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}
