const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const HABIT_ASSESSMENTS: Record<string, { criticality: string; assessment: string; recommendation: string }> = {
  smoking: {
    criticality: "high",
    assessment: "Smoking is one of the most harmful habits for long-term health. It damages nearly every organ, increases risk of cardiovascular disease, lung cancer, COPD, and reduces life expectancy by 10+ years on average. No amount of smoking is safe.",
    recommendation: "Quitting is the single most impactful health decision you can make. Start by setting a quit date within 2 weeks. Consider nicotine replacement therapy (patches, gum), prescription medications like bupropion, and behavioral support. Even reducing frequency helps — each cigarette avoided is a step toward better health.",
  },
  alcohol: {
    criticality: "high",
    assessment: "Regular alcohol consumption affects liver health, increases cancer risk, disrupts sleep quality, and impacts mental health. Chronic use can lead to dependency, hypertension, and weakened immune function.",
    recommendation: "If you choose to drink, limit to 1 drink/day (women) or 2 drinks/day (men). Consider alcohol-free days each week. If you find it hard to cut back, speak with your doctor about supportive strategies.",
  },
  "junk food": {
    criticality: "medium",
    assessment: "Regular consumption of highly processed foods high in sugar, salt, and unhealthy fats contributes to obesity, type 2 diabetes, cardiovascular disease, and inflammation. These foods often lack essential nutrients.",
    recommendation: "Gradually replace processed snacks with whole foods: fruits, nuts, yogurt. Start by reducing portion sizes and frequency. Aim for home-cooked meals 5+ days per week. Small, consistent changes are more sustainable than drastic cuts.",
  },
  "screen time": {
    criticality: "medium",
    assessment: "Excessive screen time, especially before bed, disrupts circadian rhythms and sleep quality due to blue light exposure. It also contributes to sedentary behavior, eye strain, and can impact mental health and social connection.",
    recommendation: "Set a digital sunset — no screens 1 hour before bed. Use the 20-20-20 rule for eye strain. Build in movement breaks every 30 minutes. Consider app timers to create awareness of usage patterns.",
  },
  "morning walk": {
    criticality: "low",
    assessment: "Morning walks are an excellent low-impact habit. They improve cardiovascular health, boost mood through natural endorphin release, enhance metabolism, provide vitamin D from sunlight, and help establish a consistent daily routine.",
    recommendation: "Continue this habit. Aim for 20-30 minutes at a moderate pace. If possible, walk in nature for additional mental health benefits. This pairs well with a gratitude or meditation practice.",
  },
  hydration: {
    criticality: "low",
    assessment: "Proper hydration is essential for kidney function, skin health, digestion, cognitive performance, and temperature regulation. Even mild dehydration (1-2%) impairs concentration and energy levels.",
    recommendation: "Continue maintaining good hydration. Aim for 2-3 liters per day. Start your day with a glass of water before other beverages. Listen to your body — increase intake during exercise or hot weather.",
  },
  meditation: {
    criticality: "low",
    assessment: "Regular meditation practice reduces stress, lowers cortisol levels, improves emotional regulation, enhances focus and attention, and may reduce blood pressure. Even 5-10 minutes daily provides measurable benefits over time.",
    recommendation: "Continue this practice. Consistency matters more than duration. If you miss a day, simply resume without judgment. Gradually increase session length as it becomes more natural.",
  },
  "good sleep": {
    criticality: "low",
    assessment: "Consistent, quality sleep is foundational to health. It supports immune function, memory consolidation, emotional regulation, metabolic health, and cellular repair. 7-9 hours is recommended for most adults.",
    recommendation: "Continue prioritizing sleep. Maintain a consistent sleep schedule, even on weekends. Keep your bedroom cool and dark. Avoid screens and heavy meals 2 hours before bed.",
  },
};

function getAssessment(habitName: string, habitType: string, category: string): { criticality: string; assessment: string; recommendation: string } {
  const key = habitName.toLowerCase().trim();

  for (const [keyword, data] of Object.entries(HABIT_ASSESSMENTS)) {
    if (key.includes(keyword)) return data;
  }

  if (habitType === 'good') {
    return {
      criticality: "low",
      assessment: `This ${category.toLowerCase()} habit contributes positively to your overall health. Consistent positive habits compound over time, building resilience and supporting long-term wellbeing.`,
      recommendation: "Continue this habit and consider building on it. Pair it with another healthy behavior to create a habit stack. Track your consistency to maintain awareness.",
    };
  } else {
    return {
      criticality: "medium",
      assessment: `This ${category.toLowerCase()} habit may be impacting your health in subtle ways. The cumulative effect of habits we don't notice often matters more than any single dramatic behavior.`,
      recommendation: "Start by tracking how often this happens and what triggers it. Replace it with a healthier alternative that serves the same need. Small reductions are more sustainable than abrupt changes.",
    };
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { habitName, habitType, category } = await req.json();
    const result = getAssessment(habitName || '', habitType || 'good', category || 'general');

    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
