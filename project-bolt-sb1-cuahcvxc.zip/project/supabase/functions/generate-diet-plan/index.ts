const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const openaiKey = Deno.env.get("OPENAI_API_KEY");

const COUNTRY_CUISINE: Record<string, { staples: string[]; flavors: string; breakfast_foods: string[]; lunch_foods: string[]; dinner_foods: string[]; snacks: string[]; avoid: string[] }> = {
  india: {
    staples: ["rice", "roti/chapati", "lentils (dal)", "vegetable curries", "yogurt"],
    flavors: "Indian spices like turmeric, cumin, coriander, and garam masala",
    breakfast_foods: ["moong dal chilla (savory lentil pancake)", "vegetable poha", "upma with vegetables", "idli with sambar", "masala oats"],
    lunch_foods: ["roti with dal and vegetable sabzi", "brown rice with rajma (kidney beans)", "kathi roll with grilled vegetables", "bowl of dal with rice"],
    dinner_foods: ["tandoori grilled chicken or paneer", "mixed vegetable dal", "light curry with roti", "khichdi (rice and lentil porridge)"],
    snacks: ["roasted chana (chickpeas)", "sprout chaat", "buttermilk (chaas)", "fruit with chaat masala"],
    avoid: ["Deep-fried foods like samosa and pakora (limit)", "Sugary sweets like gulab jamun (limit)", "White rice in excess (opt for brown rice)"],
  },
  "united states": {
    staples: ["whole grain bread", "lean proteins", "salads", "oats", "sweet potatoes"],
    flavors: "American-style with herbs, olive oil, and minimal processing",
    breakfast_foods: ["oatmeal with berries and nuts", "whole grain toast with avocado", "Greek yogurt with granola", "egg white omelet with spinach"],
    lunch_foods: ["grilled chicken salad with mixed greens", "whole grain wrap with turkey and vegetables", "quinoa bowl with roasted vegetables", "lentil soup with whole grain bread"],
    dinner_foods: ["baked salmon with roasted sweet potato", "grilled chicken with steamed broccoli", "turkey chili with beans", "stir-fried tofu with brown rice"],
    snacks: ["apple slices with almond butter", "carrot sticks with hummus", "mixed unsalted nuts", "cottage cheese with fruit"],
    avoid: ["Fast food and fried items", "Sugary sodas and energy drinks", "Processed snack foods", "Excessive red meat"],
  },
  "united kingdom": {
    staples: ["whole grain bread", "oats", "potatoes (moderate)", "lean meats", "fish"],
    flavors: "British-style with herbs, olive oil, and seasonal vegetables",
    breakfast_foods: ["porridge with berries", "whole grain toast with scrambled eggs", "baked beans on whole grain toast", "Greek yogurt with honey and seeds"],
    lunch_foods: ["whole grain sandwich with lean chicken and salad", "lentil and vegetable soup", "jacket potato with tuna", "couscous salad with vegetables"],
    dinner_foods: ["grilled fish with new potatoes and vegetables", "chicken and vegetable stir-fry", "shepherd's pie with lean mince", "salmon with quinoa and green beans"],
    snacks: ["oatcakes with cheese", "fruit and nut mix", "carrot and cucumber sticks", "rice cakes with hummus"],
    avoid: ["Fried fish and chips (limit)", "Processed meats like sausages", "Sugary biscuits and cakes", "Excessive alcohol"],
  },
  japan: {
    staples: ["rice (moderate portions)", "fish", "tofu", "seaweed", "vegetables"],
    flavors: "Japanese-style with miso, soy sauce (low sodium), and dashi",
    breakfast_foods: ["miso soup with tofu", "grilled fish with rice", "natto with rice", "rolled omelet (tamagoyaki) with vegetables"],
    lunch_foods: ["soba noodle soup with vegetables", "grilled fish bento with rice", "tofu and vegetable donburi", "edamame and rice bowl"],
    dinner_foods: ["steamed fish with vegetables", "tofu stir-fry with miso glaze", "tempura vegetables (baked, not fried)", "rice bowl with grilled chicken"],
    snacks: ["edamame", "rice crackers (senbei)", "green tea", "fresh fruit"],
    avoid: ["Fried tempura (limit)", "Salty soy sauce (use low-sodium)", "Processed snacks", "Excessive white rice"],
  },
  italy: {
    staples: ["whole grain pasta (moderate)", "olive oil", "tomatoes", "lean proteins", "leafy greens"],
    flavors: "Mediterranean with olive oil, garlic, basil, and oregano",
    breakfast_foods: ["whole grain toast with olive oil and tomato", "Greek yogurt with fruit and honey", "frittata with vegetables", "oatmeal with nuts"],
    lunch_foods: ["whole grain pasta with tomato and basil", "minestrone soup", "grilled fish with vegetables", "farro salad with vegetables"],
    dinner_foods: ["baked fish with roasted vegetables", "chicken with cherry tomatoes and olives", "vegetable risotto (moderate)", "grilled swordfish with salad"],
    snacks: ["fresh fruit", "small handful of olives and almonds", "bruschetta with tomato", "pecorino cheese with fruit"],
    avoid: ["Creamy pasta sauces", "Excessive cheese", "Fried foods", "Processed meats like salami (limit)"],
  },
  mexico: {
    staples: ["corn tortillas", "beans", "rice (moderate)", "vegetables", "lean proteins"],
    flavors: "Mexican with cilantro, lime, cumin, and chili",
    breakfast_foods: ["huevos rancheros with corn tortilla", "black bean and vegetable burrito (whole grain)", "oatmeal with cinnamon and fruit", "scrambled eggs with peppers"],
    lunch_foods: ["grilled chicken with black beans and rice", "vegetable and bean tacos", "bowl with grilled vegetables and quinoa", "chicken and vegetable soup (caldo)"],
    dinner_foods: ["grilled fish with corn salsa", "chicken fajitas with vegetables", "bean and vegetable enchiladas (baked)", "shrimp with rice and beans"],
    snacks: ["jicama sticks with lime and chili", "roasted pumpkin seeds", "fresh mango or papaya", "corn tortilla chips with salsa (baked)"],
    avoid: ["Fried foods like chimichangas", "Sour cream (use sparingly)", "Refried beans with lard", "Sugary horchata (limit)"],
  },
};

function getCuisineContext(country: string): string {
  if (!country) return '';
  const lower = country.toLowerCase();
  for (const [key, cuisine] of Object.entries(COUNTRY_CUISINE)) {
    if (lower.includes(key) || key.includes(lower)) {
      return `Country: ${country}. Use ${cuisine.flavors}. Staple foods include ${cuisine.staples.join(', ')}. Breakfast ideas: ${cuisine.breakfast_foods.join(', ')}. Lunch ideas: ${cuisine.lunch_foods.join(', ')}. Dinner ideas: ${cuisine.dinner_foods.join(', ')}. Snack ideas: ${cuisine.snacks.join(', ')}. Suggest limiting: ${cuisine.avoid.join(', ')}.`;
    }
  }
  return `Country: ${country}. Incorporate local cuisine and food traditions from ${country} while keeping the diet healthy and balanced.`;
}

// ============================================================
// Goal-based diet plans (user needs mode)
// ============================================================

const GOAL_DIET_PLANS: Record<string, { plan_name: string; description: string; daily_calories: number; meals: unknown[]; restrictions: string[]; notes: string }> = {
  "weight-loss": {
    plan_name: "Weight Loss Diet Plan",
    description: "A calorie-controlled diet plan designed for sustainable weight loss, emphasizing high-protein, high-fiber foods that keep you full while creating a moderate calorie deficit.",
    daily_calories: 1600,
    meals: [
      { name: "Breakfast", time: "7:30 AM", calories: 350, items: ["2 egg omelet with spinach and tomatoes", "1 slice whole grain toast", "1/2 grapefruit", "Black coffee or green tea"] },
      { name: "Mid-Morning Snack", time: "10:30 AM", calories: 100, items: ["1 small apple", "10 almonds"] },
      { name: "Lunch", time: "1:00 PM", calories: 450, items: ["Grilled chicken breast (150g)", "Large mixed green salad with cucumber, tomato", "1 tbsp olive oil and lemon dressing", "1/2 cup quinoa"] },
      { name: "Afternoon Snack", time: "4:00 PM", calories: 100, items: ["1 cup carrot and bell pepper sticks", "2 tbsp hummus"] },
      { name: "Dinner", time: "7:00 PM", calories: 500, items: ["Baked white fish or tofu (150g)", "1 cup steamed broccoli and cauliflower", "1/2 cup sweet potato (roasted)", "Side salad with vinaigrette"] },
      { name: "Evening Snack", time: "9:00 PM", calories: 100, items: ["1/2 cup Greek yogurt (unsweetened)", "Pinch of cinnamon"] },
    ],
    restrictions: ["Sugary beverages and sodas", "Fried foods", "Refined carbohydrates (white bread, white rice)", "Processed snacks and chips", "High-calorie desserts", "Alcohol (limit strictly)"],
    notes: "Aim for a 500-calorie deficit from your maintenance level. Combine with 150 minutes of moderate cardio weekly. Prioritize protein at every meal to preserve muscle mass. Drink at least 2L of water daily. Weigh yourself once a week, not daily.",
  },
  "weight-gain": {
    plan_name: "Weight Gain Diet Plan",
    description: "A calorie-surplus diet plan designed for healthy weight gain, emphasizing nutrient-dense foods, healthy fats, and frequent meals to build muscle mass.",
    daily_calories: 2800,
    meals: [
      { name: "Breakfast", time: "7:30 AM", calories: 600, items: ["1 cup oatmeal with whole milk", "1 banana", "2 tbsp peanut butter", "2 scrambled eggs", "1 handful walnuts"] },
      { name: "Mid-Morning Snack", time: "10:30 AM", calories: 300, items: ["1 cup Greek yogurt with honey", "1/2 cup granola", "1 handful mixed nuts"] },
      { name: "Lunch", time: "1:00 PM", calories: 700, items: ["Grilled chicken thigh or salmon (200g)", "1 cup brown rice", "1 cup roasted vegetables with olive oil", "1/2 avocado", "1 whole grain roti or bread"] },
      { name: "Afternoon Snack", time: "4:00 PM", calories: 300, items: ["1 protein shake or smoothie (banana, milk, peanut butter)", "1 handful trail mix"] },
      { name: "Dinner", time: "7:00 PM", calories: 700, items: ["Grilled steak or paneer (200g)", "1 cup mashed potatoes or sweet potato", "1 cup sautéed vegetables with butter", "1 cup lentil soup", "2 whole grain roti"] },
      { name: "Evening Snack", time: "9:30 PM", calories: 200, items: ["1 cup cottage cheese or Greek yogurt", "1 tbsp honey", "1 handful almonds"] },
    ],
    restrictions: ["Low-calorie or diet foods", "Excessive cardio (limit to 2-3x weekly)", "Skipping meals", "Processed junk food (choose nutrient-dense instead)"],
    notes: "Aim for a 300-500 calorie surplus above maintenance. Combine with strength training 3-4 times per week to build muscle rather than fat. Eat every 3 hours. Include protein at every meal (aim for 1.6-2g protein per kg body weight). Drink calorie-containing beverages like milk or smoothies between meals.",
  },
  "diabetes": {
    plan_name: "Diabetes-Friendly Diet Plan",
    description: "A balanced diet plan designed to manage blood sugar levels, emphasizing low-glycemic foods, fiber-rich vegetables, and lean proteins while limiting refined carbohydrates and added sugars.",
    daily_calories: 1800,
    meals: [
      { name: "Breakfast", time: "7:00 AM", calories: 400, items: ["1/2 cup steel-cut oats with cinnamon", "1 tbsp chia seeds", "1/2 cup berries (blueberries or raspberries)", "1 boiled egg", "Black coffee or herbal tea"] },
      { name: "Mid-Morning Snack", time: "10:00 AM", calories: 150, items: ["15 almonds or walnuts", "1 small apple"] },
      { name: "Lunch", time: "12:30 PM", calories: 500, items: ["Grilled chicken breast (120g)", "1 cup mixed vegetables (broccoli, peppers, zucchini)", "1/2 cup quinoa", "Olive oil and lemon dressing", "Side salad with leafy greens"] },
      { name: "Afternoon Snack", time: "3:30 PM", calories: 150, items: ["1 cup cucumber and carrot sticks", "2 tbsp hummus"] },
      { name: "Dinner", time: "6:30 PM", calories: 500, items: ["Baked salmon or tofu (150g)", "1 cup roasted non-starchy vegetables", "1/2 cup brown rice or cauliflower rice", "1 tbsp olive oil", "Herbal tea"] },
      { name: "Evening Snack (if needed)", time: "8:30 PM", calories: 100, items: ["1/2 cup Greek yogurt (unsweetened)", "Pinch of cinnamon"] },
    ],
    restrictions: ["Refined sugar", "White bread and white rice", "Sugary beverages and fruit juices", "Processed snacks and sweets", "Fried foods", "Full-fat dairy in excess"],
    notes: "Monitor blood sugar before and 2 hours after meals. Aim for consistent meal times. Stay hydrated with water. Include 30 minutes of moderate exercise daily. Consult your endocrinologist for personalized carb targets.",
  },
  "high-blood-pressure": {
    plan_name: "Heart-Healthy DASH Diet Plan",
    description: "The DASH (Dietary Approaches to Stop Hypertension) diet emphasizes fruits, vegetables, whole grains, and lean proteins while reducing sodium intake to help lower blood pressure.",
    daily_calories: 2000,
    meals: [
      { name: "Breakfast", time: "7:00 AM", calories: 450, items: ["1 cup whole grain cereal (low sodium)", "1 cup skim or plant milk", "1 medium banana", "1 slice whole wheat toast with unsalted almond butter"] },
      { name: "Mid-Morning Snack", time: "10:00 AM", calories: 150, items: ["1 orange", "10 unsalted walnuts"] },
      { name: "Lunch", time: "12:30 PM", calories: 550, items: ["Grilled turkey or chicken sandwich on whole wheat bread", "Large side salad with mixed greens, tomatoes, cucumber", "1 tbsp olive oil and vinegar dressing", "1 cup fresh fruit"] },
      { name: "Afternoon Snack", time: "3:30 PM", calories: 150, items: ["1 cup baby carrots", "1/2 cup unsalted edamame"] },
      { name: "Dinner", time: "6:30 PM", calories: 550, items: ["Baked fish or skinless chicken (150g)", "1 cup steamed broccoli", "1/2 cup brown rice", "1 whole wheat dinner roll (no butter)", "Fresh fruit for dessert"] },
      { name: "Evening Snack", time: "8:30 PM", calories: 100, items: ["1/2 cup unsalted mixed berries", "1 small square dark chocolate (70%+)"] },
    ],
    restrictions: ["High-sodium processed foods", "Canned soups (unless low-sodium)", "Salted snacks and chips", "Pickled and fermented foods (high sodium)", "Red meat (limit to once weekly)", "Alcohol (limit strictly)"],
    notes: "Limit sodium to 1500-2300mg per day. Read food labels carefully. Use herbs and spices instead of salt for flavoring. Aim for 4-5 servings each of fruits and vegetables daily. Maintain regular physical activity and stress management.",
  },
  "cholesterol": {
    plan_name: "Cholesterol-Lowering Diet Plan",
    description: "A heart-healthy diet plan focused on reducing LDL cholesterol through soluble fiber, healthy fats, and plant sterols while limiting saturated and trans fats.",
    daily_calories: 1900,
    meals: [
      { name: "Breakfast", time: "7:00 AM", calories: 420, items: ["1 cup oatmeal with 2 tbsp ground flaxseed", "1/2 cup walnuts", "1 medium apple", "Green tea"] },
      { name: "Mid-Morning Snack", time: "10:00 AM", calories: 160, items: ["1 pear", "1 tbsp almond butter"] },
      { name: "Lunch", time: "12:30 PM", calories: 520, items: ["Lentil soup (1 cup)", "Mixed green salad with avocado", "Olive oil dressing", "1 slice whole grain bread", "1 orange"] },
      { name: "Afternoon Snack", time: "3:30 PM", calories: 140, items: ["1/4 cup unsalted sunflower seeds", "1 cup baby spinach smoothie"] },
      { name: "Dinner", time: "6:30 PM", calories: 520, items: ["Baked salmon (150g) — rich in omega-3", "1 cup Brussels sprouts roasted with olive oil", "1/2 cup quinoa", "Side salad with leafy greens"] },
      { name: "Evening Snack", time: "8:30 PM", calories: 100, items: ["1/2 cup edamame (steamed)", "Herbal tea"] },
    ],
    restrictions: ["Trans fats (partially hydrogenated oils)", "Red meat and processed meats", "Full-fat dairy products", "Fried foods", "Commercial baked goods", "Tropical oils (palm, coconut) in excess"],
    notes: "Include soluble fiber sources daily (oats, beans, flaxseed). Aim for 2 servings of omega-3 rich fish per week. Consider plant sterols/stanols. Limit dietary cholesterol to under 200mg/day. Regular cardio exercise amplifies benefits.",
  },
  "general-wellness": {
    plan_name: "General Wellness Diet Plan",
    description: "A balanced, nutrient-rich diet plan for overall health and wellness, emphasizing whole foods, diverse vegetables and fruits, and balanced macronutrients.",
    daily_calories: 2200,
    meals: [
      { name: "Breakfast", time: "7:30 AM", calories: 500, items: ["1 cup oatmeal with fruit and nuts", "1 boiled egg", "1 slice whole grain toast with avocado", "Green tea or black coffee"] },
      { name: "Mid-Morning Snack", time: "10:30 AM", calories: 200, items: ["1 cup Greek yogurt with berries", "1 small handful mixed nuts"] },
      { name: "Lunch", time: "12:30 PM", calories: 600, items: ["Grilled chicken or tofu (150g)", "1 cup mixed vegetables", "1/2 cup brown rice or quinoa", "Large salad with olive oil dressing", "1 piece fruit"] },
      { name: "Afternoon Snack", time: "3:30 PM", calories: 200, items: ["1 apple with 2 tbsp peanut butter", "1 cup green tea"] },
      { name: "Dinner", time: "7:00 PM", calories: 500, items: ["Baked fish or lentils (150g)", "1 cup roasted seasonal vegetables", "1/2 cup sweet potato", "Mixed green salad"] },
      { name: "Evening Snack", time: "9:00 PM", calories: 200, items: ["1 cup herbal tea", "1 small piece dark chocolate (70%+)"] },
    ],
    restrictions: ["Highly processed foods", "Excessive added sugars", "Trans fats", "Sugary beverages", "Excessive alcohol"],
    notes: "Eat a rainbow of fruits and vegetables daily. Include 2-3 servings of fish per week. Stay hydrated with at least 2L of water. Combine with 150 minutes of moderate exercise weekly. Prioritize sleep (7-9 hours) for optimal health.",
  },
  "pcos": {
    plan_name: "PCOS-Friendly Diet Plan",
    description: "A diet plan tailored for managing PCOS symptoms, focusing on low-glycemic foods, anti-inflammatory ingredients, and balanced blood sugar through protein and fiber.",
    daily_calories: 1800,
    meals: [
      { name: "Breakfast", time: "7:30 AM", calories: 400, items: ["2 egg omelet with spinach and mushrooms", "1/2 avocado", "1 slice whole grain or sourdough toast", "Green tea"] },
      { name: "Mid-Morning Snack", time: "10:30 AM", calories: 150, items: ["1 small apple", "15 walnuts"] },
      { name: "Lunch", time: "1:00 PM", calories: 500, items: ["Grilled salmon or chicken (120g)", "1 cup leafy greens with olive oil", "1/2 cup quinoa", "1/2 cup roasted Brussels sprouts"] },
      { name: "Afternoon Snack", time: "4:00 PM", calories: 150, items: ["1 cup cucumber sticks", "2 tbsp hummus"] },
      { name: "Dinner", time: "7:00 PM", calories: 500, items: ["Baked chicken or tofu (120g)", "1 cup steamed broccoli", "1/2 cup cauliflower rice", "1 tbsp olive oil", "Herbal tea"] },
      { name: "Evening Snack", time: "9:00 PM", calories: 100, items: ["1/2 cup berries", "1 tbsp chia seeds"] },
    ],
    restrictions: ["Refined carbohydrates", "Sugary foods and beverages", "Processed snacks", "Excessive soy (consult doctor)", "Fried foods"],
    notes: "Focus on low-glycemic foods to manage insulin resistance. Include anti-inflammatory foods like berries, leafy greens, and fatty fish. Aim for 30 minutes of exercise daily, combining cardio and strength training. Consult your endocrinologist for personalized guidance.",
  },
  "thyroid": {
    plan_name: "Thyroid-Supportive Diet Plan",
    description: "A nutrient-dense diet plan supporting thyroid health, rich in iodine, selenium, and zinc while avoiding goitrogen-heavy raw cruciferous vegetables.",
    daily_calories: 2000,
    meals: [
      { name: "Breakfast", time: "7:30 AM", calories: 450, items: ["1 cup oatmeal with walnuts and berries", "2 boiled eggs", "1 slice whole grain toast", "Green tea"] },
      { name: "Mid-Morning Snack", time: "10:30 AM", calories: 200, items: ["1 cup Greek yogurt", "1 tbsp pumpkin seeds (rich in zinc)"] },
      { name: "Lunch", time: "12:30 PM", calories: 550, items: ["Grilled fish or chicken (150g)", "1 cup cooked carrots and zucchini", "1/2 cup brown rice", "Side salad with olive oil"] },
      { name: "Afternoon Snack", time: "3:30 PM", calories: 150, items: ["1 handful Brazil nuts (2-3 nuts, rich in selenium)", "1 orange"] },
      { name: "Dinner", time: "7:00 PM", calories: 500, items: ["Baked salmon or shrimp (150g)", "1 cup cooked spinach (cooked reduces goitrogens)", "1/2 cup sweet potato", "1 tbsp olive oil"] },
      { name: "Evening Snack", time: "9:00 PM", calories: 150, items: ["1 cup warm milk or herbal tea", "1 small handful almonds"] },
    ],
    restrictions: ["Raw cruciferous vegetables (cabbage, broccoli, cauliflower — cook them instead)", "Excessive soy products", "Highly processed foods", "Excessive iodine supplementation (consult doctor)"],
    notes: "Include selenium-rich foods like Brazil nuts (2-3 daily) and zinc-rich foods like pumpkin seeds. Cook cruciferous vegetables to reduce goitrogens. Avoid taking thyroid medication with calcium or iron supplements within 4 hours. Consult your endocrinologist for personalized guidance.",
  },
};

const GOAL_LABELS: Record<string, string> = {
  "weight-loss": "Weight Loss",
  "weight-gain": "Weight Gain",
  "diabetes": "Diabetes Management",
  "high-blood-pressure": "High Blood Pressure",
  "cholesterol": "Cholesterol Management",
  "general-wellness": "General Wellness",
  "pcos": "PCOS Management",
  "thyroid": "Thyroid Support",
};

function getMergedGoalPlan(goals: string[], allergies: string[], country: string) {
  const cuisineContext = getCuisineContext(country);

  // Gather all base plans for selected goals
  const basePlans = goals.map((g) => GOAL_DIET_PLANS[g] || GOAL_DIET_PLANS["general-wellness"]);
  if (basePlans.length === 0) basePlans.push(GOAL_DIET_PLANS["general-wellness"]);

  // Use the first goal's plan as the structural base
  const primary = basePlans[0];

  // Merge: pick the most restrictive calorie target (lowest among goals)
  const dailyCalories = Math.min(...basePlans.map((p) => p.daily_calories));

  // Merge restrictions from all goals (deduplicated)
  const mergedRestrictions = [...new Set(basePlans.flatMap((p) => p.restrictions))];

  // Merge notes from all goals
  const mergedNotesBase = basePlans.map((p) => p.notes).join(' ');

  // Build meals by alternating items from each goal's plan for each meal slot
  const mealSlots = primary.meals.map((_: any, idx: number) => idx);
  const mergedMeals = mealSlots.map((idx) => {
    const mealVariants = basePlans.map((p) => p.meals[idx]).filter(Boolean);
    const baseMeal = mealVariants[0];
    // Collect unique items from all goals for this meal slot
    const allItems = [...new Set(mealVariants.flatMap((m: any) => m.items))];
    // Average the calories across goals for this meal
    const avgCalories = Math.round(mealVariants.reduce((sum: number, m: any) => sum + (m.calories || 0), 0) / mealVariants.length);
    return { ...baseMeal, items: allItems, calories: avgCalories };
  });

  // Apply allergy filtering to merged meals
  const allergyLower = allergies.map((a) => a.toLowerCase().trim()).filter(Boolean);
  const filteredMeals = mergedMeals.map((meal: any) => {
    const filteredItems = meal.items.filter((item: string) => {
      const itemLower = item.toLowerCase();
      return !allergyLower.some((allergy) => itemLower.includes(allergy));
    });
    if (filteredItems.length < meal.items.length) {
      filteredItems.push("Substitute added to avoid allergens — see notes");
    }
    return { ...meal, items: filteredItems.length > 0 ? filteredItems : meal.items };
  });

  const goalLabels = goals.map((g) => GOAL_LABELS[g] || g);
  const planName = goalLabels.length > 1
    ? `${goalLabels.join(' + ')} Diet Plan`
    : primary.plan_name;

  const description = goalLabels.length > 1
    ? `A combined diet plan addressing ${goalLabels.join(', ')}. This plan merges the dietary principles of each goal — selecting foods that satisfy the most restrictive requirements while maintaining balance and nutrition.`
    : primary.description;

  const allergyNote = allergies.length > 0
    ? `\n\nIMPORTANT — Allergies to avoid: ${allergies.join(', ')}. All meals have been adjusted to exclude these allergens. Please double-check ingredient labels when purchasing packaged foods, as trace amounts may be present.`
    : '';

  const cuisineNote = cuisineContext
    ? `\n\nLocalized for ${country}: ${cuisineContext}`
    : '';

  return {
    plan_name: allergies.length > 0 ? `${planName} (Allergy-Adapted)` : planName,
    description,
    daily_calories: dailyCalories,
    meals: filteredMeals,
    restrictions: [...mergedRestrictions, ...allergies.map((a) => `${a} (allergy)`)],
    notes: `${mergedNotesBase}${allergyNote}${cuisineNote}`,
    conditions: goalLabels,
    source: "user-needs",
  };
}

// ============================================================
// Condition-based diet plans (medical docs mode)
// ============================================================

const CONDITION_DIET_PLANS: Record<string, { plan_name: string; description: string; daily_calories: number; meals: unknown[]; restrictions: string[]; notes: string }> = {
  diabetes: GOAL_DIET_PLANS["diabetes"],
  "high blood pressure": GOAL_DIET_PLANS["high-blood-pressure"],
  cholesterol: GOAL_DIET_PLANS["cholesterol"],
};

function getDietPlan(conditions: string[], documents: { filename: string; summary: string; conditions: string[] }[], country: string) {
  const cuisineContext = getCuisineContext(country);

  for (const cond of conditions) {
    const lower = cond.toLowerCase();
    for (const [key, plan] of Object.entries(CONDITION_DIET_PLANS)) {
      if (lower.includes(key) || key.includes(lower)) {
        const planCopy = { ...plan, conditions };
        if (cuisineContext) {
          planCopy.notes = `${plan.notes}\n\nLocalized for ${country}: ${cuisineContext}`;
        }
        return planCopy;
      }
    }
  }

  return {
    plan_name: country
      ? `Healthy Diet Plan (${country} Cuisine)`
      : "Personalized Healthy Diet Plan",
    description: `A balanced diet plan based on your health profile${country ? `, featuring cuisine from ${country}` : ''}. This plan emphasizes whole foods, balanced macronutrients, and regular meal timing to support overall health${conditions.length > 0 ? ` while managing ${conditions.join(', ')}` : ''}.`,
    daily_calories: 2000,
    meals: [
      { name: "Breakfast", time: "7:00 AM", calories: 450, items: ["1 cup whole grain cereal or oatmeal", "1 cup milk or plant-based alternative", "1 serving fresh fruit", "1 boiled egg or 2 tbsp nuts"] },
      { name: "Mid-Morning Snack", time: "10:00 AM", calories: 150, items: ["1 piece of fresh fruit", "Small handful of unsalted nuts"] },
      { name: "Lunch", time: "12:30 PM", calories: 550, items: ["Grilled lean protein (chicken, fish, or tofu) — 120-150g", "1 cup mixed vegetables", "1/2 cup whole grains (brown rice, quinoa)", "Side salad with olive oil dressing"] },
      { name: "Afternoon Snack", time: "3:30 PM", calories: 150, items: ["1 cup vegetable sticks", "2 tbsp hummus or yogurt dip"] },
      { name: "Dinner", time: "6:30 PM", calories: 550, items: ["Baked or grilled protein — 150g", "1 cup steamed or roasted vegetables", "1/2 cup complex carbohydrates", "1 tbsp healthy fat (olive oil, avocado)"] },
      { name: "Evening Snack", time: "8:30 PM", calories: 150, items: ["1 cup Greek yogurt or herbal tea", "Small serving of berries"] },
    ],
    restrictions: ["Highly processed foods", "Excessive added sugars", "Trans fats", "Sugary beverages", "Excessive alcohol"],
    notes: country
      ? `This plan is tailored for ${country} cuisine preferences. ${cuisineContext} Adjust portions based on your activity level and health goals. Stay hydrated with water throughout the day. Consult with a registered dietitian for a fully personalized plan.`
      : "This is a general healthy eating plan. Adjust portions based on your activity level and health goals. Stay hydrated with water throughout the day. Include a variety of colorful vegetables and fruits. Consult with a registered dietitian for a fully personalized plan.",
  };
}

// ============================================================
// Main handler
// ============================================================

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const mode: string = body.mode || "medical";
    const userCountry = body.country || '';

    let plan;

    if (mode === "user-needs") {
      // User needs mode: multi-goal diet plan with allergies
      const goalsRaw: string[] = Array.isArray(body.goals) ? body.goals : (body.goal ? [body.goal] : ["general-wellness"]);
      const goals: string[] = goalsRaw.filter(Boolean);
      const allergies: string[] = body.allergies || [];

      if (openaiKey) {
        const cuisineContext = getCuisineContext(userCountry);
        const goalLabels = goals.map((g) => GOAL_LABELS[g] || g);
        const goalsDescription = goalLabels.length > 1
          ? `the following combined health goals: ${goalLabels.join(', ')}. Create a SINGLE unified diet plan that satisfies ALL goals simultaneously. Pick foods that work for the most restrictive goal. When goals conflict (e.g., weight gain vs. diabetes), prioritize the medical condition.`
          : `the goal: ${goalLabels[0]}`;
        const allergyPrompt = allergies.length > 0
          ? ` The user has the following food allergies: ${allergies.join(', ')}. STRICTLY AVOID all foods containing these allergens in every meal. Provide safe alternatives. Do not include any food item that contains or is derived from these allergens.`
          : '';
        const countryPrompt = cuisineContext
          ? ` The user is based in ${userCountry}. ${cuisineContext} Use locally available ingredients and traditional dishes adapted to be healthy.`
          : '';

        const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${openaiKey}`,
          },
          body: JSON.stringify({
            model: "gpt-4o",
            messages: [
              {
                role: "system",
                content: `You are a nutritionist AI. Generate a personalized diet plan based on the user's health goals, food allergies, and country/cuisine preferences. When multiple goals are selected, create a single combined plan that satisfies all of them. STRICTLY exclude any foods the user is allergic to — this is non-negotiable. Respond in JSON format: {"plan_name": "...", "description": "...", "daily_calories": number, "meals": [{"name": "...", "time": "...", "calories": number, "items": ["..."]}], "restrictions": ["..."], "notes": "..."}. Include a medical disclaimer in notes. Use foods and ingredients native to the user's country where possible.`,
              },
              {
                role: "user",
                content: `Create a diet plan for ${goalsDescription}.${allergyPrompt}${countryPrompt}`,
              },
            ],
            max_tokens: 2000,
          }),
        });

        if (openaiResponse.ok) {
          const result = await openaiResponse.json();
          const content = result.choices?.[0]?.message?.content || '';
          try {
            plan = JSON.parse(content);
            plan.conditions = goalLabels;
            plan.source = "user-needs";
            // Ensure allergies are in restrictions
            if (allergies.length > 0) {
              plan.restrictions = [...(plan.restrictions || []), ...allergies.map((a: string) => `${a} (allergy)`)];
            }
          } catch {
            plan = getMergedGoalPlan(goals, allergies, userCountry);
          }
        }
      }

      if (!plan) {
        plan = getMergedGoalPlan(goals, allergies, userCountry);
      }
    } else {
      // Medical docs mode (original behavior)
      const conditions: string[] = body.conditions || [];
      const documents = body.documents || [];

      if (openaiKey) {
        const cuisineContext = getCuisineContext(userCountry);
        const countryPrompt = cuisineContext
          ? ` The user is based in ${userCountry}. ${cuisineContext} Use locally available ingredients and traditional dishes adapted to be healthy.`
          : '';

        const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${openaiKey}`,
          },
          body: JSON.stringify({
            model: "gpt-4o",
            messages: [
              {
                role: "system",
                content: `You are a nutritionist AI. Generate a personalized diet plan based on medical conditions and the user's country/cuisine preferences. Respond in JSON format: {"plan_name": "...", "description": "...", "daily_calories": number, "meals": [{"name": "...", "time": "...", "calories": number, "items": ["..."]}], "restrictions": ["..."], "notes": "..."}. Include a medical disclaimer in notes. Use foods and ingredients native to the user's country where possible.`,
              },
              {
                role: "user",
                content: `Create a diet plan for someone with these conditions: ${conditions.join(', ')}. Medical documents: ${JSON.stringify(documents)}.${countryPrompt}`,
              },
            ],
            max_tokens: 2000,
          }),
        });

        if (openaiResponse.ok) {
          const result = await openaiResponse.json();
          const content = result.choices?.[0]?.message?.content || '';
          try {
            plan = JSON.parse(content);
            plan.conditions = conditions;
            plan.source = "medical";
          } catch {
            plan = getDietPlan(conditions, documents, userCountry);
          }
        }
      }

      if (!plan) {
        plan = getDietPlan(conditions, documents, userCountry);
      }
    }

    return new Response(
      JSON.stringify(plan),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: (err as Error).message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
