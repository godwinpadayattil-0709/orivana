/*
# Add color_theme column to wellness_settings

1. Modified Tables
- `wellness_settings`: Added `color_theme` column (text, default 'teal-mist')
  - Stores the user's selected color theme ID from the available presets
  - Defaults to 'teal-mist' which is the original Vitalis teal/cyan theme
2. Security
- No changes to existing RLS policies — the column is user-owned data within
  the existing wellness_settings row, already protected by owner-scoped policies.
3. Notes
- The column is nullable-safe with a default so existing rows get the default theme
- The frontend reads this column and applies the corresponding CSS variables
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'wellness_settings' AND column_name = 'color_theme'
  ) THEN
    ALTER TABLE wellness_settings ADD COLUMN color_theme text DEFAULT 'teal-mist';
  END IF;
END $$;
