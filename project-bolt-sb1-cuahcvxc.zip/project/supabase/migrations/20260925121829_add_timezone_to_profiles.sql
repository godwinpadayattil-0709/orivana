/*
# Add timezone field to profiles

1. Modified Tables
- `profiles`: adds `timezone` (text, nullable) — stores the user's IANA timezone (e.g. "America/New_York") for time-aware features.
2. Security
- No new policies needed — existing profiles policies already cover this column.
3. Important Notes
- The `timezone` column is nullable so existing profiles are unaffected.
*/

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'timezone') THEN
    ALTER TABLE profiles ADD COLUMN timezone text;
  END IF;
END $$;
