/*
# Fix mutable search_path on update_updated_at function

1. Modified Functions
- `public.update_updated_at`: sets an explicit `search_path = public` so the function is not vulnerable to search_path manipulation.
2. Security
- Eliminates the "mutable search_path" security finding.
*/

CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;
