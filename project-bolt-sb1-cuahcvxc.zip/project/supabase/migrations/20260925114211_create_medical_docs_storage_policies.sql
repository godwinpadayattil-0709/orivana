/*
# Storage policies for medical-docs bucket

## Overview
Creates RLS policies on storage.objects so authenticated users can upload, read,
and delete their own medical documents in the 'medical-docs' bucket.
Files are stored under a per-user path: user_id/filename

## Security
- SELECT (read): user can read objects in their own folder
- INSERT (upload): user can upload to their own folder
- UPDATE: user can update objects in their own folder
- DELETE: user can delete objects in their own folder
*/

DROP POLICY IF EXISTS "read_own_medical_docs" ON storage.objects;
CREATE POLICY "read_own_medical_docs" ON storage.objects FOR SELECT
  TO authenticated USING (
    bucket_id = 'medical-docs'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

DROP POLICY IF EXISTS "upload_own_medical_docs" ON storage.objects;
CREATE POLICY "upload_own_medical_docs" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (
    bucket_id = 'medical-docs'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

DROP POLICY IF EXISTS "update_own_medical_docs" ON storage.objects;
CREATE POLICY "update_own_medical_docs" ON storage.objects FOR UPDATE
  TO authenticated USING (
    bucket_id = 'medical-docs'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

DROP POLICY IF EXISTS "delete_own_medical_docs" ON storage.objects;
CREATE POLICY "delete_own_medical_docs" ON storage.objects FOR DELETE
  TO authenticated USING (
    bucket_id = 'medical-docs'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
