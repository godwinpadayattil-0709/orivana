/*
# Create Wellness Features Schema

## Overview
Adds optional wellness modules to Vitalis: gratitude journaling, meditation tracking,
habit tracking, medical document upload with AI analysis, AI-generated diet plans,
and per-user wellness settings.

## New Tables

1. **gratitude_entries** — Daily gratitude journal entries
   - id (uuid PK), user_id (FK auth.users), entry_date (date), content (text),
     mood (text), tags (text[]), created_at, updated_at

2. **meditation_sessions** — Completed meditation session logs
   - id (uuid PK), user_id (FK auth.users), meditation_type (text), duration (int seconds),
     completed (bool), mood_before (text), mood_after (text), reflection (text),
     started_at (timestamptz), completed_at (timestamptz)

3. **wellness_settings** — Per-user wellness feature toggles and reminder prefs
   - user_id (FK auth.users PK), gratitude_enabled (bool), meditation_enabled (bool),
     gratitude_reminder_enabled (bool), gratitude_reminder_time (text),
     meditation_reminder_enabled (bool), meditation_reminder_time (text),
     created_at, updated_at

4. **habits** — User-defined good and bad habits with AI criticality assessment
   - id (uuid PK), user_id (FK auth.users), name (text), type (text: good/bad),
     category (text), frequency (text), ai_assessment (text), ai_recommendation (text),
     criticality (text: low/medium/high), active (bool), created_at, updated_at

5. **medical_documents** — Uploaded medical reports (metadata + Supabase Storage path)
   - id (uuid PK), user_id (FK auth.users), filename (text), file_path (text),
     file_type (text), file_size (bigint), upload_date (date),
     ai_analysis (text), ai_conditions (text[]), ai_summary (text),
     analysis_status (text: pending/analyzed/failed), created_at

6. **diet_plans** — AI-generated diet plans based on medical conditions
   - id (uuid PK), user_id (FK auth.users), plan_name (text), conditions (text[]),
     description (text), daily_calories (int), meals (jsonb), restrictions (text[]),
     notes (text), created_at, updated_at

## Security
- RLS enabled on all tables.
- Owner-scoped CRUD policies (4 per table) using auth.uid() = user_id.
- All user_id columns default to auth.uid() for safe inserts.
- Unique constraints on (user_id, entry_date) for gratitude_entries and
  (user_id, log_date) patterns to prevent duplicates.
*/

-- ============================================================
-- gratitude_entries
-- ============================================================
CREATE TABLE IF NOT EXISTS gratitude_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  content text NOT NULL DEFAULT '',
  mood text,
  tags text[] DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, entry_date)
);

ALTER TABLE gratitude_entries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_gratitude" ON gratitude_entries;
CREATE POLICY "select_own_gratitude" ON gratitude_entries FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_gratitude" ON gratitude_entries;
CREATE POLICY "insert_own_gratitude" ON gratitude_entries FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_gratitude" ON gratitude_entries;
CREATE POLICY "update_own_gratitude" ON gratitude_entries FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_gratitude" ON gratitude_entries;
CREATE POLICY "delete_own_gratitude" ON gratitude_entries FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_gratitude_user_date ON gratitude_entries(user_id, entry_date DESC);

-- ============================================================
-- meditation_sessions
-- ============================================================
CREATE TABLE IF NOT EXISTS meditation_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  meditation_type text NOT NULL DEFAULT '',
  duration integer NOT NULL DEFAULT 0,
  completed boolean NOT NULL DEFAULT false,
  mood_before text,
  mood_after text,
  reflection text,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE meditation_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_meditation" ON meditation_sessions;
CREATE POLICY "select_own_meditation" ON meditation_sessions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_meditation" ON meditation_sessions;
CREATE POLICY "insert_own_meditation" ON meditation_sessions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_meditation" ON meditation_sessions;
CREATE POLICY "update_own_meditation" ON meditation_sessions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_meditation" ON meditation_sessions;
CREATE POLICY "delete_own_meditation" ON meditation_sessions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_meditation_user_date ON meditation_sessions(user_id, started_at DESC);

-- ============================================================
-- wellness_settings
-- ============================================================
CREATE TABLE IF NOT EXISTS wellness_settings (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  gratitude_enabled boolean NOT NULL DEFAULT false,
  meditation_enabled boolean NOT NULL DEFAULT false,
  gratitude_reminder_enabled boolean NOT NULL DEFAULT false,
  gratitude_reminder_time text DEFAULT '09:00',
  meditation_reminder_enabled boolean NOT NULL DEFAULT false,
  meditation_reminder_time text DEFAULT '20:00',
  theme_preference text NOT NULL DEFAULT 'dark',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE wellness_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_wellness_settings" ON wellness_settings;
CREATE POLICY "select_own_wellness_settings" ON wellness_settings FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_wellness_settings" ON wellness_settings;
CREATE POLICY "insert_own_wellness_settings" ON wellness_settings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_wellness_settings" ON wellness_settings;
CREATE POLICY "update_own_wellness_settings" ON wellness_settings FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_wellness_settings" ON wellness_settings;
CREATE POLICY "delete_own_wellness_settings" ON wellness_settings FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================
-- habits
-- ============================================================
CREATE TABLE IF NOT EXISTS habits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('good', 'bad')),
  category text DEFAULT 'general',
  frequency text DEFAULT 'daily',
  ai_assessment text,
  ai_recommendation text,
  criticality text DEFAULT 'low' CHECK (criticality IN ('low', 'medium', 'high')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE habits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_habits" ON habits;
CREATE POLICY "select_own_habits" ON habits FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_habits" ON habits;
CREATE POLICY "insert_own_habits" ON habits FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_habits" ON habits;
CREATE POLICY "update_own_habits" ON habits FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_habits" ON habits;
CREATE POLICY "delete_own_habits" ON habits FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_habits_user ON habits(user_id, active);

-- ============================================================
-- medical_documents
-- ============================================================
CREATE TABLE IF NOT EXISTS medical_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  filename text NOT NULL,
  file_path text NOT NULL,
  file_type text,
  file_size bigint DEFAULT 0,
  upload_date date NOT NULL DEFAULT CURRENT_DATE,
  ai_analysis text,
  ai_conditions text[] DEFAULT '{}',
  ai_summary text,
  analysis_status text NOT NULL DEFAULT 'pending' CHECK (analysis_status IN ('pending', 'analyzed', 'failed')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE medical_documents ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_medical_docs" ON medical_documents;
CREATE POLICY "select_own_medical_docs" ON medical_documents FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_medical_docs" ON medical_documents;
CREATE POLICY "insert_own_medical_docs" ON medical_documents FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_medical_docs" ON medical_documents;
CREATE POLICY "update_own_medical_docs" ON medical_documents FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_medical_docs" ON medical_documents;
CREATE POLICY "delete_own_medical_docs" ON medical_documents FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_medical_docs_user ON medical_documents(user_id, upload_date DESC);

-- ============================================================
-- diet_plans
-- ============================================================
CREATE TABLE IF NOT EXISTS diet_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_name text NOT NULL,
  conditions text[] DEFAULT '{}',
  description text,
  daily_calories integer,
  meals jsonb DEFAULT '[]',
  restrictions text[] DEFAULT '{}',
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE diet_plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_diet_plans" ON diet_plans;
CREATE POLICY "select_own_diet_plans" ON diet_plans FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_diet_plans" ON diet_plans;
CREATE POLICY "insert_own_diet_plans" ON diet_plans FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_diet_plans" ON diet_plans;
CREATE POLICY "update_own_diet_plans" ON diet_plans FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_diet_plans" ON diet_plans;
CREATE POLICY "delete_own_diet_plans" ON diet_plans FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_diet_plans_user ON diet_plans(user_id, created_at DESC);
