/*
# Add country field to profiles and create mood_entries table

1. Modified Tables
- `profiles`: adds `country` (text, nullable) — stores the user's country for diet plan localization.
- `profiles`: adds `country_source` (text, nullable) — 'manual' or 'geo' to indicate how country was captured.

2. New Tables
- `mood_entries`
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to auth.uid(), references auth.users)
  - `entry_date` (date, not null) — the date of the mood check-in
  - `mood` (text, not null) — one of: great, good, okay, low, rough
  - `mood_score` (integer, not null) — 1-5 scale (5=great, 1=rough)
  - `note` (text, nullable) — optional user note
  - `created_at` (timestamptz, defaults to now())
  - `updated_at` (timestamptz, defaults to now())
  - Unique constraint on (user_id, entry_date) — one mood entry per day.

3. Security
- Enable RLS on `mood_entries`.
- Owner-scoped CRUD: each authenticated user can only access their own mood entries.
- Profiles: existing policies already cover the new columns since they are on the same table.

4. Important Notes
- The `country` and `country_source` columns are nullable so existing profiles are unaffected.
- `mood_entries` has a unique constraint on (user_id, entry_date) to prevent duplicate daily entries.
- The `user_id` column defaults to `auth.uid()` so inserts that omit it still satisfy RLS.
*/

-- Add country columns to profiles
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'country') THEN
    ALTER TABLE profiles ADD COLUMN country text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'country_source') THEN
    ALTER TABLE profiles ADD COLUMN country_source text;
  END IF;
END $$;

-- Create mood_entries table
CREATE TABLE IF NOT EXISTS mood_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  entry_date date NOT NULL,
  mood text NOT NULL,
  mood_score integer NOT NULL,
  note text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, entry_date)
);

ALTER TABLE mood_entries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_mood_entries" ON mood_entries;
CREATE POLICY "select_own_mood_entries"
  ON mood_entries FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_mood_entries" ON mood_entries;
CREATE POLICY "insert_own_mood_entries"
  ON mood_entries FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_mood_entries" ON mood_entries;
CREATE POLICY "update_own_mood_entries"
  ON mood_entries FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_mood_entries" ON mood_entries;
CREATE POLICY "delete_own_mood_entries"
  ON mood_entries FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Index for fast lookups by user
CREATE INDEX IF NOT EXISTS idx_mood_entries_user_id ON mood_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_mood_entries_user_date ON mood_entries(user_id, entry_date DESC);
