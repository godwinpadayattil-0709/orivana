/*
# Personal Health Manager — Initial Schema

## Overview
Creates the core database tables for a personal wellness tracking app:
- profiles: user personal info (name, age, weight)
- goals: daily wellness targets (water, sleep, exercise, steps)
- daily_health_logs: per-day habit entries (sleep, water, exercise, steps, weight)
- ai_insights: cached AI-generated weekly summaries

## Tables

### profiles
- id (uuid, PK, references auth.users)
- name (text)
- age (int)
- weight (numeric)
- created_at, updated_at (timestamptz)

### goals
- id (uuid, PK)
- user_id (uuid, FK → auth.users, DEFAULT auth.uid())
- water_goal (numeric, liters)
- sleep_goal (numeric, hours)
- exercise_goal (numeric, minutes)
- steps_goal (integer, steps)
- created_at, updated_at (timestamptz)

### daily_health_logs
- id (uuid, PK)
- user_id (uuid, FK → auth.users, DEFAULT auth.uid())
- log_date (date, NOT NULL)
- sleep_hours (numeric)
- water_amount (numeric, liters)
- exercise_minutes (numeric)
- steps (integer)
- weight (numeric)
- created_at, updated_at (timestamptz)
- UNIQUE(user_id, log_date) — prevents duplicate daily logs

### ai_insights
- id (uuid, PK)
- user_id (uuid, FK → auth.users, DEFAULT auth.uid())
- insight_date (date)
- period_start, period_end (date)
- summary (text)
- suggestions (text)
- created_at (timestamptz)

## Security
- RLS enabled on ALL tables
- Each table has 4 owner-scoped policies (SELECT/INSERT/UPDATE/DELETE)
- All scoped TO authenticated with auth.uid() = user_id checks
- profiles uses auth.uid() = id (the PK is the user id)

## Indexes
- goals: user_id
- daily_health_logs: user_id, (user_id, log_date) unique
- ai_insights: user_id
*/

-- PROFILES TABLE
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name text,
  age integer,
  weight numeric,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

-- GOALS TABLE
CREATE TABLE IF NOT EXISTS goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  water_goal numeric DEFAULT 2.5,
  sleep_goal numeric DEFAULT 8,
  exercise_goal numeric DEFAULT 45,
  steps_goal integer DEFAULT 8000,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE goals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_goals" ON goals;
CREATE POLICY "select_own_goals" ON goals FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_goals" ON goals;
CREATE POLICY "insert_own_goals" ON goals FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_goals" ON goals;
CREATE POLICY "update_own_goals" ON goals FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_goals" ON goals;
CREATE POLICY "delete_own_goals" ON goals FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_goals_user_id ON goals(user_id);

-- DAILY HEALTH LOGS TABLE
CREATE TABLE IF NOT EXISTS daily_health_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  log_date date NOT NULL DEFAULT CURRENT_DATE,
  sleep_hours numeric DEFAULT 0,
  water_amount numeric DEFAULT 0,
  exercise_minutes numeric DEFAULT 0,
  steps integer DEFAULT 0,
  weight numeric,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, log_date)
);

ALTER TABLE daily_health_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_logs" ON daily_health_logs;
CREATE POLICY "select_own_logs" ON daily_health_logs FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_logs" ON daily_health_logs;
CREATE POLICY "insert_own_logs" ON daily_health_logs FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_logs" ON daily_health_logs;
CREATE POLICY "update_own_logs" ON daily_health_logs FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_logs" ON daily_health_logs;
CREATE POLICY "delete_own_logs" ON daily_health_logs FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_logs_user_id ON daily_health_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_logs_user_date ON daily_health_logs(user_id, log_date);

-- AI INSIGHTS TABLE
CREATE TABLE IF NOT EXISTS ai_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  insight_date date NOT NULL DEFAULT CURRENT_DATE,
  period_start date NOT NULL,
  period_end date NOT NULL,
  summary text,
  suggestions text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ai_insights ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_insights" ON ai_insights;
CREATE POLICY "select_own_insights" ON ai_insights FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_insights" ON ai_insights;
CREATE POLICY "insert_own_insights" ON ai_insights FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_insights" ON ai_insights;
CREATE POLICY "update_own_insights" ON ai_insights FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_insights" ON ai_insights;
CREATE POLICY "delete_own_insights" ON ai_insights FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_insights_user_id ON ai_insights(user_id);

-- updated_at trigger helper
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_updated_at_profiles ON profiles;
CREATE TRIGGER set_updated_at_profiles BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_goals ON goals;
CREATE TRIGGER set_updated_at_goals BEFORE UPDATE ON goals
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS set_updated_at_logs ON daily_health_logs;
CREATE TRIGGER set_updated_at_logs BEFORE UPDATE ON daily_health_logs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
